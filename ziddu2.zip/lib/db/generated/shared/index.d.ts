
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model SharedUser
 * 
 */
export type SharedUser = $Result.DefaultSelection<Prisma.$SharedUserPayload>
/**
 * Model SharedVendor
 * 
 */
export type SharedVendor = $Result.DefaultSelection<Prisma.$SharedVendorPayload>
/**
 * Model SharedPost
 * 
 */
export type SharedPost = $Result.DefaultSelection<Prisma.$SharedPostPayload>
/**
 * Model SharedMenuCategory
 * 
 */
export type SharedMenuCategory = $Result.DefaultSelection<Prisma.$SharedMenuCategoryPayload>
/**
 * Model SharedMenuSubCategory
 * 
 */
export type SharedMenuSubCategory = $Result.DefaultSelection<Prisma.$SharedMenuSubCategoryPayload>
/**
 * Model SharedMenuItem
 * 
 */
export type SharedMenuItem = $Result.DefaultSelection<Prisma.$SharedMenuItemPayload>
/**
 * Model SharedOffer
 * 
 */
export type SharedOffer = $Result.DefaultSelection<Prisma.$SharedOfferPayload>
/**
 * Model SharedBill
 * 
 */
export type SharedBill = $Result.DefaultSelection<Prisma.$SharedBillPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more SharedUsers
 * const sharedUsers = await prisma.sharedUser.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more SharedUsers
   * const sharedUsers = await prisma.sharedUser.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.sharedUser`: Exposes CRUD operations for the **SharedUser** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SharedUsers
    * const sharedUsers = await prisma.sharedUser.findMany()
    * ```
    */
  get sharedUser(): Prisma.SharedUserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sharedVendor`: Exposes CRUD operations for the **SharedVendor** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SharedVendors
    * const sharedVendors = await prisma.sharedVendor.findMany()
    * ```
    */
  get sharedVendor(): Prisma.SharedVendorDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sharedPost`: Exposes CRUD operations for the **SharedPost** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SharedPosts
    * const sharedPosts = await prisma.sharedPost.findMany()
    * ```
    */
  get sharedPost(): Prisma.SharedPostDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sharedMenuCategory`: Exposes CRUD operations for the **SharedMenuCategory** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SharedMenuCategories
    * const sharedMenuCategories = await prisma.sharedMenuCategory.findMany()
    * ```
    */
  get sharedMenuCategory(): Prisma.SharedMenuCategoryDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sharedMenuSubCategory`: Exposes CRUD operations for the **SharedMenuSubCategory** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SharedMenuSubCategories
    * const sharedMenuSubCategories = await prisma.sharedMenuSubCategory.findMany()
    * ```
    */
  get sharedMenuSubCategory(): Prisma.SharedMenuSubCategoryDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sharedMenuItem`: Exposes CRUD operations for the **SharedMenuItem** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SharedMenuItems
    * const sharedMenuItems = await prisma.sharedMenuItem.findMany()
    * ```
    */
  get sharedMenuItem(): Prisma.SharedMenuItemDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sharedOffer`: Exposes CRUD operations for the **SharedOffer** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SharedOffers
    * const sharedOffers = await prisma.sharedOffer.findMany()
    * ```
    */
  get sharedOffer(): Prisma.SharedOfferDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sharedBill`: Exposes CRUD operations for the **SharedBill** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SharedBills
    * const sharedBills = await prisma.sharedBill.findMany()
    * ```
    */
  get sharedBill(): Prisma.SharedBillDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.19.0
   * Query Engine version: 2ba551f319ab1df4bc874a89965d8b3641056773
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    SharedUser: 'SharedUser',
    SharedVendor: 'SharedVendor',
    SharedPost: 'SharedPost',
    SharedMenuCategory: 'SharedMenuCategory',
    SharedMenuSubCategory: 'SharedMenuSubCategory',
    SharedMenuItem: 'SharedMenuItem',
    SharedOffer: 'SharedOffer',
    SharedBill: 'SharedBill'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "sharedUser" | "sharedVendor" | "sharedPost" | "sharedMenuCategory" | "sharedMenuSubCategory" | "sharedMenuItem" | "sharedOffer" | "sharedBill"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      SharedUser: {
        payload: Prisma.$SharedUserPayload<ExtArgs>
        fields: Prisma.SharedUserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SharedUserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SharedUserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload>
          }
          findFirst: {
            args: Prisma.SharedUserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SharedUserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload>
          }
          findMany: {
            args: Prisma.SharedUserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload>[]
          }
          create: {
            args: Prisma.SharedUserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload>
          }
          createMany: {
            args: Prisma.SharedUserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SharedUserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload>
          }
          update: {
            args: Prisma.SharedUserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload>
          }
          deleteMany: {
            args: Prisma.SharedUserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SharedUserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SharedUserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedUserPayload>
          }
          aggregate: {
            args: Prisma.SharedUserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSharedUser>
          }
          groupBy: {
            args: Prisma.SharedUserGroupByArgs<ExtArgs>
            result: $Utils.Optional<SharedUserGroupByOutputType>[]
          }
          count: {
            args: Prisma.SharedUserCountArgs<ExtArgs>
            result: $Utils.Optional<SharedUserCountAggregateOutputType> | number
          }
        }
      }
      SharedVendor: {
        payload: Prisma.$SharedVendorPayload<ExtArgs>
        fields: Prisma.SharedVendorFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SharedVendorFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SharedVendorFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload>
          }
          findFirst: {
            args: Prisma.SharedVendorFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SharedVendorFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload>
          }
          findMany: {
            args: Prisma.SharedVendorFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload>[]
          }
          create: {
            args: Prisma.SharedVendorCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload>
          }
          createMany: {
            args: Prisma.SharedVendorCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SharedVendorDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload>
          }
          update: {
            args: Prisma.SharedVendorUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload>
          }
          deleteMany: {
            args: Prisma.SharedVendorDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SharedVendorUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SharedVendorUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedVendorPayload>
          }
          aggregate: {
            args: Prisma.SharedVendorAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSharedVendor>
          }
          groupBy: {
            args: Prisma.SharedVendorGroupByArgs<ExtArgs>
            result: $Utils.Optional<SharedVendorGroupByOutputType>[]
          }
          count: {
            args: Prisma.SharedVendorCountArgs<ExtArgs>
            result: $Utils.Optional<SharedVendorCountAggregateOutputType> | number
          }
        }
      }
      SharedPost: {
        payload: Prisma.$SharedPostPayload<ExtArgs>
        fields: Prisma.SharedPostFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SharedPostFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SharedPostFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload>
          }
          findFirst: {
            args: Prisma.SharedPostFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SharedPostFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload>
          }
          findMany: {
            args: Prisma.SharedPostFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload>[]
          }
          create: {
            args: Prisma.SharedPostCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload>
          }
          createMany: {
            args: Prisma.SharedPostCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SharedPostDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload>
          }
          update: {
            args: Prisma.SharedPostUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload>
          }
          deleteMany: {
            args: Prisma.SharedPostDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SharedPostUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SharedPostUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedPostPayload>
          }
          aggregate: {
            args: Prisma.SharedPostAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSharedPost>
          }
          groupBy: {
            args: Prisma.SharedPostGroupByArgs<ExtArgs>
            result: $Utils.Optional<SharedPostGroupByOutputType>[]
          }
          count: {
            args: Prisma.SharedPostCountArgs<ExtArgs>
            result: $Utils.Optional<SharedPostCountAggregateOutputType> | number
          }
        }
      }
      SharedMenuCategory: {
        payload: Prisma.$SharedMenuCategoryPayload<ExtArgs>
        fields: Prisma.SharedMenuCategoryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SharedMenuCategoryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SharedMenuCategoryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload>
          }
          findFirst: {
            args: Prisma.SharedMenuCategoryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SharedMenuCategoryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload>
          }
          findMany: {
            args: Prisma.SharedMenuCategoryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload>[]
          }
          create: {
            args: Prisma.SharedMenuCategoryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload>
          }
          createMany: {
            args: Prisma.SharedMenuCategoryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SharedMenuCategoryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload>
          }
          update: {
            args: Prisma.SharedMenuCategoryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload>
          }
          deleteMany: {
            args: Prisma.SharedMenuCategoryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SharedMenuCategoryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SharedMenuCategoryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuCategoryPayload>
          }
          aggregate: {
            args: Prisma.SharedMenuCategoryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSharedMenuCategory>
          }
          groupBy: {
            args: Prisma.SharedMenuCategoryGroupByArgs<ExtArgs>
            result: $Utils.Optional<SharedMenuCategoryGroupByOutputType>[]
          }
          count: {
            args: Prisma.SharedMenuCategoryCountArgs<ExtArgs>
            result: $Utils.Optional<SharedMenuCategoryCountAggregateOutputType> | number
          }
        }
      }
      SharedMenuSubCategory: {
        payload: Prisma.$SharedMenuSubCategoryPayload<ExtArgs>
        fields: Prisma.SharedMenuSubCategoryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SharedMenuSubCategoryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SharedMenuSubCategoryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload>
          }
          findFirst: {
            args: Prisma.SharedMenuSubCategoryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SharedMenuSubCategoryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload>
          }
          findMany: {
            args: Prisma.SharedMenuSubCategoryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload>[]
          }
          create: {
            args: Prisma.SharedMenuSubCategoryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload>
          }
          createMany: {
            args: Prisma.SharedMenuSubCategoryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SharedMenuSubCategoryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload>
          }
          update: {
            args: Prisma.SharedMenuSubCategoryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload>
          }
          deleteMany: {
            args: Prisma.SharedMenuSubCategoryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SharedMenuSubCategoryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SharedMenuSubCategoryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuSubCategoryPayload>
          }
          aggregate: {
            args: Prisma.SharedMenuSubCategoryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSharedMenuSubCategory>
          }
          groupBy: {
            args: Prisma.SharedMenuSubCategoryGroupByArgs<ExtArgs>
            result: $Utils.Optional<SharedMenuSubCategoryGroupByOutputType>[]
          }
          count: {
            args: Prisma.SharedMenuSubCategoryCountArgs<ExtArgs>
            result: $Utils.Optional<SharedMenuSubCategoryCountAggregateOutputType> | number
          }
        }
      }
      SharedMenuItem: {
        payload: Prisma.$SharedMenuItemPayload<ExtArgs>
        fields: Prisma.SharedMenuItemFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SharedMenuItemFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SharedMenuItemFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload>
          }
          findFirst: {
            args: Prisma.SharedMenuItemFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SharedMenuItemFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload>
          }
          findMany: {
            args: Prisma.SharedMenuItemFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload>[]
          }
          create: {
            args: Prisma.SharedMenuItemCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload>
          }
          createMany: {
            args: Prisma.SharedMenuItemCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SharedMenuItemDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload>
          }
          update: {
            args: Prisma.SharedMenuItemUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload>
          }
          deleteMany: {
            args: Prisma.SharedMenuItemDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SharedMenuItemUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SharedMenuItemUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedMenuItemPayload>
          }
          aggregate: {
            args: Prisma.SharedMenuItemAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSharedMenuItem>
          }
          groupBy: {
            args: Prisma.SharedMenuItemGroupByArgs<ExtArgs>
            result: $Utils.Optional<SharedMenuItemGroupByOutputType>[]
          }
          count: {
            args: Prisma.SharedMenuItemCountArgs<ExtArgs>
            result: $Utils.Optional<SharedMenuItemCountAggregateOutputType> | number
          }
        }
      }
      SharedOffer: {
        payload: Prisma.$SharedOfferPayload<ExtArgs>
        fields: Prisma.SharedOfferFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SharedOfferFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SharedOfferFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload>
          }
          findFirst: {
            args: Prisma.SharedOfferFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SharedOfferFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload>
          }
          findMany: {
            args: Prisma.SharedOfferFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload>[]
          }
          create: {
            args: Prisma.SharedOfferCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload>
          }
          createMany: {
            args: Prisma.SharedOfferCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SharedOfferDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload>
          }
          update: {
            args: Prisma.SharedOfferUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload>
          }
          deleteMany: {
            args: Prisma.SharedOfferDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SharedOfferUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SharedOfferUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedOfferPayload>
          }
          aggregate: {
            args: Prisma.SharedOfferAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSharedOffer>
          }
          groupBy: {
            args: Prisma.SharedOfferGroupByArgs<ExtArgs>
            result: $Utils.Optional<SharedOfferGroupByOutputType>[]
          }
          count: {
            args: Prisma.SharedOfferCountArgs<ExtArgs>
            result: $Utils.Optional<SharedOfferCountAggregateOutputType> | number
          }
        }
      }
      SharedBill: {
        payload: Prisma.$SharedBillPayload<ExtArgs>
        fields: Prisma.SharedBillFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SharedBillFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SharedBillFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload>
          }
          findFirst: {
            args: Prisma.SharedBillFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SharedBillFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload>
          }
          findMany: {
            args: Prisma.SharedBillFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload>[]
          }
          create: {
            args: Prisma.SharedBillCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload>
          }
          createMany: {
            args: Prisma.SharedBillCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SharedBillDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload>
          }
          update: {
            args: Prisma.SharedBillUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload>
          }
          deleteMany: {
            args: Prisma.SharedBillDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SharedBillUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SharedBillUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SharedBillPayload>
          }
          aggregate: {
            args: Prisma.SharedBillAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSharedBill>
          }
          groupBy: {
            args: Prisma.SharedBillGroupByArgs<ExtArgs>
            result: $Utils.Optional<SharedBillGroupByOutputType>[]
          }
          count: {
            args: Prisma.SharedBillCountArgs<ExtArgs>
            result: $Utils.Optional<SharedBillCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory | null
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    sharedUser?: SharedUserOmit
    sharedVendor?: SharedVendorOmit
    sharedPost?: SharedPostOmit
    sharedMenuCategory?: SharedMenuCategoryOmit
    sharedMenuSubCategory?: SharedMenuSubCategoryOmit
    sharedMenuItem?: SharedMenuItemOmit
    sharedOffer?: SharedOfferOmit
    sharedBill?: SharedBillOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type SharedUserCountOutputType
   */

  export type SharedUserCountOutputType = {
    vendors: number
    bills: number
  }

  export type SharedUserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendors?: boolean | SharedUserCountOutputTypeCountVendorsArgs
    bills?: boolean | SharedUserCountOutputTypeCountBillsArgs
  }

  // Custom InputTypes
  /**
   * SharedUserCountOutputType without action
   */
  export type SharedUserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUserCountOutputType
     */
    select?: SharedUserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * SharedUserCountOutputType without action
   */
  export type SharedUserCountOutputTypeCountVendorsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedVendorWhereInput
  }

  /**
   * SharedUserCountOutputType without action
   */
  export type SharedUserCountOutputTypeCountBillsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedBillWhereInput
  }


  /**
   * Count Type SharedVendorCountOutputType
   */

  export type SharedVendorCountOutputType = {
    posts: number
    menuCategories: number
    menuSubCategories: number
    menuItems: number
    offers: number
    bills: number
  }

  export type SharedVendorCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    posts?: boolean | SharedVendorCountOutputTypeCountPostsArgs
    menuCategories?: boolean | SharedVendorCountOutputTypeCountMenuCategoriesArgs
    menuSubCategories?: boolean | SharedVendorCountOutputTypeCountMenuSubCategoriesArgs
    menuItems?: boolean | SharedVendorCountOutputTypeCountMenuItemsArgs
    offers?: boolean | SharedVendorCountOutputTypeCountOffersArgs
    bills?: boolean | SharedVendorCountOutputTypeCountBillsArgs
  }

  // Custom InputTypes
  /**
   * SharedVendorCountOutputType without action
   */
  export type SharedVendorCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendorCountOutputType
     */
    select?: SharedVendorCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * SharedVendorCountOutputType without action
   */
  export type SharedVendorCountOutputTypeCountPostsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedPostWhereInput
  }

  /**
   * SharedVendorCountOutputType without action
   */
  export type SharedVendorCountOutputTypeCountMenuCategoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuCategoryWhereInput
  }

  /**
   * SharedVendorCountOutputType without action
   */
  export type SharedVendorCountOutputTypeCountMenuSubCategoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuSubCategoryWhereInput
  }

  /**
   * SharedVendorCountOutputType without action
   */
  export type SharedVendorCountOutputTypeCountMenuItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuItemWhereInput
  }

  /**
   * SharedVendorCountOutputType without action
   */
  export type SharedVendorCountOutputTypeCountOffersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedOfferWhereInput
  }

  /**
   * SharedVendorCountOutputType without action
   */
  export type SharedVendorCountOutputTypeCountBillsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedBillWhereInput
  }


  /**
   * Count Type SharedMenuCategoryCountOutputType
   */

  export type SharedMenuCategoryCountOutputType = {
    subCategories: number
    items: number
  }

  export type SharedMenuCategoryCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    subCategories?: boolean | SharedMenuCategoryCountOutputTypeCountSubCategoriesArgs
    items?: boolean | SharedMenuCategoryCountOutputTypeCountItemsArgs
  }

  // Custom InputTypes
  /**
   * SharedMenuCategoryCountOutputType without action
   */
  export type SharedMenuCategoryCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategoryCountOutputType
     */
    select?: SharedMenuCategoryCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * SharedMenuCategoryCountOutputType without action
   */
  export type SharedMenuCategoryCountOutputTypeCountSubCategoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuSubCategoryWhereInput
  }

  /**
   * SharedMenuCategoryCountOutputType without action
   */
  export type SharedMenuCategoryCountOutputTypeCountItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuItemWhereInput
  }


  /**
   * Count Type SharedMenuSubCategoryCountOutputType
   */

  export type SharedMenuSubCategoryCountOutputType = {
    items: number
  }

  export type SharedMenuSubCategoryCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    items?: boolean | SharedMenuSubCategoryCountOutputTypeCountItemsArgs
  }

  // Custom InputTypes
  /**
   * SharedMenuSubCategoryCountOutputType without action
   */
  export type SharedMenuSubCategoryCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategoryCountOutputType
     */
    select?: SharedMenuSubCategoryCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * SharedMenuSubCategoryCountOutputType without action
   */
  export type SharedMenuSubCategoryCountOutputTypeCountItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuItemWhereInput
  }


  /**
   * Count Type SharedOfferCountOutputType
   */

  export type SharedOfferCountOutputType = {
    posts: number
  }

  export type SharedOfferCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    posts?: boolean | SharedOfferCountOutputTypeCountPostsArgs
  }

  // Custom InputTypes
  /**
   * SharedOfferCountOutputType without action
   */
  export type SharedOfferCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOfferCountOutputType
     */
    select?: SharedOfferCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * SharedOfferCountOutputType without action
   */
  export type SharedOfferCountOutputTypeCountPostsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedPostWhereInput
  }


  /**
   * Models
   */

  /**
   * Model SharedUser
   */

  export type AggregateSharedUser = {
    _count: SharedUserCountAggregateOutputType | null
    _avg: SharedUserAvgAggregateOutputType | null
    _sum: SharedUserSumAggregateOutputType | null
    _min: SharedUserMinAggregateOutputType | null
    _max: SharedUserMaxAggregateOutputType | null
  }

  export type SharedUserAvgAggregateOutputType = {
    id: number | null
  }

  export type SharedUserSumAggregateOutputType = {
    id: number | null
  }

  export type SharedUserMinAggregateOutputType = {
    id: number | null
    phoneNumber: string | null
    userType: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedUserMaxAggregateOutputType = {
    id: number | null
    phoneNumber: string | null
    userType: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedUserCountAggregateOutputType = {
    id: number
    phoneNumber: number
    userType: number
    status: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SharedUserAvgAggregateInputType = {
    id?: true
  }

  export type SharedUserSumAggregateInputType = {
    id?: true
  }

  export type SharedUserMinAggregateInputType = {
    id?: true
    phoneNumber?: true
    userType?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedUserMaxAggregateInputType = {
    id?: true
    phoneNumber?: true
    userType?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedUserCountAggregateInputType = {
    id?: true
    phoneNumber?: true
    userType?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SharedUserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedUser to aggregate.
     */
    where?: SharedUserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedUsers to fetch.
     */
    orderBy?: SharedUserOrderByWithRelationInput | SharedUserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SharedUserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedUsers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedUsers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SharedUsers
    **/
    _count?: true | SharedUserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SharedUserAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SharedUserSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SharedUserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SharedUserMaxAggregateInputType
  }

  export type GetSharedUserAggregateType<T extends SharedUserAggregateArgs> = {
        [P in keyof T & keyof AggregateSharedUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSharedUser[P]>
      : GetScalarType<T[P], AggregateSharedUser[P]>
  }




  export type SharedUserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedUserWhereInput
    orderBy?: SharedUserOrderByWithAggregationInput | SharedUserOrderByWithAggregationInput[]
    by: SharedUserScalarFieldEnum[] | SharedUserScalarFieldEnum
    having?: SharedUserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SharedUserCountAggregateInputType | true
    _avg?: SharedUserAvgAggregateInputType
    _sum?: SharedUserSumAggregateInputType
    _min?: SharedUserMinAggregateInputType
    _max?: SharedUserMaxAggregateInputType
  }

  export type SharedUserGroupByOutputType = {
    id: number
    phoneNumber: string
    userType: string
    status: string
    createdAt: Date | null
    updatedAt: Date | null
    _count: SharedUserCountAggregateOutputType | null
    _avg: SharedUserAvgAggregateOutputType | null
    _sum: SharedUserSumAggregateOutputType | null
    _min: SharedUserMinAggregateOutputType | null
    _max: SharedUserMaxAggregateOutputType | null
  }

  type GetSharedUserGroupByPayload<T extends SharedUserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SharedUserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SharedUserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SharedUserGroupByOutputType[P]>
            : GetScalarType<T[P], SharedUserGroupByOutputType[P]>
        }
      >
    >


  export type SharedUserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    phoneNumber?: boolean
    userType?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    vendors?: boolean | SharedUser$vendorsArgs<ExtArgs>
    bills?: boolean | SharedUser$billsArgs<ExtArgs>
    _count?: boolean | SharedUserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["sharedUser"]>



  export type SharedUserSelectScalar = {
    id?: boolean
    phoneNumber?: boolean
    userType?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SharedUserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "phoneNumber" | "userType" | "status" | "createdAt" | "updatedAt", ExtArgs["result"]["sharedUser"]>
  export type SharedUserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendors?: boolean | SharedUser$vendorsArgs<ExtArgs>
    bills?: boolean | SharedUser$billsArgs<ExtArgs>
    _count?: boolean | SharedUserCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $SharedUserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SharedUser"
    objects: {
      vendors: Prisma.$SharedVendorPayload<ExtArgs>[]
      bills: Prisma.$SharedBillPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      phoneNumber: string
      userType: string
      status: string
      createdAt: Date | null
      updatedAt: Date | null
    }, ExtArgs["result"]["sharedUser"]>
    composites: {}
  }

  type SharedUserGetPayload<S extends boolean | null | undefined | SharedUserDefaultArgs> = $Result.GetResult<Prisma.$SharedUserPayload, S>

  type SharedUserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SharedUserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SharedUserCountAggregateInputType | true
    }

  export interface SharedUserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SharedUser'], meta: { name: 'SharedUser' } }
    /**
     * Find zero or one SharedUser that matches the filter.
     * @param {SharedUserFindUniqueArgs} args - Arguments to find a SharedUser
     * @example
     * // Get one SharedUser
     * const sharedUser = await prisma.sharedUser.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SharedUserFindUniqueArgs>(args: SelectSubset<T, SharedUserFindUniqueArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SharedUser that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SharedUserFindUniqueOrThrowArgs} args - Arguments to find a SharedUser
     * @example
     * // Get one SharedUser
     * const sharedUser = await prisma.sharedUser.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SharedUserFindUniqueOrThrowArgs>(args: SelectSubset<T, SharedUserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedUser that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedUserFindFirstArgs} args - Arguments to find a SharedUser
     * @example
     * // Get one SharedUser
     * const sharedUser = await prisma.sharedUser.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SharedUserFindFirstArgs>(args?: SelectSubset<T, SharedUserFindFirstArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedUser that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedUserFindFirstOrThrowArgs} args - Arguments to find a SharedUser
     * @example
     * // Get one SharedUser
     * const sharedUser = await prisma.sharedUser.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SharedUserFindFirstOrThrowArgs>(args?: SelectSubset<T, SharedUserFindFirstOrThrowArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SharedUsers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedUserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SharedUsers
     * const sharedUsers = await prisma.sharedUser.findMany()
     * 
     * // Get first 10 SharedUsers
     * const sharedUsers = await prisma.sharedUser.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sharedUserWithIdOnly = await prisma.sharedUser.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SharedUserFindManyArgs>(args?: SelectSubset<T, SharedUserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SharedUser.
     * @param {SharedUserCreateArgs} args - Arguments to create a SharedUser.
     * @example
     * // Create one SharedUser
     * const SharedUser = await prisma.sharedUser.create({
     *   data: {
     *     // ... data to create a SharedUser
     *   }
     * })
     * 
     */
    create<T extends SharedUserCreateArgs>(args: SelectSubset<T, SharedUserCreateArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SharedUsers.
     * @param {SharedUserCreateManyArgs} args - Arguments to create many SharedUsers.
     * @example
     * // Create many SharedUsers
     * const sharedUser = await prisma.sharedUser.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SharedUserCreateManyArgs>(args?: SelectSubset<T, SharedUserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SharedUser.
     * @param {SharedUserDeleteArgs} args - Arguments to delete one SharedUser.
     * @example
     * // Delete one SharedUser
     * const SharedUser = await prisma.sharedUser.delete({
     *   where: {
     *     // ... filter to delete one SharedUser
     *   }
     * })
     * 
     */
    delete<T extends SharedUserDeleteArgs>(args: SelectSubset<T, SharedUserDeleteArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SharedUser.
     * @param {SharedUserUpdateArgs} args - Arguments to update one SharedUser.
     * @example
     * // Update one SharedUser
     * const sharedUser = await prisma.sharedUser.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SharedUserUpdateArgs>(args: SelectSubset<T, SharedUserUpdateArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SharedUsers.
     * @param {SharedUserDeleteManyArgs} args - Arguments to filter SharedUsers to delete.
     * @example
     * // Delete a few SharedUsers
     * const { count } = await prisma.sharedUser.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SharedUserDeleteManyArgs>(args?: SelectSubset<T, SharedUserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SharedUsers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedUserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SharedUsers
     * const sharedUser = await prisma.sharedUser.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SharedUserUpdateManyArgs>(args: SelectSubset<T, SharedUserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SharedUser.
     * @param {SharedUserUpsertArgs} args - Arguments to update or create a SharedUser.
     * @example
     * // Update or create a SharedUser
     * const sharedUser = await prisma.sharedUser.upsert({
     *   create: {
     *     // ... data to create a SharedUser
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SharedUser we want to update
     *   }
     * })
     */
    upsert<T extends SharedUserUpsertArgs>(args: SelectSubset<T, SharedUserUpsertArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SharedUsers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedUserCountArgs} args - Arguments to filter SharedUsers to count.
     * @example
     * // Count the number of SharedUsers
     * const count = await prisma.sharedUser.count({
     *   where: {
     *     // ... the filter for the SharedUsers we want to count
     *   }
     * })
    **/
    count<T extends SharedUserCountArgs>(
      args?: Subset<T, SharedUserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SharedUserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SharedUser.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedUserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SharedUserAggregateArgs>(args: Subset<T, SharedUserAggregateArgs>): Prisma.PrismaPromise<GetSharedUserAggregateType<T>>

    /**
     * Group by SharedUser.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedUserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SharedUserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SharedUserGroupByArgs['orderBy'] }
        : { orderBy?: SharedUserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SharedUserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSharedUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SharedUser model
   */
  readonly fields: SharedUserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SharedUser.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SharedUserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    vendors<T extends SharedUser$vendorsArgs<ExtArgs> = {}>(args?: Subset<T, SharedUser$vendorsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    bills<T extends SharedUser$billsArgs<ExtArgs> = {}>(args?: Subset<T, SharedUser$billsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SharedUser model
   */
  interface SharedUserFieldRefs {
    readonly id: FieldRef<"SharedUser", 'Int'>
    readonly phoneNumber: FieldRef<"SharedUser", 'String'>
    readonly userType: FieldRef<"SharedUser", 'String'>
    readonly status: FieldRef<"SharedUser", 'String'>
    readonly createdAt: FieldRef<"SharedUser", 'DateTime'>
    readonly updatedAt: FieldRef<"SharedUser", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SharedUser findUnique
   */
  export type SharedUserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * Filter, which SharedUser to fetch.
     */
    where: SharedUserWhereUniqueInput
  }

  /**
   * SharedUser findUniqueOrThrow
   */
  export type SharedUserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * Filter, which SharedUser to fetch.
     */
    where: SharedUserWhereUniqueInput
  }

  /**
   * SharedUser findFirst
   */
  export type SharedUserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * Filter, which SharedUser to fetch.
     */
    where?: SharedUserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedUsers to fetch.
     */
    orderBy?: SharedUserOrderByWithRelationInput | SharedUserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedUsers.
     */
    cursor?: SharedUserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedUsers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedUsers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedUsers.
     */
    distinct?: SharedUserScalarFieldEnum | SharedUserScalarFieldEnum[]
  }

  /**
   * SharedUser findFirstOrThrow
   */
  export type SharedUserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * Filter, which SharedUser to fetch.
     */
    where?: SharedUserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedUsers to fetch.
     */
    orderBy?: SharedUserOrderByWithRelationInput | SharedUserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedUsers.
     */
    cursor?: SharedUserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedUsers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedUsers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedUsers.
     */
    distinct?: SharedUserScalarFieldEnum | SharedUserScalarFieldEnum[]
  }

  /**
   * SharedUser findMany
   */
  export type SharedUserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * Filter, which SharedUsers to fetch.
     */
    where?: SharedUserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedUsers to fetch.
     */
    orderBy?: SharedUserOrderByWithRelationInput | SharedUserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SharedUsers.
     */
    cursor?: SharedUserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedUsers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedUsers.
     */
    skip?: number
    distinct?: SharedUserScalarFieldEnum | SharedUserScalarFieldEnum[]
  }

  /**
   * SharedUser create
   */
  export type SharedUserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * The data needed to create a SharedUser.
     */
    data: XOR<SharedUserCreateInput, SharedUserUncheckedCreateInput>
  }

  /**
   * SharedUser createMany
   */
  export type SharedUserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SharedUsers.
     */
    data: SharedUserCreateManyInput | SharedUserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SharedUser update
   */
  export type SharedUserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * The data needed to update a SharedUser.
     */
    data: XOR<SharedUserUpdateInput, SharedUserUncheckedUpdateInput>
    /**
     * Choose, which SharedUser to update.
     */
    where: SharedUserWhereUniqueInput
  }

  /**
   * SharedUser updateMany
   */
  export type SharedUserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SharedUsers.
     */
    data: XOR<SharedUserUpdateManyMutationInput, SharedUserUncheckedUpdateManyInput>
    /**
     * Filter which SharedUsers to update
     */
    where?: SharedUserWhereInput
    /**
     * Limit how many SharedUsers to update.
     */
    limit?: number
  }

  /**
   * SharedUser upsert
   */
  export type SharedUserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * The filter to search for the SharedUser to update in case it exists.
     */
    where: SharedUserWhereUniqueInput
    /**
     * In case the SharedUser found by the `where` argument doesn't exist, create a new SharedUser with this data.
     */
    create: XOR<SharedUserCreateInput, SharedUserUncheckedCreateInput>
    /**
     * In case the SharedUser was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SharedUserUpdateInput, SharedUserUncheckedUpdateInput>
  }

  /**
   * SharedUser delete
   */
  export type SharedUserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    /**
     * Filter which SharedUser to delete.
     */
    where: SharedUserWhereUniqueInput
  }

  /**
   * SharedUser deleteMany
   */
  export type SharedUserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedUsers to delete
     */
    where?: SharedUserWhereInput
    /**
     * Limit how many SharedUsers to delete.
     */
    limit?: number
  }

  /**
   * SharedUser.vendors
   */
  export type SharedUser$vendorsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    where?: SharedVendorWhereInput
    orderBy?: SharedVendorOrderByWithRelationInput | SharedVendorOrderByWithRelationInput[]
    cursor?: SharedVendorWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedVendorScalarFieldEnum | SharedVendorScalarFieldEnum[]
  }

  /**
   * SharedUser.bills
   */
  export type SharedUser$billsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    where?: SharedBillWhereInput
    orderBy?: SharedBillOrderByWithRelationInput | SharedBillOrderByWithRelationInput[]
    cursor?: SharedBillWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedBillScalarFieldEnum | SharedBillScalarFieldEnum[]
  }

  /**
   * SharedUser without action
   */
  export type SharedUserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
  }


  /**
   * Model SharedVendor
   */

  export type AggregateSharedVendor = {
    _count: SharedVendorCountAggregateOutputType | null
    _avg: SharedVendorAvgAggregateOutputType | null
    _sum: SharedVendorSumAggregateOutputType | null
    _min: SharedVendorMinAggregateOutputType | null
    _max: SharedVendorMaxAggregateOutputType | null
  }

  export type SharedVendorAvgAggregateOutputType = {
    id: number | null
    userId: number | null
  }

  export type SharedVendorSumAggregateOutputType = {
    id: number | null
    userId: number | null
  }

  export type SharedVendorMinAggregateOutputType = {
    id: number | null
    userId: number | null
    businessName: string | null
    status: string | null
    logoUrl: string | null
    businessCategory: string | null
    address: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedVendorMaxAggregateOutputType = {
    id: number | null
    userId: number | null
    businessName: string | null
    status: string | null
    logoUrl: string | null
    businessCategory: string | null
    address: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedVendorCountAggregateOutputType = {
    id: number
    userId: number
    businessName: number
    status: number
    logoUrl: number
    businessCategory: number
    address: number
    payment: number
    workingDays: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SharedVendorAvgAggregateInputType = {
    id?: true
    userId?: true
  }

  export type SharedVendorSumAggregateInputType = {
    id?: true
    userId?: true
  }

  export type SharedVendorMinAggregateInputType = {
    id?: true
    userId?: true
    businessName?: true
    status?: true
    logoUrl?: true
    businessCategory?: true
    address?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedVendorMaxAggregateInputType = {
    id?: true
    userId?: true
    businessName?: true
    status?: true
    logoUrl?: true
    businessCategory?: true
    address?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedVendorCountAggregateInputType = {
    id?: true
    userId?: true
    businessName?: true
    status?: true
    logoUrl?: true
    businessCategory?: true
    address?: true
    payment?: true
    workingDays?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SharedVendorAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedVendor to aggregate.
     */
    where?: SharedVendorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedVendors to fetch.
     */
    orderBy?: SharedVendorOrderByWithRelationInput | SharedVendorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SharedVendorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedVendors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedVendors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SharedVendors
    **/
    _count?: true | SharedVendorCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SharedVendorAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SharedVendorSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SharedVendorMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SharedVendorMaxAggregateInputType
  }

  export type GetSharedVendorAggregateType<T extends SharedVendorAggregateArgs> = {
        [P in keyof T & keyof AggregateSharedVendor]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSharedVendor[P]>
      : GetScalarType<T[P], AggregateSharedVendor[P]>
  }




  export type SharedVendorGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedVendorWhereInput
    orderBy?: SharedVendorOrderByWithAggregationInput | SharedVendorOrderByWithAggregationInput[]
    by: SharedVendorScalarFieldEnum[] | SharedVendorScalarFieldEnum
    having?: SharedVendorScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SharedVendorCountAggregateInputType | true
    _avg?: SharedVendorAvgAggregateInputType
    _sum?: SharedVendorSumAggregateInputType
    _min?: SharedVendorMinAggregateInputType
    _max?: SharedVendorMaxAggregateInputType
  }

  export type SharedVendorGroupByOutputType = {
    id: number
    userId: number
    businessName: string | null
    status: string
    logoUrl: string | null
    businessCategory: string | null
    address: string | null
    payment: JsonValue | null
    workingDays: JsonValue | null
    createdAt: Date | null
    updatedAt: Date | null
    _count: SharedVendorCountAggregateOutputType | null
    _avg: SharedVendorAvgAggregateOutputType | null
    _sum: SharedVendorSumAggregateOutputType | null
    _min: SharedVendorMinAggregateOutputType | null
    _max: SharedVendorMaxAggregateOutputType | null
  }

  type GetSharedVendorGroupByPayload<T extends SharedVendorGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SharedVendorGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SharedVendorGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SharedVendorGroupByOutputType[P]>
            : GetScalarType<T[P], SharedVendorGroupByOutputType[P]>
        }
      >
    >


  export type SharedVendorSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    businessName?: boolean
    status?: boolean
    logoUrl?: boolean
    businessCategory?: boolean
    address?: boolean
    payment?: boolean
    workingDays?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | SharedUserDefaultArgs<ExtArgs>
    posts?: boolean | SharedVendor$postsArgs<ExtArgs>
    menuCategories?: boolean | SharedVendor$menuCategoriesArgs<ExtArgs>
    menuSubCategories?: boolean | SharedVendor$menuSubCategoriesArgs<ExtArgs>
    menuItems?: boolean | SharedVendor$menuItemsArgs<ExtArgs>
    offers?: boolean | SharedVendor$offersArgs<ExtArgs>
    bills?: boolean | SharedVendor$billsArgs<ExtArgs>
    _count?: boolean | SharedVendorCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["sharedVendor"]>



  export type SharedVendorSelectScalar = {
    id?: boolean
    userId?: boolean
    businessName?: boolean
    status?: boolean
    logoUrl?: boolean
    businessCategory?: boolean
    address?: boolean
    payment?: boolean
    workingDays?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SharedVendorOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "businessName" | "status" | "logoUrl" | "businessCategory" | "address" | "payment" | "workingDays" | "createdAt" | "updatedAt", ExtArgs["result"]["sharedVendor"]>
  export type SharedVendorInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | SharedUserDefaultArgs<ExtArgs>
    posts?: boolean | SharedVendor$postsArgs<ExtArgs>
    menuCategories?: boolean | SharedVendor$menuCategoriesArgs<ExtArgs>
    menuSubCategories?: boolean | SharedVendor$menuSubCategoriesArgs<ExtArgs>
    menuItems?: boolean | SharedVendor$menuItemsArgs<ExtArgs>
    offers?: boolean | SharedVendor$offersArgs<ExtArgs>
    bills?: boolean | SharedVendor$billsArgs<ExtArgs>
    _count?: boolean | SharedVendorCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $SharedVendorPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SharedVendor"
    objects: {
      user: Prisma.$SharedUserPayload<ExtArgs>
      posts: Prisma.$SharedPostPayload<ExtArgs>[]
      menuCategories: Prisma.$SharedMenuCategoryPayload<ExtArgs>[]
      menuSubCategories: Prisma.$SharedMenuSubCategoryPayload<ExtArgs>[]
      menuItems: Prisma.$SharedMenuItemPayload<ExtArgs>[]
      offers: Prisma.$SharedOfferPayload<ExtArgs>[]
      bills: Prisma.$SharedBillPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      userId: number
      businessName: string | null
      status: string
      logoUrl: string | null
      businessCategory: string | null
      address: string | null
      payment: Prisma.JsonValue | null
      workingDays: Prisma.JsonValue | null
      createdAt: Date | null
      updatedAt: Date | null
    }, ExtArgs["result"]["sharedVendor"]>
    composites: {}
  }

  type SharedVendorGetPayload<S extends boolean | null | undefined | SharedVendorDefaultArgs> = $Result.GetResult<Prisma.$SharedVendorPayload, S>

  type SharedVendorCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SharedVendorFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SharedVendorCountAggregateInputType | true
    }

  export interface SharedVendorDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SharedVendor'], meta: { name: 'SharedVendor' } }
    /**
     * Find zero or one SharedVendor that matches the filter.
     * @param {SharedVendorFindUniqueArgs} args - Arguments to find a SharedVendor
     * @example
     * // Get one SharedVendor
     * const sharedVendor = await prisma.sharedVendor.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SharedVendorFindUniqueArgs>(args: SelectSubset<T, SharedVendorFindUniqueArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SharedVendor that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SharedVendorFindUniqueOrThrowArgs} args - Arguments to find a SharedVendor
     * @example
     * // Get one SharedVendor
     * const sharedVendor = await prisma.sharedVendor.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SharedVendorFindUniqueOrThrowArgs>(args: SelectSubset<T, SharedVendorFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedVendor that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedVendorFindFirstArgs} args - Arguments to find a SharedVendor
     * @example
     * // Get one SharedVendor
     * const sharedVendor = await prisma.sharedVendor.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SharedVendorFindFirstArgs>(args?: SelectSubset<T, SharedVendorFindFirstArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedVendor that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedVendorFindFirstOrThrowArgs} args - Arguments to find a SharedVendor
     * @example
     * // Get one SharedVendor
     * const sharedVendor = await prisma.sharedVendor.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SharedVendorFindFirstOrThrowArgs>(args?: SelectSubset<T, SharedVendorFindFirstOrThrowArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SharedVendors that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedVendorFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SharedVendors
     * const sharedVendors = await prisma.sharedVendor.findMany()
     * 
     * // Get first 10 SharedVendors
     * const sharedVendors = await prisma.sharedVendor.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sharedVendorWithIdOnly = await prisma.sharedVendor.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SharedVendorFindManyArgs>(args?: SelectSubset<T, SharedVendorFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SharedVendor.
     * @param {SharedVendorCreateArgs} args - Arguments to create a SharedVendor.
     * @example
     * // Create one SharedVendor
     * const SharedVendor = await prisma.sharedVendor.create({
     *   data: {
     *     // ... data to create a SharedVendor
     *   }
     * })
     * 
     */
    create<T extends SharedVendorCreateArgs>(args: SelectSubset<T, SharedVendorCreateArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SharedVendors.
     * @param {SharedVendorCreateManyArgs} args - Arguments to create many SharedVendors.
     * @example
     * // Create many SharedVendors
     * const sharedVendor = await prisma.sharedVendor.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SharedVendorCreateManyArgs>(args?: SelectSubset<T, SharedVendorCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SharedVendor.
     * @param {SharedVendorDeleteArgs} args - Arguments to delete one SharedVendor.
     * @example
     * // Delete one SharedVendor
     * const SharedVendor = await prisma.sharedVendor.delete({
     *   where: {
     *     // ... filter to delete one SharedVendor
     *   }
     * })
     * 
     */
    delete<T extends SharedVendorDeleteArgs>(args: SelectSubset<T, SharedVendorDeleteArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SharedVendor.
     * @param {SharedVendorUpdateArgs} args - Arguments to update one SharedVendor.
     * @example
     * // Update one SharedVendor
     * const sharedVendor = await prisma.sharedVendor.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SharedVendorUpdateArgs>(args: SelectSubset<T, SharedVendorUpdateArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SharedVendors.
     * @param {SharedVendorDeleteManyArgs} args - Arguments to filter SharedVendors to delete.
     * @example
     * // Delete a few SharedVendors
     * const { count } = await prisma.sharedVendor.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SharedVendorDeleteManyArgs>(args?: SelectSubset<T, SharedVendorDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SharedVendors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedVendorUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SharedVendors
     * const sharedVendor = await prisma.sharedVendor.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SharedVendorUpdateManyArgs>(args: SelectSubset<T, SharedVendorUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SharedVendor.
     * @param {SharedVendorUpsertArgs} args - Arguments to update or create a SharedVendor.
     * @example
     * // Update or create a SharedVendor
     * const sharedVendor = await prisma.sharedVendor.upsert({
     *   create: {
     *     // ... data to create a SharedVendor
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SharedVendor we want to update
     *   }
     * })
     */
    upsert<T extends SharedVendorUpsertArgs>(args: SelectSubset<T, SharedVendorUpsertArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SharedVendors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedVendorCountArgs} args - Arguments to filter SharedVendors to count.
     * @example
     * // Count the number of SharedVendors
     * const count = await prisma.sharedVendor.count({
     *   where: {
     *     // ... the filter for the SharedVendors we want to count
     *   }
     * })
    **/
    count<T extends SharedVendorCountArgs>(
      args?: Subset<T, SharedVendorCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SharedVendorCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SharedVendor.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedVendorAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SharedVendorAggregateArgs>(args: Subset<T, SharedVendorAggregateArgs>): Prisma.PrismaPromise<GetSharedVendorAggregateType<T>>

    /**
     * Group by SharedVendor.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedVendorGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SharedVendorGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SharedVendorGroupByArgs['orderBy'] }
        : { orderBy?: SharedVendorGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SharedVendorGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSharedVendorGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SharedVendor model
   */
  readonly fields: SharedVendorFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SharedVendor.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SharedVendorClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends SharedUserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedUserDefaultArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    posts<T extends SharedVendor$postsArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendor$postsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    menuCategories<T extends SharedVendor$menuCategoriesArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendor$menuCategoriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    menuSubCategories<T extends SharedVendor$menuSubCategoriesArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendor$menuSubCategoriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    menuItems<T extends SharedVendor$menuItemsArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendor$menuItemsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    offers<T extends SharedVendor$offersArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendor$offersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    bills<T extends SharedVendor$billsArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendor$billsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SharedVendor model
   */
  interface SharedVendorFieldRefs {
    readonly id: FieldRef<"SharedVendor", 'Int'>
    readonly userId: FieldRef<"SharedVendor", 'Int'>
    readonly businessName: FieldRef<"SharedVendor", 'String'>
    readonly status: FieldRef<"SharedVendor", 'String'>
    readonly logoUrl: FieldRef<"SharedVendor", 'String'>
    readonly businessCategory: FieldRef<"SharedVendor", 'String'>
    readonly address: FieldRef<"SharedVendor", 'String'>
    readonly payment: FieldRef<"SharedVendor", 'Json'>
    readonly workingDays: FieldRef<"SharedVendor", 'Json'>
    readonly createdAt: FieldRef<"SharedVendor", 'DateTime'>
    readonly updatedAt: FieldRef<"SharedVendor", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SharedVendor findUnique
   */
  export type SharedVendorFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * Filter, which SharedVendor to fetch.
     */
    where: SharedVendorWhereUniqueInput
  }

  /**
   * SharedVendor findUniqueOrThrow
   */
  export type SharedVendorFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * Filter, which SharedVendor to fetch.
     */
    where: SharedVendorWhereUniqueInput
  }

  /**
   * SharedVendor findFirst
   */
  export type SharedVendorFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * Filter, which SharedVendor to fetch.
     */
    where?: SharedVendorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedVendors to fetch.
     */
    orderBy?: SharedVendorOrderByWithRelationInput | SharedVendorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedVendors.
     */
    cursor?: SharedVendorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedVendors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedVendors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedVendors.
     */
    distinct?: SharedVendorScalarFieldEnum | SharedVendorScalarFieldEnum[]
  }

  /**
   * SharedVendor findFirstOrThrow
   */
  export type SharedVendorFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * Filter, which SharedVendor to fetch.
     */
    where?: SharedVendorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedVendors to fetch.
     */
    orderBy?: SharedVendorOrderByWithRelationInput | SharedVendorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedVendors.
     */
    cursor?: SharedVendorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedVendors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedVendors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedVendors.
     */
    distinct?: SharedVendorScalarFieldEnum | SharedVendorScalarFieldEnum[]
  }

  /**
   * SharedVendor findMany
   */
  export type SharedVendorFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * Filter, which SharedVendors to fetch.
     */
    where?: SharedVendorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedVendors to fetch.
     */
    orderBy?: SharedVendorOrderByWithRelationInput | SharedVendorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SharedVendors.
     */
    cursor?: SharedVendorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedVendors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedVendors.
     */
    skip?: number
    distinct?: SharedVendorScalarFieldEnum | SharedVendorScalarFieldEnum[]
  }

  /**
   * SharedVendor create
   */
  export type SharedVendorCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * The data needed to create a SharedVendor.
     */
    data: XOR<SharedVendorCreateInput, SharedVendorUncheckedCreateInput>
  }

  /**
   * SharedVendor createMany
   */
  export type SharedVendorCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SharedVendors.
     */
    data: SharedVendorCreateManyInput | SharedVendorCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SharedVendor update
   */
  export type SharedVendorUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * The data needed to update a SharedVendor.
     */
    data: XOR<SharedVendorUpdateInput, SharedVendorUncheckedUpdateInput>
    /**
     * Choose, which SharedVendor to update.
     */
    where: SharedVendorWhereUniqueInput
  }

  /**
   * SharedVendor updateMany
   */
  export type SharedVendorUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SharedVendors.
     */
    data: XOR<SharedVendorUpdateManyMutationInput, SharedVendorUncheckedUpdateManyInput>
    /**
     * Filter which SharedVendors to update
     */
    where?: SharedVendorWhereInput
    /**
     * Limit how many SharedVendors to update.
     */
    limit?: number
  }

  /**
   * SharedVendor upsert
   */
  export type SharedVendorUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * The filter to search for the SharedVendor to update in case it exists.
     */
    where: SharedVendorWhereUniqueInput
    /**
     * In case the SharedVendor found by the `where` argument doesn't exist, create a new SharedVendor with this data.
     */
    create: XOR<SharedVendorCreateInput, SharedVendorUncheckedCreateInput>
    /**
     * In case the SharedVendor was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SharedVendorUpdateInput, SharedVendorUncheckedUpdateInput>
  }

  /**
   * SharedVendor delete
   */
  export type SharedVendorDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
    /**
     * Filter which SharedVendor to delete.
     */
    where: SharedVendorWhereUniqueInput
  }

  /**
   * SharedVendor deleteMany
   */
  export type SharedVendorDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedVendors to delete
     */
    where?: SharedVendorWhereInput
    /**
     * Limit how many SharedVendors to delete.
     */
    limit?: number
  }

  /**
   * SharedVendor.posts
   */
  export type SharedVendor$postsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    where?: SharedPostWhereInput
    orderBy?: SharedPostOrderByWithRelationInput | SharedPostOrderByWithRelationInput[]
    cursor?: SharedPostWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedPostScalarFieldEnum | SharedPostScalarFieldEnum[]
  }

  /**
   * SharedVendor.menuCategories
   */
  export type SharedVendor$menuCategoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    where?: SharedMenuCategoryWhereInput
    orderBy?: SharedMenuCategoryOrderByWithRelationInput | SharedMenuCategoryOrderByWithRelationInput[]
    cursor?: SharedMenuCategoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedMenuCategoryScalarFieldEnum | SharedMenuCategoryScalarFieldEnum[]
  }

  /**
   * SharedVendor.menuSubCategories
   */
  export type SharedVendor$menuSubCategoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    where?: SharedMenuSubCategoryWhereInput
    orderBy?: SharedMenuSubCategoryOrderByWithRelationInput | SharedMenuSubCategoryOrderByWithRelationInput[]
    cursor?: SharedMenuSubCategoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedMenuSubCategoryScalarFieldEnum | SharedMenuSubCategoryScalarFieldEnum[]
  }

  /**
   * SharedVendor.menuItems
   */
  export type SharedVendor$menuItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    where?: SharedMenuItemWhereInput
    orderBy?: SharedMenuItemOrderByWithRelationInput | SharedMenuItemOrderByWithRelationInput[]
    cursor?: SharedMenuItemWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedMenuItemScalarFieldEnum | SharedMenuItemScalarFieldEnum[]
  }

  /**
   * SharedVendor.offers
   */
  export type SharedVendor$offersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    where?: SharedOfferWhereInput
    orderBy?: SharedOfferOrderByWithRelationInput | SharedOfferOrderByWithRelationInput[]
    cursor?: SharedOfferWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedOfferScalarFieldEnum | SharedOfferScalarFieldEnum[]
  }

  /**
   * SharedVendor.bills
   */
  export type SharedVendor$billsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    where?: SharedBillWhereInput
    orderBy?: SharedBillOrderByWithRelationInput | SharedBillOrderByWithRelationInput[]
    cursor?: SharedBillWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedBillScalarFieldEnum | SharedBillScalarFieldEnum[]
  }

  /**
   * SharedVendor without action
   */
  export type SharedVendorDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedVendor
     */
    select?: SharedVendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedVendor
     */
    omit?: SharedVendorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedVendorInclude<ExtArgs> | null
  }


  /**
   * Model SharedPost
   */

  export type AggregateSharedPost = {
    _count: SharedPostCountAggregateOutputType | null
    _avg: SharedPostAvgAggregateOutputType | null
    _sum: SharedPostSumAggregateOutputType | null
    _min: SharedPostMinAggregateOutputType | null
    _max: SharedPostMaxAggregateOutputType | null
  }

  export type SharedPostAvgAggregateOutputType = {
    id: number | null
    vendorId: number | null
    offerId: number | null
  }

  export type SharedPostSumAggregateOutputType = {
    id: number | null
    vendorId: number | null
    offerId: number | null
  }

  export type SharedPostMinAggregateOutputType = {
    id: number | null
    vendorId: number | null
    postType: string | null
    postCategory: string | null
    postUrl: string | null
    isOfferIncluded: boolean | null
    offerId: number | null
    isDownloaded: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedPostMaxAggregateOutputType = {
    id: number | null
    vendorId: number | null
    postType: string | null
    postCategory: string | null
    postUrl: string | null
    isOfferIncluded: boolean | null
    offerId: number | null
    isDownloaded: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedPostCountAggregateOutputType = {
    id: number
    vendorId: number
    postType: number
    postCategory: number
    postUrl: number
    isOfferIncluded: number
    offerId: number
    isDownloaded: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SharedPostAvgAggregateInputType = {
    id?: true
    vendorId?: true
    offerId?: true
  }

  export type SharedPostSumAggregateInputType = {
    id?: true
    vendorId?: true
    offerId?: true
  }

  export type SharedPostMinAggregateInputType = {
    id?: true
    vendorId?: true
    postType?: true
    postCategory?: true
    postUrl?: true
    isOfferIncluded?: true
    offerId?: true
    isDownloaded?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedPostMaxAggregateInputType = {
    id?: true
    vendorId?: true
    postType?: true
    postCategory?: true
    postUrl?: true
    isOfferIncluded?: true
    offerId?: true
    isDownloaded?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedPostCountAggregateInputType = {
    id?: true
    vendorId?: true
    postType?: true
    postCategory?: true
    postUrl?: true
    isOfferIncluded?: true
    offerId?: true
    isDownloaded?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SharedPostAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedPost to aggregate.
     */
    where?: SharedPostWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedPosts to fetch.
     */
    orderBy?: SharedPostOrderByWithRelationInput | SharedPostOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SharedPostWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedPosts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedPosts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SharedPosts
    **/
    _count?: true | SharedPostCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SharedPostAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SharedPostSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SharedPostMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SharedPostMaxAggregateInputType
  }

  export type GetSharedPostAggregateType<T extends SharedPostAggregateArgs> = {
        [P in keyof T & keyof AggregateSharedPost]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSharedPost[P]>
      : GetScalarType<T[P], AggregateSharedPost[P]>
  }




  export type SharedPostGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedPostWhereInput
    orderBy?: SharedPostOrderByWithAggregationInput | SharedPostOrderByWithAggregationInput[]
    by: SharedPostScalarFieldEnum[] | SharedPostScalarFieldEnum
    having?: SharedPostScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SharedPostCountAggregateInputType | true
    _avg?: SharedPostAvgAggregateInputType
    _sum?: SharedPostSumAggregateInputType
    _min?: SharedPostMinAggregateInputType
    _max?: SharedPostMaxAggregateInputType
  }

  export type SharedPostGroupByOutputType = {
    id: number
    vendorId: number
    postType: string
    postCategory: string | null
    postUrl: string
    isOfferIncluded: boolean
    offerId: number | null
    isDownloaded: boolean
    createdAt: Date | null
    updatedAt: Date | null
    _count: SharedPostCountAggregateOutputType | null
    _avg: SharedPostAvgAggregateOutputType | null
    _sum: SharedPostSumAggregateOutputType | null
    _min: SharedPostMinAggregateOutputType | null
    _max: SharedPostMaxAggregateOutputType | null
  }

  type GetSharedPostGroupByPayload<T extends SharedPostGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SharedPostGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SharedPostGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SharedPostGroupByOutputType[P]>
            : GetScalarType<T[P], SharedPostGroupByOutputType[P]>
        }
      >
    >


  export type SharedPostSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    vendorId?: boolean
    postType?: boolean
    postCategory?: boolean
    postUrl?: boolean
    isOfferIncluded?: boolean
    offerId?: boolean
    isDownloaded?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    offer?: boolean | SharedPost$offerArgs<ExtArgs>
  }, ExtArgs["result"]["sharedPost"]>



  export type SharedPostSelectScalar = {
    id?: boolean
    vendorId?: boolean
    postType?: boolean
    postCategory?: boolean
    postUrl?: boolean
    isOfferIncluded?: boolean
    offerId?: boolean
    isDownloaded?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SharedPostOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "vendorId" | "postType" | "postCategory" | "postUrl" | "isOfferIncluded" | "offerId" | "isDownloaded" | "createdAt" | "updatedAt", ExtArgs["result"]["sharedPost"]>
  export type SharedPostInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    offer?: boolean | SharedPost$offerArgs<ExtArgs>
  }

  export type $SharedPostPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SharedPost"
    objects: {
      vendor: Prisma.$SharedVendorPayload<ExtArgs>
      offer: Prisma.$SharedOfferPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      vendorId: number
      postType: string
      postCategory: string | null
      postUrl: string
      isOfferIncluded: boolean
      offerId: number | null
      isDownloaded: boolean
      createdAt: Date | null
      updatedAt: Date | null
    }, ExtArgs["result"]["sharedPost"]>
    composites: {}
  }

  type SharedPostGetPayload<S extends boolean | null | undefined | SharedPostDefaultArgs> = $Result.GetResult<Prisma.$SharedPostPayload, S>

  type SharedPostCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SharedPostFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SharedPostCountAggregateInputType | true
    }

  export interface SharedPostDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SharedPost'], meta: { name: 'SharedPost' } }
    /**
     * Find zero or one SharedPost that matches the filter.
     * @param {SharedPostFindUniqueArgs} args - Arguments to find a SharedPost
     * @example
     * // Get one SharedPost
     * const sharedPost = await prisma.sharedPost.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SharedPostFindUniqueArgs>(args: SelectSubset<T, SharedPostFindUniqueArgs<ExtArgs>>): Prisma__SharedPostClient<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SharedPost that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SharedPostFindUniqueOrThrowArgs} args - Arguments to find a SharedPost
     * @example
     * // Get one SharedPost
     * const sharedPost = await prisma.sharedPost.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SharedPostFindUniqueOrThrowArgs>(args: SelectSubset<T, SharedPostFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SharedPostClient<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedPost that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedPostFindFirstArgs} args - Arguments to find a SharedPost
     * @example
     * // Get one SharedPost
     * const sharedPost = await prisma.sharedPost.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SharedPostFindFirstArgs>(args?: SelectSubset<T, SharedPostFindFirstArgs<ExtArgs>>): Prisma__SharedPostClient<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedPost that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedPostFindFirstOrThrowArgs} args - Arguments to find a SharedPost
     * @example
     * // Get one SharedPost
     * const sharedPost = await prisma.sharedPost.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SharedPostFindFirstOrThrowArgs>(args?: SelectSubset<T, SharedPostFindFirstOrThrowArgs<ExtArgs>>): Prisma__SharedPostClient<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SharedPosts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedPostFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SharedPosts
     * const sharedPosts = await prisma.sharedPost.findMany()
     * 
     * // Get first 10 SharedPosts
     * const sharedPosts = await prisma.sharedPost.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sharedPostWithIdOnly = await prisma.sharedPost.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SharedPostFindManyArgs>(args?: SelectSubset<T, SharedPostFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SharedPost.
     * @param {SharedPostCreateArgs} args - Arguments to create a SharedPost.
     * @example
     * // Create one SharedPost
     * const SharedPost = await prisma.sharedPost.create({
     *   data: {
     *     // ... data to create a SharedPost
     *   }
     * })
     * 
     */
    create<T extends SharedPostCreateArgs>(args: SelectSubset<T, SharedPostCreateArgs<ExtArgs>>): Prisma__SharedPostClient<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SharedPosts.
     * @param {SharedPostCreateManyArgs} args - Arguments to create many SharedPosts.
     * @example
     * // Create many SharedPosts
     * const sharedPost = await prisma.sharedPost.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SharedPostCreateManyArgs>(args?: SelectSubset<T, SharedPostCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SharedPost.
     * @param {SharedPostDeleteArgs} args - Arguments to delete one SharedPost.
     * @example
     * // Delete one SharedPost
     * const SharedPost = await prisma.sharedPost.delete({
     *   where: {
     *     // ... filter to delete one SharedPost
     *   }
     * })
     * 
     */
    delete<T extends SharedPostDeleteArgs>(args: SelectSubset<T, SharedPostDeleteArgs<ExtArgs>>): Prisma__SharedPostClient<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SharedPost.
     * @param {SharedPostUpdateArgs} args - Arguments to update one SharedPost.
     * @example
     * // Update one SharedPost
     * const sharedPost = await prisma.sharedPost.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SharedPostUpdateArgs>(args: SelectSubset<T, SharedPostUpdateArgs<ExtArgs>>): Prisma__SharedPostClient<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SharedPosts.
     * @param {SharedPostDeleteManyArgs} args - Arguments to filter SharedPosts to delete.
     * @example
     * // Delete a few SharedPosts
     * const { count } = await prisma.sharedPost.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SharedPostDeleteManyArgs>(args?: SelectSubset<T, SharedPostDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SharedPosts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedPostUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SharedPosts
     * const sharedPost = await prisma.sharedPost.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SharedPostUpdateManyArgs>(args: SelectSubset<T, SharedPostUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SharedPost.
     * @param {SharedPostUpsertArgs} args - Arguments to update or create a SharedPost.
     * @example
     * // Update or create a SharedPost
     * const sharedPost = await prisma.sharedPost.upsert({
     *   create: {
     *     // ... data to create a SharedPost
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SharedPost we want to update
     *   }
     * })
     */
    upsert<T extends SharedPostUpsertArgs>(args: SelectSubset<T, SharedPostUpsertArgs<ExtArgs>>): Prisma__SharedPostClient<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SharedPosts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedPostCountArgs} args - Arguments to filter SharedPosts to count.
     * @example
     * // Count the number of SharedPosts
     * const count = await prisma.sharedPost.count({
     *   where: {
     *     // ... the filter for the SharedPosts we want to count
     *   }
     * })
    **/
    count<T extends SharedPostCountArgs>(
      args?: Subset<T, SharedPostCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SharedPostCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SharedPost.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedPostAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SharedPostAggregateArgs>(args: Subset<T, SharedPostAggregateArgs>): Prisma.PrismaPromise<GetSharedPostAggregateType<T>>

    /**
     * Group by SharedPost.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedPostGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SharedPostGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SharedPostGroupByArgs['orderBy'] }
        : { orderBy?: SharedPostGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SharedPostGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSharedPostGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SharedPost model
   */
  readonly fields: SharedPostFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SharedPost.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SharedPostClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    vendor<T extends SharedVendorDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendorDefaultArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    offer<T extends SharedPost$offerArgs<ExtArgs> = {}>(args?: Subset<T, SharedPost$offerArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SharedPost model
   */
  interface SharedPostFieldRefs {
    readonly id: FieldRef<"SharedPost", 'Int'>
    readonly vendorId: FieldRef<"SharedPost", 'Int'>
    readonly postType: FieldRef<"SharedPost", 'String'>
    readonly postCategory: FieldRef<"SharedPost", 'String'>
    readonly postUrl: FieldRef<"SharedPost", 'String'>
    readonly isOfferIncluded: FieldRef<"SharedPost", 'Boolean'>
    readonly offerId: FieldRef<"SharedPost", 'Int'>
    readonly isDownloaded: FieldRef<"SharedPost", 'Boolean'>
    readonly createdAt: FieldRef<"SharedPost", 'DateTime'>
    readonly updatedAt: FieldRef<"SharedPost", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SharedPost findUnique
   */
  export type SharedPostFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * Filter, which SharedPost to fetch.
     */
    where: SharedPostWhereUniqueInput
  }

  /**
   * SharedPost findUniqueOrThrow
   */
  export type SharedPostFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * Filter, which SharedPost to fetch.
     */
    where: SharedPostWhereUniqueInput
  }

  /**
   * SharedPost findFirst
   */
  export type SharedPostFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * Filter, which SharedPost to fetch.
     */
    where?: SharedPostWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedPosts to fetch.
     */
    orderBy?: SharedPostOrderByWithRelationInput | SharedPostOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedPosts.
     */
    cursor?: SharedPostWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedPosts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedPosts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedPosts.
     */
    distinct?: SharedPostScalarFieldEnum | SharedPostScalarFieldEnum[]
  }

  /**
   * SharedPost findFirstOrThrow
   */
  export type SharedPostFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * Filter, which SharedPost to fetch.
     */
    where?: SharedPostWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedPosts to fetch.
     */
    orderBy?: SharedPostOrderByWithRelationInput | SharedPostOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedPosts.
     */
    cursor?: SharedPostWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedPosts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedPosts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedPosts.
     */
    distinct?: SharedPostScalarFieldEnum | SharedPostScalarFieldEnum[]
  }

  /**
   * SharedPost findMany
   */
  export type SharedPostFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * Filter, which SharedPosts to fetch.
     */
    where?: SharedPostWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedPosts to fetch.
     */
    orderBy?: SharedPostOrderByWithRelationInput | SharedPostOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SharedPosts.
     */
    cursor?: SharedPostWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedPosts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedPosts.
     */
    skip?: number
    distinct?: SharedPostScalarFieldEnum | SharedPostScalarFieldEnum[]
  }

  /**
   * SharedPost create
   */
  export type SharedPostCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * The data needed to create a SharedPost.
     */
    data: XOR<SharedPostCreateInput, SharedPostUncheckedCreateInput>
  }

  /**
   * SharedPost createMany
   */
  export type SharedPostCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SharedPosts.
     */
    data: SharedPostCreateManyInput | SharedPostCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SharedPost update
   */
  export type SharedPostUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * The data needed to update a SharedPost.
     */
    data: XOR<SharedPostUpdateInput, SharedPostUncheckedUpdateInput>
    /**
     * Choose, which SharedPost to update.
     */
    where: SharedPostWhereUniqueInput
  }

  /**
   * SharedPost updateMany
   */
  export type SharedPostUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SharedPosts.
     */
    data: XOR<SharedPostUpdateManyMutationInput, SharedPostUncheckedUpdateManyInput>
    /**
     * Filter which SharedPosts to update
     */
    where?: SharedPostWhereInput
    /**
     * Limit how many SharedPosts to update.
     */
    limit?: number
  }

  /**
   * SharedPost upsert
   */
  export type SharedPostUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * The filter to search for the SharedPost to update in case it exists.
     */
    where: SharedPostWhereUniqueInput
    /**
     * In case the SharedPost found by the `where` argument doesn't exist, create a new SharedPost with this data.
     */
    create: XOR<SharedPostCreateInput, SharedPostUncheckedCreateInput>
    /**
     * In case the SharedPost was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SharedPostUpdateInput, SharedPostUncheckedUpdateInput>
  }

  /**
   * SharedPost delete
   */
  export type SharedPostDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    /**
     * Filter which SharedPost to delete.
     */
    where: SharedPostWhereUniqueInput
  }

  /**
   * SharedPost deleteMany
   */
  export type SharedPostDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedPosts to delete
     */
    where?: SharedPostWhereInput
    /**
     * Limit how many SharedPosts to delete.
     */
    limit?: number
  }

  /**
   * SharedPost.offer
   */
  export type SharedPost$offerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    where?: SharedOfferWhereInput
  }

  /**
   * SharedPost without action
   */
  export type SharedPostDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
  }


  /**
   * Model SharedMenuCategory
   */

  export type AggregateSharedMenuCategory = {
    _count: SharedMenuCategoryCountAggregateOutputType | null
    _avg: SharedMenuCategoryAvgAggregateOutputType | null
    _sum: SharedMenuCategorySumAggregateOutputType | null
    _min: SharedMenuCategoryMinAggregateOutputType | null
    _max: SharedMenuCategoryMaxAggregateOutputType | null
  }

  export type SharedMenuCategoryAvgAggregateOutputType = {
    id: number | null
    vendorId: number | null
  }

  export type SharedMenuCategorySumAggregateOutputType = {
    id: number | null
    vendorId: number | null
  }

  export type SharedMenuCategoryMinAggregateOutputType = {
    id: number | null
    vendorId: number | null
    categoryName: string | null
    categoryImage: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedMenuCategoryMaxAggregateOutputType = {
    id: number | null
    vendorId: number | null
    categoryName: string | null
    categoryImage: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedMenuCategoryCountAggregateOutputType = {
    id: number
    vendorId: number
    categoryName: number
    categoryImage: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SharedMenuCategoryAvgAggregateInputType = {
    id?: true
    vendorId?: true
  }

  export type SharedMenuCategorySumAggregateInputType = {
    id?: true
    vendorId?: true
  }

  export type SharedMenuCategoryMinAggregateInputType = {
    id?: true
    vendorId?: true
    categoryName?: true
    categoryImage?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedMenuCategoryMaxAggregateInputType = {
    id?: true
    vendorId?: true
    categoryName?: true
    categoryImage?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedMenuCategoryCountAggregateInputType = {
    id?: true
    vendorId?: true
    categoryName?: true
    categoryImage?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SharedMenuCategoryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedMenuCategory to aggregate.
     */
    where?: SharedMenuCategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuCategories to fetch.
     */
    orderBy?: SharedMenuCategoryOrderByWithRelationInput | SharedMenuCategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SharedMenuCategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuCategories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuCategories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SharedMenuCategories
    **/
    _count?: true | SharedMenuCategoryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SharedMenuCategoryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SharedMenuCategorySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SharedMenuCategoryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SharedMenuCategoryMaxAggregateInputType
  }

  export type GetSharedMenuCategoryAggregateType<T extends SharedMenuCategoryAggregateArgs> = {
        [P in keyof T & keyof AggregateSharedMenuCategory]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSharedMenuCategory[P]>
      : GetScalarType<T[P], AggregateSharedMenuCategory[P]>
  }




  export type SharedMenuCategoryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuCategoryWhereInput
    orderBy?: SharedMenuCategoryOrderByWithAggregationInput | SharedMenuCategoryOrderByWithAggregationInput[]
    by: SharedMenuCategoryScalarFieldEnum[] | SharedMenuCategoryScalarFieldEnum
    having?: SharedMenuCategoryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SharedMenuCategoryCountAggregateInputType | true
    _avg?: SharedMenuCategoryAvgAggregateInputType
    _sum?: SharedMenuCategorySumAggregateInputType
    _min?: SharedMenuCategoryMinAggregateInputType
    _max?: SharedMenuCategoryMaxAggregateInputType
  }

  export type SharedMenuCategoryGroupByOutputType = {
    id: number
    vendorId: number
    categoryName: string
    categoryImage: string | null
    createdAt: Date | null
    updatedAt: Date | null
    _count: SharedMenuCategoryCountAggregateOutputType | null
    _avg: SharedMenuCategoryAvgAggregateOutputType | null
    _sum: SharedMenuCategorySumAggregateOutputType | null
    _min: SharedMenuCategoryMinAggregateOutputType | null
    _max: SharedMenuCategoryMaxAggregateOutputType | null
  }

  type GetSharedMenuCategoryGroupByPayload<T extends SharedMenuCategoryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SharedMenuCategoryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SharedMenuCategoryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SharedMenuCategoryGroupByOutputType[P]>
            : GetScalarType<T[P], SharedMenuCategoryGroupByOutputType[P]>
        }
      >
    >


  export type SharedMenuCategorySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    vendorId?: boolean
    categoryName?: boolean
    categoryImage?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    subCategories?: boolean | SharedMenuCategory$subCategoriesArgs<ExtArgs>
    items?: boolean | SharedMenuCategory$itemsArgs<ExtArgs>
    _count?: boolean | SharedMenuCategoryCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["sharedMenuCategory"]>



  export type SharedMenuCategorySelectScalar = {
    id?: boolean
    vendorId?: boolean
    categoryName?: boolean
    categoryImage?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SharedMenuCategoryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "vendorId" | "categoryName" | "categoryImage" | "createdAt" | "updatedAt", ExtArgs["result"]["sharedMenuCategory"]>
  export type SharedMenuCategoryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    subCategories?: boolean | SharedMenuCategory$subCategoriesArgs<ExtArgs>
    items?: boolean | SharedMenuCategory$itemsArgs<ExtArgs>
    _count?: boolean | SharedMenuCategoryCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $SharedMenuCategoryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SharedMenuCategory"
    objects: {
      vendor: Prisma.$SharedVendorPayload<ExtArgs>
      subCategories: Prisma.$SharedMenuSubCategoryPayload<ExtArgs>[]
      items: Prisma.$SharedMenuItemPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      vendorId: number
      categoryName: string
      categoryImage: string | null
      createdAt: Date | null
      updatedAt: Date | null
    }, ExtArgs["result"]["sharedMenuCategory"]>
    composites: {}
  }

  type SharedMenuCategoryGetPayload<S extends boolean | null | undefined | SharedMenuCategoryDefaultArgs> = $Result.GetResult<Prisma.$SharedMenuCategoryPayload, S>

  type SharedMenuCategoryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SharedMenuCategoryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SharedMenuCategoryCountAggregateInputType | true
    }

  export interface SharedMenuCategoryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SharedMenuCategory'], meta: { name: 'SharedMenuCategory' } }
    /**
     * Find zero or one SharedMenuCategory that matches the filter.
     * @param {SharedMenuCategoryFindUniqueArgs} args - Arguments to find a SharedMenuCategory
     * @example
     * // Get one SharedMenuCategory
     * const sharedMenuCategory = await prisma.sharedMenuCategory.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SharedMenuCategoryFindUniqueArgs>(args: SelectSubset<T, SharedMenuCategoryFindUniqueArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SharedMenuCategory that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SharedMenuCategoryFindUniqueOrThrowArgs} args - Arguments to find a SharedMenuCategory
     * @example
     * // Get one SharedMenuCategory
     * const sharedMenuCategory = await prisma.sharedMenuCategory.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SharedMenuCategoryFindUniqueOrThrowArgs>(args: SelectSubset<T, SharedMenuCategoryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedMenuCategory that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuCategoryFindFirstArgs} args - Arguments to find a SharedMenuCategory
     * @example
     * // Get one SharedMenuCategory
     * const sharedMenuCategory = await prisma.sharedMenuCategory.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SharedMenuCategoryFindFirstArgs>(args?: SelectSubset<T, SharedMenuCategoryFindFirstArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedMenuCategory that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuCategoryFindFirstOrThrowArgs} args - Arguments to find a SharedMenuCategory
     * @example
     * // Get one SharedMenuCategory
     * const sharedMenuCategory = await prisma.sharedMenuCategory.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SharedMenuCategoryFindFirstOrThrowArgs>(args?: SelectSubset<T, SharedMenuCategoryFindFirstOrThrowArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SharedMenuCategories that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuCategoryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SharedMenuCategories
     * const sharedMenuCategories = await prisma.sharedMenuCategory.findMany()
     * 
     * // Get first 10 SharedMenuCategories
     * const sharedMenuCategories = await prisma.sharedMenuCategory.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sharedMenuCategoryWithIdOnly = await prisma.sharedMenuCategory.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SharedMenuCategoryFindManyArgs>(args?: SelectSubset<T, SharedMenuCategoryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SharedMenuCategory.
     * @param {SharedMenuCategoryCreateArgs} args - Arguments to create a SharedMenuCategory.
     * @example
     * // Create one SharedMenuCategory
     * const SharedMenuCategory = await prisma.sharedMenuCategory.create({
     *   data: {
     *     // ... data to create a SharedMenuCategory
     *   }
     * })
     * 
     */
    create<T extends SharedMenuCategoryCreateArgs>(args: SelectSubset<T, SharedMenuCategoryCreateArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SharedMenuCategories.
     * @param {SharedMenuCategoryCreateManyArgs} args - Arguments to create many SharedMenuCategories.
     * @example
     * // Create many SharedMenuCategories
     * const sharedMenuCategory = await prisma.sharedMenuCategory.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SharedMenuCategoryCreateManyArgs>(args?: SelectSubset<T, SharedMenuCategoryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SharedMenuCategory.
     * @param {SharedMenuCategoryDeleteArgs} args - Arguments to delete one SharedMenuCategory.
     * @example
     * // Delete one SharedMenuCategory
     * const SharedMenuCategory = await prisma.sharedMenuCategory.delete({
     *   where: {
     *     // ... filter to delete one SharedMenuCategory
     *   }
     * })
     * 
     */
    delete<T extends SharedMenuCategoryDeleteArgs>(args: SelectSubset<T, SharedMenuCategoryDeleteArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SharedMenuCategory.
     * @param {SharedMenuCategoryUpdateArgs} args - Arguments to update one SharedMenuCategory.
     * @example
     * // Update one SharedMenuCategory
     * const sharedMenuCategory = await prisma.sharedMenuCategory.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SharedMenuCategoryUpdateArgs>(args: SelectSubset<T, SharedMenuCategoryUpdateArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SharedMenuCategories.
     * @param {SharedMenuCategoryDeleteManyArgs} args - Arguments to filter SharedMenuCategories to delete.
     * @example
     * // Delete a few SharedMenuCategories
     * const { count } = await prisma.sharedMenuCategory.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SharedMenuCategoryDeleteManyArgs>(args?: SelectSubset<T, SharedMenuCategoryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SharedMenuCategories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuCategoryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SharedMenuCategories
     * const sharedMenuCategory = await prisma.sharedMenuCategory.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SharedMenuCategoryUpdateManyArgs>(args: SelectSubset<T, SharedMenuCategoryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SharedMenuCategory.
     * @param {SharedMenuCategoryUpsertArgs} args - Arguments to update or create a SharedMenuCategory.
     * @example
     * // Update or create a SharedMenuCategory
     * const sharedMenuCategory = await prisma.sharedMenuCategory.upsert({
     *   create: {
     *     // ... data to create a SharedMenuCategory
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SharedMenuCategory we want to update
     *   }
     * })
     */
    upsert<T extends SharedMenuCategoryUpsertArgs>(args: SelectSubset<T, SharedMenuCategoryUpsertArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SharedMenuCategories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuCategoryCountArgs} args - Arguments to filter SharedMenuCategories to count.
     * @example
     * // Count the number of SharedMenuCategories
     * const count = await prisma.sharedMenuCategory.count({
     *   where: {
     *     // ... the filter for the SharedMenuCategories we want to count
     *   }
     * })
    **/
    count<T extends SharedMenuCategoryCountArgs>(
      args?: Subset<T, SharedMenuCategoryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SharedMenuCategoryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SharedMenuCategory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuCategoryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SharedMenuCategoryAggregateArgs>(args: Subset<T, SharedMenuCategoryAggregateArgs>): Prisma.PrismaPromise<GetSharedMenuCategoryAggregateType<T>>

    /**
     * Group by SharedMenuCategory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuCategoryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SharedMenuCategoryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SharedMenuCategoryGroupByArgs['orderBy'] }
        : { orderBy?: SharedMenuCategoryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SharedMenuCategoryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSharedMenuCategoryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SharedMenuCategory model
   */
  readonly fields: SharedMenuCategoryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SharedMenuCategory.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SharedMenuCategoryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    vendor<T extends SharedVendorDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendorDefaultArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    subCategories<T extends SharedMenuCategory$subCategoriesArgs<ExtArgs> = {}>(args?: Subset<T, SharedMenuCategory$subCategoriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    items<T extends SharedMenuCategory$itemsArgs<ExtArgs> = {}>(args?: Subset<T, SharedMenuCategory$itemsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SharedMenuCategory model
   */
  interface SharedMenuCategoryFieldRefs {
    readonly id: FieldRef<"SharedMenuCategory", 'Int'>
    readonly vendorId: FieldRef<"SharedMenuCategory", 'Int'>
    readonly categoryName: FieldRef<"SharedMenuCategory", 'String'>
    readonly categoryImage: FieldRef<"SharedMenuCategory", 'String'>
    readonly createdAt: FieldRef<"SharedMenuCategory", 'DateTime'>
    readonly updatedAt: FieldRef<"SharedMenuCategory", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SharedMenuCategory findUnique
   */
  export type SharedMenuCategoryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuCategory to fetch.
     */
    where: SharedMenuCategoryWhereUniqueInput
  }

  /**
   * SharedMenuCategory findUniqueOrThrow
   */
  export type SharedMenuCategoryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuCategory to fetch.
     */
    where: SharedMenuCategoryWhereUniqueInput
  }

  /**
   * SharedMenuCategory findFirst
   */
  export type SharedMenuCategoryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuCategory to fetch.
     */
    where?: SharedMenuCategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuCategories to fetch.
     */
    orderBy?: SharedMenuCategoryOrderByWithRelationInput | SharedMenuCategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedMenuCategories.
     */
    cursor?: SharedMenuCategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuCategories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuCategories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedMenuCategories.
     */
    distinct?: SharedMenuCategoryScalarFieldEnum | SharedMenuCategoryScalarFieldEnum[]
  }

  /**
   * SharedMenuCategory findFirstOrThrow
   */
  export type SharedMenuCategoryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuCategory to fetch.
     */
    where?: SharedMenuCategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuCategories to fetch.
     */
    orderBy?: SharedMenuCategoryOrderByWithRelationInput | SharedMenuCategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedMenuCategories.
     */
    cursor?: SharedMenuCategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuCategories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuCategories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedMenuCategories.
     */
    distinct?: SharedMenuCategoryScalarFieldEnum | SharedMenuCategoryScalarFieldEnum[]
  }

  /**
   * SharedMenuCategory findMany
   */
  export type SharedMenuCategoryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuCategories to fetch.
     */
    where?: SharedMenuCategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuCategories to fetch.
     */
    orderBy?: SharedMenuCategoryOrderByWithRelationInput | SharedMenuCategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SharedMenuCategories.
     */
    cursor?: SharedMenuCategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuCategories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuCategories.
     */
    skip?: number
    distinct?: SharedMenuCategoryScalarFieldEnum | SharedMenuCategoryScalarFieldEnum[]
  }

  /**
   * SharedMenuCategory create
   */
  export type SharedMenuCategoryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * The data needed to create a SharedMenuCategory.
     */
    data: XOR<SharedMenuCategoryCreateInput, SharedMenuCategoryUncheckedCreateInput>
  }

  /**
   * SharedMenuCategory createMany
   */
  export type SharedMenuCategoryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SharedMenuCategories.
     */
    data: SharedMenuCategoryCreateManyInput | SharedMenuCategoryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SharedMenuCategory update
   */
  export type SharedMenuCategoryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * The data needed to update a SharedMenuCategory.
     */
    data: XOR<SharedMenuCategoryUpdateInput, SharedMenuCategoryUncheckedUpdateInput>
    /**
     * Choose, which SharedMenuCategory to update.
     */
    where: SharedMenuCategoryWhereUniqueInput
  }

  /**
   * SharedMenuCategory updateMany
   */
  export type SharedMenuCategoryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SharedMenuCategories.
     */
    data: XOR<SharedMenuCategoryUpdateManyMutationInput, SharedMenuCategoryUncheckedUpdateManyInput>
    /**
     * Filter which SharedMenuCategories to update
     */
    where?: SharedMenuCategoryWhereInput
    /**
     * Limit how many SharedMenuCategories to update.
     */
    limit?: number
  }

  /**
   * SharedMenuCategory upsert
   */
  export type SharedMenuCategoryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * The filter to search for the SharedMenuCategory to update in case it exists.
     */
    where: SharedMenuCategoryWhereUniqueInput
    /**
     * In case the SharedMenuCategory found by the `where` argument doesn't exist, create a new SharedMenuCategory with this data.
     */
    create: XOR<SharedMenuCategoryCreateInput, SharedMenuCategoryUncheckedCreateInput>
    /**
     * In case the SharedMenuCategory was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SharedMenuCategoryUpdateInput, SharedMenuCategoryUncheckedUpdateInput>
  }

  /**
   * SharedMenuCategory delete
   */
  export type SharedMenuCategoryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
    /**
     * Filter which SharedMenuCategory to delete.
     */
    where: SharedMenuCategoryWhereUniqueInput
  }

  /**
   * SharedMenuCategory deleteMany
   */
  export type SharedMenuCategoryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedMenuCategories to delete
     */
    where?: SharedMenuCategoryWhereInput
    /**
     * Limit how many SharedMenuCategories to delete.
     */
    limit?: number
  }

  /**
   * SharedMenuCategory.subCategories
   */
  export type SharedMenuCategory$subCategoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    where?: SharedMenuSubCategoryWhereInput
    orderBy?: SharedMenuSubCategoryOrderByWithRelationInput | SharedMenuSubCategoryOrderByWithRelationInput[]
    cursor?: SharedMenuSubCategoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedMenuSubCategoryScalarFieldEnum | SharedMenuSubCategoryScalarFieldEnum[]
  }

  /**
   * SharedMenuCategory.items
   */
  export type SharedMenuCategory$itemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    where?: SharedMenuItemWhereInput
    orderBy?: SharedMenuItemOrderByWithRelationInput | SharedMenuItemOrderByWithRelationInput[]
    cursor?: SharedMenuItemWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedMenuItemScalarFieldEnum | SharedMenuItemScalarFieldEnum[]
  }

  /**
   * SharedMenuCategory without action
   */
  export type SharedMenuCategoryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuCategory
     */
    select?: SharedMenuCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuCategory
     */
    omit?: SharedMenuCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuCategoryInclude<ExtArgs> | null
  }


  /**
   * Model SharedMenuSubCategory
   */

  export type AggregateSharedMenuSubCategory = {
    _count: SharedMenuSubCategoryCountAggregateOutputType | null
    _avg: SharedMenuSubCategoryAvgAggregateOutputType | null
    _sum: SharedMenuSubCategorySumAggregateOutputType | null
    _min: SharedMenuSubCategoryMinAggregateOutputType | null
    _max: SharedMenuSubCategoryMaxAggregateOutputType | null
  }

  export type SharedMenuSubCategoryAvgAggregateOutputType = {
    id: number | null
    vendorId: number | null
    categoryId: number | null
  }

  export type SharedMenuSubCategorySumAggregateOutputType = {
    id: number | null
    vendorId: number | null
    categoryId: number | null
  }

  export type SharedMenuSubCategoryMinAggregateOutputType = {
    id: number | null
    vendorId: number | null
    categoryId: number | null
    subCategoryName: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedMenuSubCategoryMaxAggregateOutputType = {
    id: number | null
    vendorId: number | null
    categoryId: number | null
    subCategoryName: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedMenuSubCategoryCountAggregateOutputType = {
    id: number
    vendorId: number
    categoryId: number
    subCategoryName: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SharedMenuSubCategoryAvgAggregateInputType = {
    id?: true
    vendorId?: true
    categoryId?: true
  }

  export type SharedMenuSubCategorySumAggregateInputType = {
    id?: true
    vendorId?: true
    categoryId?: true
  }

  export type SharedMenuSubCategoryMinAggregateInputType = {
    id?: true
    vendorId?: true
    categoryId?: true
    subCategoryName?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedMenuSubCategoryMaxAggregateInputType = {
    id?: true
    vendorId?: true
    categoryId?: true
    subCategoryName?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedMenuSubCategoryCountAggregateInputType = {
    id?: true
    vendorId?: true
    categoryId?: true
    subCategoryName?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SharedMenuSubCategoryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedMenuSubCategory to aggregate.
     */
    where?: SharedMenuSubCategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuSubCategories to fetch.
     */
    orderBy?: SharedMenuSubCategoryOrderByWithRelationInput | SharedMenuSubCategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SharedMenuSubCategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuSubCategories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuSubCategories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SharedMenuSubCategories
    **/
    _count?: true | SharedMenuSubCategoryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SharedMenuSubCategoryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SharedMenuSubCategorySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SharedMenuSubCategoryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SharedMenuSubCategoryMaxAggregateInputType
  }

  export type GetSharedMenuSubCategoryAggregateType<T extends SharedMenuSubCategoryAggregateArgs> = {
        [P in keyof T & keyof AggregateSharedMenuSubCategory]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSharedMenuSubCategory[P]>
      : GetScalarType<T[P], AggregateSharedMenuSubCategory[P]>
  }




  export type SharedMenuSubCategoryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuSubCategoryWhereInput
    orderBy?: SharedMenuSubCategoryOrderByWithAggregationInput | SharedMenuSubCategoryOrderByWithAggregationInput[]
    by: SharedMenuSubCategoryScalarFieldEnum[] | SharedMenuSubCategoryScalarFieldEnum
    having?: SharedMenuSubCategoryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SharedMenuSubCategoryCountAggregateInputType | true
    _avg?: SharedMenuSubCategoryAvgAggregateInputType
    _sum?: SharedMenuSubCategorySumAggregateInputType
    _min?: SharedMenuSubCategoryMinAggregateInputType
    _max?: SharedMenuSubCategoryMaxAggregateInputType
  }

  export type SharedMenuSubCategoryGroupByOutputType = {
    id: number
    vendorId: number
    categoryId: number
    subCategoryName: string
    createdAt: Date | null
    updatedAt: Date | null
    _count: SharedMenuSubCategoryCountAggregateOutputType | null
    _avg: SharedMenuSubCategoryAvgAggregateOutputType | null
    _sum: SharedMenuSubCategorySumAggregateOutputType | null
    _min: SharedMenuSubCategoryMinAggregateOutputType | null
    _max: SharedMenuSubCategoryMaxAggregateOutputType | null
  }

  type GetSharedMenuSubCategoryGroupByPayload<T extends SharedMenuSubCategoryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SharedMenuSubCategoryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SharedMenuSubCategoryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SharedMenuSubCategoryGroupByOutputType[P]>
            : GetScalarType<T[P], SharedMenuSubCategoryGroupByOutputType[P]>
        }
      >
    >


  export type SharedMenuSubCategorySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    vendorId?: boolean
    categoryId?: boolean
    subCategoryName?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    category?: boolean | SharedMenuCategoryDefaultArgs<ExtArgs>
    items?: boolean | SharedMenuSubCategory$itemsArgs<ExtArgs>
    _count?: boolean | SharedMenuSubCategoryCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["sharedMenuSubCategory"]>



  export type SharedMenuSubCategorySelectScalar = {
    id?: boolean
    vendorId?: boolean
    categoryId?: boolean
    subCategoryName?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SharedMenuSubCategoryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "vendorId" | "categoryId" | "subCategoryName" | "createdAt" | "updatedAt", ExtArgs["result"]["sharedMenuSubCategory"]>
  export type SharedMenuSubCategoryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    category?: boolean | SharedMenuCategoryDefaultArgs<ExtArgs>
    items?: boolean | SharedMenuSubCategory$itemsArgs<ExtArgs>
    _count?: boolean | SharedMenuSubCategoryCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $SharedMenuSubCategoryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SharedMenuSubCategory"
    objects: {
      vendor: Prisma.$SharedVendorPayload<ExtArgs>
      category: Prisma.$SharedMenuCategoryPayload<ExtArgs>
      items: Prisma.$SharedMenuItemPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      vendorId: number
      categoryId: number
      subCategoryName: string
      createdAt: Date | null
      updatedAt: Date | null
    }, ExtArgs["result"]["sharedMenuSubCategory"]>
    composites: {}
  }

  type SharedMenuSubCategoryGetPayload<S extends boolean | null | undefined | SharedMenuSubCategoryDefaultArgs> = $Result.GetResult<Prisma.$SharedMenuSubCategoryPayload, S>

  type SharedMenuSubCategoryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SharedMenuSubCategoryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SharedMenuSubCategoryCountAggregateInputType | true
    }

  export interface SharedMenuSubCategoryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SharedMenuSubCategory'], meta: { name: 'SharedMenuSubCategory' } }
    /**
     * Find zero or one SharedMenuSubCategory that matches the filter.
     * @param {SharedMenuSubCategoryFindUniqueArgs} args - Arguments to find a SharedMenuSubCategory
     * @example
     * // Get one SharedMenuSubCategory
     * const sharedMenuSubCategory = await prisma.sharedMenuSubCategory.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SharedMenuSubCategoryFindUniqueArgs>(args: SelectSubset<T, SharedMenuSubCategoryFindUniqueArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SharedMenuSubCategory that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SharedMenuSubCategoryFindUniqueOrThrowArgs} args - Arguments to find a SharedMenuSubCategory
     * @example
     * // Get one SharedMenuSubCategory
     * const sharedMenuSubCategory = await prisma.sharedMenuSubCategory.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SharedMenuSubCategoryFindUniqueOrThrowArgs>(args: SelectSubset<T, SharedMenuSubCategoryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedMenuSubCategory that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuSubCategoryFindFirstArgs} args - Arguments to find a SharedMenuSubCategory
     * @example
     * // Get one SharedMenuSubCategory
     * const sharedMenuSubCategory = await prisma.sharedMenuSubCategory.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SharedMenuSubCategoryFindFirstArgs>(args?: SelectSubset<T, SharedMenuSubCategoryFindFirstArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedMenuSubCategory that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuSubCategoryFindFirstOrThrowArgs} args - Arguments to find a SharedMenuSubCategory
     * @example
     * // Get one SharedMenuSubCategory
     * const sharedMenuSubCategory = await prisma.sharedMenuSubCategory.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SharedMenuSubCategoryFindFirstOrThrowArgs>(args?: SelectSubset<T, SharedMenuSubCategoryFindFirstOrThrowArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SharedMenuSubCategories that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuSubCategoryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SharedMenuSubCategories
     * const sharedMenuSubCategories = await prisma.sharedMenuSubCategory.findMany()
     * 
     * // Get first 10 SharedMenuSubCategories
     * const sharedMenuSubCategories = await prisma.sharedMenuSubCategory.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sharedMenuSubCategoryWithIdOnly = await prisma.sharedMenuSubCategory.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SharedMenuSubCategoryFindManyArgs>(args?: SelectSubset<T, SharedMenuSubCategoryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SharedMenuSubCategory.
     * @param {SharedMenuSubCategoryCreateArgs} args - Arguments to create a SharedMenuSubCategory.
     * @example
     * // Create one SharedMenuSubCategory
     * const SharedMenuSubCategory = await prisma.sharedMenuSubCategory.create({
     *   data: {
     *     // ... data to create a SharedMenuSubCategory
     *   }
     * })
     * 
     */
    create<T extends SharedMenuSubCategoryCreateArgs>(args: SelectSubset<T, SharedMenuSubCategoryCreateArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SharedMenuSubCategories.
     * @param {SharedMenuSubCategoryCreateManyArgs} args - Arguments to create many SharedMenuSubCategories.
     * @example
     * // Create many SharedMenuSubCategories
     * const sharedMenuSubCategory = await prisma.sharedMenuSubCategory.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SharedMenuSubCategoryCreateManyArgs>(args?: SelectSubset<T, SharedMenuSubCategoryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SharedMenuSubCategory.
     * @param {SharedMenuSubCategoryDeleteArgs} args - Arguments to delete one SharedMenuSubCategory.
     * @example
     * // Delete one SharedMenuSubCategory
     * const SharedMenuSubCategory = await prisma.sharedMenuSubCategory.delete({
     *   where: {
     *     // ... filter to delete one SharedMenuSubCategory
     *   }
     * })
     * 
     */
    delete<T extends SharedMenuSubCategoryDeleteArgs>(args: SelectSubset<T, SharedMenuSubCategoryDeleteArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SharedMenuSubCategory.
     * @param {SharedMenuSubCategoryUpdateArgs} args - Arguments to update one SharedMenuSubCategory.
     * @example
     * // Update one SharedMenuSubCategory
     * const sharedMenuSubCategory = await prisma.sharedMenuSubCategory.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SharedMenuSubCategoryUpdateArgs>(args: SelectSubset<T, SharedMenuSubCategoryUpdateArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SharedMenuSubCategories.
     * @param {SharedMenuSubCategoryDeleteManyArgs} args - Arguments to filter SharedMenuSubCategories to delete.
     * @example
     * // Delete a few SharedMenuSubCategories
     * const { count } = await prisma.sharedMenuSubCategory.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SharedMenuSubCategoryDeleteManyArgs>(args?: SelectSubset<T, SharedMenuSubCategoryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SharedMenuSubCategories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuSubCategoryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SharedMenuSubCategories
     * const sharedMenuSubCategory = await prisma.sharedMenuSubCategory.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SharedMenuSubCategoryUpdateManyArgs>(args: SelectSubset<T, SharedMenuSubCategoryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SharedMenuSubCategory.
     * @param {SharedMenuSubCategoryUpsertArgs} args - Arguments to update or create a SharedMenuSubCategory.
     * @example
     * // Update or create a SharedMenuSubCategory
     * const sharedMenuSubCategory = await prisma.sharedMenuSubCategory.upsert({
     *   create: {
     *     // ... data to create a SharedMenuSubCategory
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SharedMenuSubCategory we want to update
     *   }
     * })
     */
    upsert<T extends SharedMenuSubCategoryUpsertArgs>(args: SelectSubset<T, SharedMenuSubCategoryUpsertArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SharedMenuSubCategories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuSubCategoryCountArgs} args - Arguments to filter SharedMenuSubCategories to count.
     * @example
     * // Count the number of SharedMenuSubCategories
     * const count = await prisma.sharedMenuSubCategory.count({
     *   where: {
     *     // ... the filter for the SharedMenuSubCategories we want to count
     *   }
     * })
    **/
    count<T extends SharedMenuSubCategoryCountArgs>(
      args?: Subset<T, SharedMenuSubCategoryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SharedMenuSubCategoryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SharedMenuSubCategory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuSubCategoryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SharedMenuSubCategoryAggregateArgs>(args: Subset<T, SharedMenuSubCategoryAggregateArgs>): Prisma.PrismaPromise<GetSharedMenuSubCategoryAggregateType<T>>

    /**
     * Group by SharedMenuSubCategory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuSubCategoryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SharedMenuSubCategoryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SharedMenuSubCategoryGroupByArgs['orderBy'] }
        : { orderBy?: SharedMenuSubCategoryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SharedMenuSubCategoryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSharedMenuSubCategoryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SharedMenuSubCategory model
   */
  readonly fields: SharedMenuSubCategoryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SharedMenuSubCategory.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SharedMenuSubCategoryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    vendor<T extends SharedVendorDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendorDefaultArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    category<T extends SharedMenuCategoryDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedMenuCategoryDefaultArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    items<T extends SharedMenuSubCategory$itemsArgs<ExtArgs> = {}>(args?: Subset<T, SharedMenuSubCategory$itemsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SharedMenuSubCategory model
   */
  interface SharedMenuSubCategoryFieldRefs {
    readonly id: FieldRef<"SharedMenuSubCategory", 'Int'>
    readonly vendorId: FieldRef<"SharedMenuSubCategory", 'Int'>
    readonly categoryId: FieldRef<"SharedMenuSubCategory", 'Int'>
    readonly subCategoryName: FieldRef<"SharedMenuSubCategory", 'String'>
    readonly createdAt: FieldRef<"SharedMenuSubCategory", 'DateTime'>
    readonly updatedAt: FieldRef<"SharedMenuSubCategory", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SharedMenuSubCategory findUnique
   */
  export type SharedMenuSubCategoryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuSubCategory to fetch.
     */
    where: SharedMenuSubCategoryWhereUniqueInput
  }

  /**
   * SharedMenuSubCategory findUniqueOrThrow
   */
  export type SharedMenuSubCategoryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuSubCategory to fetch.
     */
    where: SharedMenuSubCategoryWhereUniqueInput
  }

  /**
   * SharedMenuSubCategory findFirst
   */
  export type SharedMenuSubCategoryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuSubCategory to fetch.
     */
    where?: SharedMenuSubCategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuSubCategories to fetch.
     */
    orderBy?: SharedMenuSubCategoryOrderByWithRelationInput | SharedMenuSubCategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedMenuSubCategories.
     */
    cursor?: SharedMenuSubCategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuSubCategories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuSubCategories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedMenuSubCategories.
     */
    distinct?: SharedMenuSubCategoryScalarFieldEnum | SharedMenuSubCategoryScalarFieldEnum[]
  }

  /**
   * SharedMenuSubCategory findFirstOrThrow
   */
  export type SharedMenuSubCategoryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuSubCategory to fetch.
     */
    where?: SharedMenuSubCategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuSubCategories to fetch.
     */
    orderBy?: SharedMenuSubCategoryOrderByWithRelationInput | SharedMenuSubCategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedMenuSubCategories.
     */
    cursor?: SharedMenuSubCategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuSubCategories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuSubCategories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedMenuSubCategories.
     */
    distinct?: SharedMenuSubCategoryScalarFieldEnum | SharedMenuSubCategoryScalarFieldEnum[]
  }

  /**
   * SharedMenuSubCategory findMany
   */
  export type SharedMenuSubCategoryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuSubCategories to fetch.
     */
    where?: SharedMenuSubCategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuSubCategories to fetch.
     */
    orderBy?: SharedMenuSubCategoryOrderByWithRelationInput | SharedMenuSubCategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SharedMenuSubCategories.
     */
    cursor?: SharedMenuSubCategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuSubCategories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuSubCategories.
     */
    skip?: number
    distinct?: SharedMenuSubCategoryScalarFieldEnum | SharedMenuSubCategoryScalarFieldEnum[]
  }

  /**
   * SharedMenuSubCategory create
   */
  export type SharedMenuSubCategoryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * The data needed to create a SharedMenuSubCategory.
     */
    data: XOR<SharedMenuSubCategoryCreateInput, SharedMenuSubCategoryUncheckedCreateInput>
  }

  /**
   * SharedMenuSubCategory createMany
   */
  export type SharedMenuSubCategoryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SharedMenuSubCategories.
     */
    data: SharedMenuSubCategoryCreateManyInput | SharedMenuSubCategoryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SharedMenuSubCategory update
   */
  export type SharedMenuSubCategoryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * The data needed to update a SharedMenuSubCategory.
     */
    data: XOR<SharedMenuSubCategoryUpdateInput, SharedMenuSubCategoryUncheckedUpdateInput>
    /**
     * Choose, which SharedMenuSubCategory to update.
     */
    where: SharedMenuSubCategoryWhereUniqueInput
  }

  /**
   * SharedMenuSubCategory updateMany
   */
  export type SharedMenuSubCategoryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SharedMenuSubCategories.
     */
    data: XOR<SharedMenuSubCategoryUpdateManyMutationInput, SharedMenuSubCategoryUncheckedUpdateManyInput>
    /**
     * Filter which SharedMenuSubCategories to update
     */
    where?: SharedMenuSubCategoryWhereInput
    /**
     * Limit how many SharedMenuSubCategories to update.
     */
    limit?: number
  }

  /**
   * SharedMenuSubCategory upsert
   */
  export type SharedMenuSubCategoryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * The filter to search for the SharedMenuSubCategory to update in case it exists.
     */
    where: SharedMenuSubCategoryWhereUniqueInput
    /**
     * In case the SharedMenuSubCategory found by the `where` argument doesn't exist, create a new SharedMenuSubCategory with this data.
     */
    create: XOR<SharedMenuSubCategoryCreateInput, SharedMenuSubCategoryUncheckedCreateInput>
    /**
     * In case the SharedMenuSubCategory was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SharedMenuSubCategoryUpdateInput, SharedMenuSubCategoryUncheckedUpdateInput>
  }

  /**
   * SharedMenuSubCategory delete
   */
  export type SharedMenuSubCategoryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    /**
     * Filter which SharedMenuSubCategory to delete.
     */
    where: SharedMenuSubCategoryWhereUniqueInput
  }

  /**
   * SharedMenuSubCategory deleteMany
   */
  export type SharedMenuSubCategoryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedMenuSubCategories to delete
     */
    where?: SharedMenuSubCategoryWhereInput
    /**
     * Limit how many SharedMenuSubCategories to delete.
     */
    limit?: number
  }

  /**
   * SharedMenuSubCategory.items
   */
  export type SharedMenuSubCategory$itemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    where?: SharedMenuItemWhereInput
    orderBy?: SharedMenuItemOrderByWithRelationInput | SharedMenuItemOrderByWithRelationInput[]
    cursor?: SharedMenuItemWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedMenuItemScalarFieldEnum | SharedMenuItemScalarFieldEnum[]
  }

  /**
   * SharedMenuSubCategory without action
   */
  export type SharedMenuSubCategoryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
  }


  /**
   * Model SharedMenuItem
   */

  export type AggregateSharedMenuItem = {
    _count: SharedMenuItemCountAggregateOutputType | null
    _avg: SharedMenuItemAvgAggregateOutputType | null
    _sum: SharedMenuItemSumAggregateOutputType | null
    _min: SharedMenuItemMinAggregateOutputType | null
    _max: SharedMenuItemMaxAggregateOutputType | null
  }

  export type SharedMenuItemAvgAggregateOutputType = {
    id: number | null
    vendorId: number | null
    menuCategoryId: number | null
    menuSubCategoryId: number | null
    price: Decimal | null
  }

  export type SharedMenuItemSumAggregateOutputType = {
    id: number | null
    vendorId: number | null
    menuCategoryId: number | null
    menuSubCategoryId: number | null
    price: Decimal | null
  }

  export type SharedMenuItemMinAggregateOutputType = {
    id: number | null
    vendorId: number | null
    menuCategoryId: number | null
    menuSubCategoryId: number | null
    productName: string | null
    image: string | null
    price: Decimal | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedMenuItemMaxAggregateOutputType = {
    id: number | null
    vendorId: number | null
    menuCategoryId: number | null
    menuSubCategoryId: number | null
    productName: string | null
    image: string | null
    price: Decimal | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedMenuItemCountAggregateOutputType = {
    id: number
    vendorId: number
    menuCategoryId: number
    menuSubCategoryId: number
    productName: number
    image: number
    price: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SharedMenuItemAvgAggregateInputType = {
    id?: true
    vendorId?: true
    menuCategoryId?: true
    menuSubCategoryId?: true
    price?: true
  }

  export type SharedMenuItemSumAggregateInputType = {
    id?: true
    vendorId?: true
    menuCategoryId?: true
    menuSubCategoryId?: true
    price?: true
  }

  export type SharedMenuItemMinAggregateInputType = {
    id?: true
    vendorId?: true
    menuCategoryId?: true
    menuSubCategoryId?: true
    productName?: true
    image?: true
    price?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedMenuItemMaxAggregateInputType = {
    id?: true
    vendorId?: true
    menuCategoryId?: true
    menuSubCategoryId?: true
    productName?: true
    image?: true
    price?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedMenuItemCountAggregateInputType = {
    id?: true
    vendorId?: true
    menuCategoryId?: true
    menuSubCategoryId?: true
    productName?: true
    image?: true
    price?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SharedMenuItemAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedMenuItem to aggregate.
     */
    where?: SharedMenuItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuItems to fetch.
     */
    orderBy?: SharedMenuItemOrderByWithRelationInput | SharedMenuItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SharedMenuItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SharedMenuItems
    **/
    _count?: true | SharedMenuItemCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SharedMenuItemAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SharedMenuItemSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SharedMenuItemMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SharedMenuItemMaxAggregateInputType
  }

  export type GetSharedMenuItemAggregateType<T extends SharedMenuItemAggregateArgs> = {
        [P in keyof T & keyof AggregateSharedMenuItem]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSharedMenuItem[P]>
      : GetScalarType<T[P], AggregateSharedMenuItem[P]>
  }




  export type SharedMenuItemGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedMenuItemWhereInput
    orderBy?: SharedMenuItemOrderByWithAggregationInput | SharedMenuItemOrderByWithAggregationInput[]
    by: SharedMenuItemScalarFieldEnum[] | SharedMenuItemScalarFieldEnum
    having?: SharedMenuItemScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SharedMenuItemCountAggregateInputType | true
    _avg?: SharedMenuItemAvgAggregateInputType
    _sum?: SharedMenuItemSumAggregateInputType
    _min?: SharedMenuItemMinAggregateInputType
    _max?: SharedMenuItemMaxAggregateInputType
  }

  export type SharedMenuItemGroupByOutputType = {
    id: number
    vendorId: number
    menuCategoryId: number
    menuSubCategoryId: number | null
    productName: string
    image: string | null
    price: Decimal
    createdAt: Date | null
    updatedAt: Date | null
    _count: SharedMenuItemCountAggregateOutputType | null
    _avg: SharedMenuItemAvgAggregateOutputType | null
    _sum: SharedMenuItemSumAggregateOutputType | null
    _min: SharedMenuItemMinAggregateOutputType | null
    _max: SharedMenuItemMaxAggregateOutputType | null
  }

  type GetSharedMenuItemGroupByPayload<T extends SharedMenuItemGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SharedMenuItemGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SharedMenuItemGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SharedMenuItemGroupByOutputType[P]>
            : GetScalarType<T[P], SharedMenuItemGroupByOutputType[P]>
        }
      >
    >


  export type SharedMenuItemSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    vendorId?: boolean
    menuCategoryId?: boolean
    menuSubCategoryId?: boolean
    productName?: boolean
    image?: boolean
    price?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    category?: boolean | SharedMenuCategoryDefaultArgs<ExtArgs>
    subCategory?: boolean | SharedMenuItem$subCategoryArgs<ExtArgs>
  }, ExtArgs["result"]["sharedMenuItem"]>



  export type SharedMenuItemSelectScalar = {
    id?: boolean
    vendorId?: boolean
    menuCategoryId?: boolean
    menuSubCategoryId?: boolean
    productName?: boolean
    image?: boolean
    price?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SharedMenuItemOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "vendorId" | "menuCategoryId" | "menuSubCategoryId" | "productName" | "image" | "price" | "createdAt" | "updatedAt", ExtArgs["result"]["sharedMenuItem"]>
  export type SharedMenuItemInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    category?: boolean | SharedMenuCategoryDefaultArgs<ExtArgs>
    subCategory?: boolean | SharedMenuItem$subCategoryArgs<ExtArgs>
  }

  export type $SharedMenuItemPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SharedMenuItem"
    objects: {
      vendor: Prisma.$SharedVendorPayload<ExtArgs>
      category: Prisma.$SharedMenuCategoryPayload<ExtArgs>
      subCategory: Prisma.$SharedMenuSubCategoryPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      vendorId: number
      menuCategoryId: number
      menuSubCategoryId: number | null
      productName: string
      image: string | null
      price: Prisma.Decimal
      createdAt: Date | null
      updatedAt: Date | null
    }, ExtArgs["result"]["sharedMenuItem"]>
    composites: {}
  }

  type SharedMenuItemGetPayload<S extends boolean | null | undefined | SharedMenuItemDefaultArgs> = $Result.GetResult<Prisma.$SharedMenuItemPayload, S>

  type SharedMenuItemCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SharedMenuItemFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SharedMenuItemCountAggregateInputType | true
    }

  export interface SharedMenuItemDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SharedMenuItem'], meta: { name: 'SharedMenuItem' } }
    /**
     * Find zero or one SharedMenuItem that matches the filter.
     * @param {SharedMenuItemFindUniqueArgs} args - Arguments to find a SharedMenuItem
     * @example
     * // Get one SharedMenuItem
     * const sharedMenuItem = await prisma.sharedMenuItem.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SharedMenuItemFindUniqueArgs>(args: SelectSubset<T, SharedMenuItemFindUniqueArgs<ExtArgs>>): Prisma__SharedMenuItemClient<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SharedMenuItem that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SharedMenuItemFindUniqueOrThrowArgs} args - Arguments to find a SharedMenuItem
     * @example
     * // Get one SharedMenuItem
     * const sharedMenuItem = await prisma.sharedMenuItem.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SharedMenuItemFindUniqueOrThrowArgs>(args: SelectSubset<T, SharedMenuItemFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SharedMenuItemClient<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedMenuItem that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuItemFindFirstArgs} args - Arguments to find a SharedMenuItem
     * @example
     * // Get one SharedMenuItem
     * const sharedMenuItem = await prisma.sharedMenuItem.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SharedMenuItemFindFirstArgs>(args?: SelectSubset<T, SharedMenuItemFindFirstArgs<ExtArgs>>): Prisma__SharedMenuItemClient<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedMenuItem that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuItemFindFirstOrThrowArgs} args - Arguments to find a SharedMenuItem
     * @example
     * // Get one SharedMenuItem
     * const sharedMenuItem = await prisma.sharedMenuItem.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SharedMenuItemFindFirstOrThrowArgs>(args?: SelectSubset<T, SharedMenuItemFindFirstOrThrowArgs<ExtArgs>>): Prisma__SharedMenuItemClient<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SharedMenuItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuItemFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SharedMenuItems
     * const sharedMenuItems = await prisma.sharedMenuItem.findMany()
     * 
     * // Get first 10 SharedMenuItems
     * const sharedMenuItems = await prisma.sharedMenuItem.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sharedMenuItemWithIdOnly = await prisma.sharedMenuItem.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SharedMenuItemFindManyArgs>(args?: SelectSubset<T, SharedMenuItemFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SharedMenuItem.
     * @param {SharedMenuItemCreateArgs} args - Arguments to create a SharedMenuItem.
     * @example
     * // Create one SharedMenuItem
     * const SharedMenuItem = await prisma.sharedMenuItem.create({
     *   data: {
     *     // ... data to create a SharedMenuItem
     *   }
     * })
     * 
     */
    create<T extends SharedMenuItemCreateArgs>(args: SelectSubset<T, SharedMenuItemCreateArgs<ExtArgs>>): Prisma__SharedMenuItemClient<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SharedMenuItems.
     * @param {SharedMenuItemCreateManyArgs} args - Arguments to create many SharedMenuItems.
     * @example
     * // Create many SharedMenuItems
     * const sharedMenuItem = await prisma.sharedMenuItem.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SharedMenuItemCreateManyArgs>(args?: SelectSubset<T, SharedMenuItemCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SharedMenuItem.
     * @param {SharedMenuItemDeleteArgs} args - Arguments to delete one SharedMenuItem.
     * @example
     * // Delete one SharedMenuItem
     * const SharedMenuItem = await prisma.sharedMenuItem.delete({
     *   where: {
     *     // ... filter to delete one SharedMenuItem
     *   }
     * })
     * 
     */
    delete<T extends SharedMenuItemDeleteArgs>(args: SelectSubset<T, SharedMenuItemDeleteArgs<ExtArgs>>): Prisma__SharedMenuItemClient<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SharedMenuItem.
     * @param {SharedMenuItemUpdateArgs} args - Arguments to update one SharedMenuItem.
     * @example
     * // Update one SharedMenuItem
     * const sharedMenuItem = await prisma.sharedMenuItem.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SharedMenuItemUpdateArgs>(args: SelectSubset<T, SharedMenuItemUpdateArgs<ExtArgs>>): Prisma__SharedMenuItemClient<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SharedMenuItems.
     * @param {SharedMenuItemDeleteManyArgs} args - Arguments to filter SharedMenuItems to delete.
     * @example
     * // Delete a few SharedMenuItems
     * const { count } = await prisma.sharedMenuItem.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SharedMenuItemDeleteManyArgs>(args?: SelectSubset<T, SharedMenuItemDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SharedMenuItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuItemUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SharedMenuItems
     * const sharedMenuItem = await prisma.sharedMenuItem.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SharedMenuItemUpdateManyArgs>(args: SelectSubset<T, SharedMenuItemUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SharedMenuItem.
     * @param {SharedMenuItemUpsertArgs} args - Arguments to update or create a SharedMenuItem.
     * @example
     * // Update or create a SharedMenuItem
     * const sharedMenuItem = await prisma.sharedMenuItem.upsert({
     *   create: {
     *     // ... data to create a SharedMenuItem
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SharedMenuItem we want to update
     *   }
     * })
     */
    upsert<T extends SharedMenuItemUpsertArgs>(args: SelectSubset<T, SharedMenuItemUpsertArgs<ExtArgs>>): Prisma__SharedMenuItemClient<$Result.GetResult<Prisma.$SharedMenuItemPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SharedMenuItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuItemCountArgs} args - Arguments to filter SharedMenuItems to count.
     * @example
     * // Count the number of SharedMenuItems
     * const count = await prisma.sharedMenuItem.count({
     *   where: {
     *     // ... the filter for the SharedMenuItems we want to count
     *   }
     * })
    **/
    count<T extends SharedMenuItemCountArgs>(
      args?: Subset<T, SharedMenuItemCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SharedMenuItemCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SharedMenuItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuItemAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SharedMenuItemAggregateArgs>(args: Subset<T, SharedMenuItemAggregateArgs>): Prisma.PrismaPromise<GetSharedMenuItemAggregateType<T>>

    /**
     * Group by SharedMenuItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedMenuItemGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SharedMenuItemGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SharedMenuItemGroupByArgs['orderBy'] }
        : { orderBy?: SharedMenuItemGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SharedMenuItemGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSharedMenuItemGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SharedMenuItem model
   */
  readonly fields: SharedMenuItemFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SharedMenuItem.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SharedMenuItemClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    vendor<T extends SharedVendorDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendorDefaultArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    category<T extends SharedMenuCategoryDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedMenuCategoryDefaultArgs<ExtArgs>>): Prisma__SharedMenuCategoryClient<$Result.GetResult<Prisma.$SharedMenuCategoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    subCategory<T extends SharedMenuItem$subCategoryArgs<ExtArgs> = {}>(args?: Subset<T, SharedMenuItem$subCategoryArgs<ExtArgs>>): Prisma__SharedMenuSubCategoryClient<$Result.GetResult<Prisma.$SharedMenuSubCategoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SharedMenuItem model
   */
  interface SharedMenuItemFieldRefs {
    readonly id: FieldRef<"SharedMenuItem", 'Int'>
    readonly vendorId: FieldRef<"SharedMenuItem", 'Int'>
    readonly menuCategoryId: FieldRef<"SharedMenuItem", 'Int'>
    readonly menuSubCategoryId: FieldRef<"SharedMenuItem", 'Int'>
    readonly productName: FieldRef<"SharedMenuItem", 'String'>
    readonly image: FieldRef<"SharedMenuItem", 'String'>
    readonly price: FieldRef<"SharedMenuItem", 'Decimal'>
    readonly createdAt: FieldRef<"SharedMenuItem", 'DateTime'>
    readonly updatedAt: FieldRef<"SharedMenuItem", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SharedMenuItem findUnique
   */
  export type SharedMenuItemFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuItem to fetch.
     */
    where: SharedMenuItemWhereUniqueInput
  }

  /**
   * SharedMenuItem findUniqueOrThrow
   */
  export type SharedMenuItemFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuItem to fetch.
     */
    where: SharedMenuItemWhereUniqueInput
  }

  /**
   * SharedMenuItem findFirst
   */
  export type SharedMenuItemFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuItem to fetch.
     */
    where?: SharedMenuItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuItems to fetch.
     */
    orderBy?: SharedMenuItemOrderByWithRelationInput | SharedMenuItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedMenuItems.
     */
    cursor?: SharedMenuItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedMenuItems.
     */
    distinct?: SharedMenuItemScalarFieldEnum | SharedMenuItemScalarFieldEnum[]
  }

  /**
   * SharedMenuItem findFirstOrThrow
   */
  export type SharedMenuItemFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuItem to fetch.
     */
    where?: SharedMenuItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuItems to fetch.
     */
    orderBy?: SharedMenuItemOrderByWithRelationInput | SharedMenuItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedMenuItems.
     */
    cursor?: SharedMenuItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedMenuItems.
     */
    distinct?: SharedMenuItemScalarFieldEnum | SharedMenuItemScalarFieldEnum[]
  }

  /**
   * SharedMenuItem findMany
   */
  export type SharedMenuItemFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * Filter, which SharedMenuItems to fetch.
     */
    where?: SharedMenuItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedMenuItems to fetch.
     */
    orderBy?: SharedMenuItemOrderByWithRelationInput | SharedMenuItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SharedMenuItems.
     */
    cursor?: SharedMenuItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedMenuItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedMenuItems.
     */
    skip?: number
    distinct?: SharedMenuItemScalarFieldEnum | SharedMenuItemScalarFieldEnum[]
  }

  /**
   * SharedMenuItem create
   */
  export type SharedMenuItemCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * The data needed to create a SharedMenuItem.
     */
    data: XOR<SharedMenuItemCreateInput, SharedMenuItemUncheckedCreateInput>
  }

  /**
   * SharedMenuItem createMany
   */
  export type SharedMenuItemCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SharedMenuItems.
     */
    data: SharedMenuItemCreateManyInput | SharedMenuItemCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SharedMenuItem update
   */
  export type SharedMenuItemUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * The data needed to update a SharedMenuItem.
     */
    data: XOR<SharedMenuItemUpdateInput, SharedMenuItemUncheckedUpdateInput>
    /**
     * Choose, which SharedMenuItem to update.
     */
    where: SharedMenuItemWhereUniqueInput
  }

  /**
   * SharedMenuItem updateMany
   */
  export type SharedMenuItemUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SharedMenuItems.
     */
    data: XOR<SharedMenuItemUpdateManyMutationInput, SharedMenuItemUncheckedUpdateManyInput>
    /**
     * Filter which SharedMenuItems to update
     */
    where?: SharedMenuItemWhereInput
    /**
     * Limit how many SharedMenuItems to update.
     */
    limit?: number
  }

  /**
   * SharedMenuItem upsert
   */
  export type SharedMenuItemUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * The filter to search for the SharedMenuItem to update in case it exists.
     */
    where: SharedMenuItemWhereUniqueInput
    /**
     * In case the SharedMenuItem found by the `where` argument doesn't exist, create a new SharedMenuItem with this data.
     */
    create: XOR<SharedMenuItemCreateInput, SharedMenuItemUncheckedCreateInput>
    /**
     * In case the SharedMenuItem was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SharedMenuItemUpdateInput, SharedMenuItemUncheckedUpdateInput>
  }

  /**
   * SharedMenuItem delete
   */
  export type SharedMenuItemDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
    /**
     * Filter which SharedMenuItem to delete.
     */
    where: SharedMenuItemWhereUniqueInput
  }

  /**
   * SharedMenuItem deleteMany
   */
  export type SharedMenuItemDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedMenuItems to delete
     */
    where?: SharedMenuItemWhereInput
    /**
     * Limit how many SharedMenuItems to delete.
     */
    limit?: number
  }

  /**
   * SharedMenuItem.subCategory
   */
  export type SharedMenuItem$subCategoryArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuSubCategory
     */
    select?: SharedMenuSubCategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuSubCategory
     */
    omit?: SharedMenuSubCategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuSubCategoryInclude<ExtArgs> | null
    where?: SharedMenuSubCategoryWhereInput
  }

  /**
   * SharedMenuItem without action
   */
  export type SharedMenuItemDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedMenuItem
     */
    select?: SharedMenuItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedMenuItem
     */
    omit?: SharedMenuItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedMenuItemInclude<ExtArgs> | null
  }


  /**
   * Model SharedOffer
   */

  export type AggregateSharedOffer = {
    _count: SharedOfferCountAggregateOutputType | null
    _avg: SharedOfferAvgAggregateOutputType | null
    _sum: SharedOfferSumAggregateOutputType | null
    _min: SharedOfferMinAggregateOutputType | null
    _max: SharedOfferMaxAggregateOutputType | null
  }

  export type SharedOfferAvgAggregateOutputType = {
    id: number | null
    vendorId: number | null
    offerTargetId: number | null
  }

  export type SharedOfferSumAggregateOutputType = {
    id: number | null
    vendorId: number | null
    offerTargetId: number | null
  }

  export type SharedOfferMinAggregateOutputType = {
    id: number | null
    vendorId: number | null
    offerTargetType: string | null
    offerTargetId: number | null
    offerType: string | null
    validityFrom: Date | null
    validityTo: Date | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedOfferMaxAggregateOutputType = {
    id: number | null
    vendorId: number | null
    offerTargetType: string | null
    offerTargetId: number | null
    offerType: string | null
    validityFrom: Date | null
    validityTo: Date | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedOfferCountAggregateOutputType = {
    id: number
    vendorId: number
    offerTargetType: number
    offerTargetId: number
    offerType: number
    offerValue: number
    validityFrom: number
    validityTo: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SharedOfferAvgAggregateInputType = {
    id?: true
    vendorId?: true
    offerTargetId?: true
  }

  export type SharedOfferSumAggregateInputType = {
    id?: true
    vendorId?: true
    offerTargetId?: true
  }

  export type SharedOfferMinAggregateInputType = {
    id?: true
    vendorId?: true
    offerTargetType?: true
    offerTargetId?: true
    offerType?: true
    validityFrom?: true
    validityTo?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedOfferMaxAggregateInputType = {
    id?: true
    vendorId?: true
    offerTargetType?: true
    offerTargetId?: true
    offerType?: true
    validityFrom?: true
    validityTo?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedOfferCountAggregateInputType = {
    id?: true
    vendorId?: true
    offerTargetType?: true
    offerTargetId?: true
    offerType?: true
    offerValue?: true
    validityFrom?: true
    validityTo?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SharedOfferAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedOffer to aggregate.
     */
    where?: SharedOfferWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedOffers to fetch.
     */
    orderBy?: SharedOfferOrderByWithRelationInput | SharedOfferOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SharedOfferWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedOffers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedOffers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SharedOffers
    **/
    _count?: true | SharedOfferCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SharedOfferAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SharedOfferSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SharedOfferMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SharedOfferMaxAggregateInputType
  }

  export type GetSharedOfferAggregateType<T extends SharedOfferAggregateArgs> = {
        [P in keyof T & keyof AggregateSharedOffer]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSharedOffer[P]>
      : GetScalarType<T[P], AggregateSharedOffer[P]>
  }




  export type SharedOfferGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedOfferWhereInput
    orderBy?: SharedOfferOrderByWithAggregationInput | SharedOfferOrderByWithAggregationInput[]
    by: SharedOfferScalarFieldEnum[] | SharedOfferScalarFieldEnum
    having?: SharedOfferScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SharedOfferCountAggregateInputType | true
    _avg?: SharedOfferAvgAggregateInputType
    _sum?: SharedOfferSumAggregateInputType
    _min?: SharedOfferMinAggregateInputType
    _max?: SharedOfferMaxAggregateInputType
  }

  export type SharedOfferGroupByOutputType = {
    id: number
    vendorId: number
    offerTargetType: string | null
    offerTargetId: number | null
    offerType: string
    offerValue: JsonValue | null
    validityFrom: Date | null
    validityTo: Date | null
    createdAt: Date | null
    updatedAt: Date | null
    _count: SharedOfferCountAggregateOutputType | null
    _avg: SharedOfferAvgAggregateOutputType | null
    _sum: SharedOfferSumAggregateOutputType | null
    _min: SharedOfferMinAggregateOutputType | null
    _max: SharedOfferMaxAggregateOutputType | null
  }

  type GetSharedOfferGroupByPayload<T extends SharedOfferGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SharedOfferGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SharedOfferGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SharedOfferGroupByOutputType[P]>
            : GetScalarType<T[P], SharedOfferGroupByOutputType[P]>
        }
      >
    >


  export type SharedOfferSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    vendorId?: boolean
    offerTargetType?: boolean
    offerTargetId?: boolean
    offerType?: boolean
    offerValue?: boolean
    validityFrom?: boolean
    validityTo?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    posts?: boolean | SharedOffer$postsArgs<ExtArgs>
    _count?: boolean | SharedOfferCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["sharedOffer"]>



  export type SharedOfferSelectScalar = {
    id?: boolean
    vendorId?: boolean
    offerTargetType?: boolean
    offerTargetId?: boolean
    offerType?: boolean
    offerValue?: boolean
    validityFrom?: boolean
    validityTo?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SharedOfferOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "vendorId" | "offerTargetType" | "offerTargetId" | "offerType" | "offerValue" | "validityFrom" | "validityTo" | "createdAt" | "updatedAt", ExtArgs["result"]["sharedOffer"]>
  export type SharedOfferInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    posts?: boolean | SharedOffer$postsArgs<ExtArgs>
    _count?: boolean | SharedOfferCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $SharedOfferPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SharedOffer"
    objects: {
      vendor: Prisma.$SharedVendorPayload<ExtArgs>
      posts: Prisma.$SharedPostPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      vendorId: number
      offerTargetType: string | null
      offerTargetId: number | null
      offerType: string
      offerValue: Prisma.JsonValue | null
      validityFrom: Date | null
      validityTo: Date | null
      createdAt: Date | null
      updatedAt: Date | null
    }, ExtArgs["result"]["sharedOffer"]>
    composites: {}
  }

  type SharedOfferGetPayload<S extends boolean | null | undefined | SharedOfferDefaultArgs> = $Result.GetResult<Prisma.$SharedOfferPayload, S>

  type SharedOfferCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SharedOfferFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SharedOfferCountAggregateInputType | true
    }

  export interface SharedOfferDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SharedOffer'], meta: { name: 'SharedOffer' } }
    /**
     * Find zero or one SharedOffer that matches the filter.
     * @param {SharedOfferFindUniqueArgs} args - Arguments to find a SharedOffer
     * @example
     * // Get one SharedOffer
     * const sharedOffer = await prisma.sharedOffer.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SharedOfferFindUniqueArgs>(args: SelectSubset<T, SharedOfferFindUniqueArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SharedOffer that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SharedOfferFindUniqueOrThrowArgs} args - Arguments to find a SharedOffer
     * @example
     * // Get one SharedOffer
     * const sharedOffer = await prisma.sharedOffer.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SharedOfferFindUniqueOrThrowArgs>(args: SelectSubset<T, SharedOfferFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedOffer that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedOfferFindFirstArgs} args - Arguments to find a SharedOffer
     * @example
     * // Get one SharedOffer
     * const sharedOffer = await prisma.sharedOffer.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SharedOfferFindFirstArgs>(args?: SelectSubset<T, SharedOfferFindFirstArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedOffer that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedOfferFindFirstOrThrowArgs} args - Arguments to find a SharedOffer
     * @example
     * // Get one SharedOffer
     * const sharedOffer = await prisma.sharedOffer.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SharedOfferFindFirstOrThrowArgs>(args?: SelectSubset<T, SharedOfferFindFirstOrThrowArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SharedOffers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedOfferFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SharedOffers
     * const sharedOffers = await prisma.sharedOffer.findMany()
     * 
     * // Get first 10 SharedOffers
     * const sharedOffers = await prisma.sharedOffer.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sharedOfferWithIdOnly = await prisma.sharedOffer.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SharedOfferFindManyArgs>(args?: SelectSubset<T, SharedOfferFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SharedOffer.
     * @param {SharedOfferCreateArgs} args - Arguments to create a SharedOffer.
     * @example
     * // Create one SharedOffer
     * const SharedOffer = await prisma.sharedOffer.create({
     *   data: {
     *     // ... data to create a SharedOffer
     *   }
     * })
     * 
     */
    create<T extends SharedOfferCreateArgs>(args: SelectSubset<T, SharedOfferCreateArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SharedOffers.
     * @param {SharedOfferCreateManyArgs} args - Arguments to create many SharedOffers.
     * @example
     * // Create many SharedOffers
     * const sharedOffer = await prisma.sharedOffer.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SharedOfferCreateManyArgs>(args?: SelectSubset<T, SharedOfferCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SharedOffer.
     * @param {SharedOfferDeleteArgs} args - Arguments to delete one SharedOffer.
     * @example
     * // Delete one SharedOffer
     * const SharedOffer = await prisma.sharedOffer.delete({
     *   where: {
     *     // ... filter to delete one SharedOffer
     *   }
     * })
     * 
     */
    delete<T extends SharedOfferDeleteArgs>(args: SelectSubset<T, SharedOfferDeleteArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SharedOffer.
     * @param {SharedOfferUpdateArgs} args - Arguments to update one SharedOffer.
     * @example
     * // Update one SharedOffer
     * const sharedOffer = await prisma.sharedOffer.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SharedOfferUpdateArgs>(args: SelectSubset<T, SharedOfferUpdateArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SharedOffers.
     * @param {SharedOfferDeleteManyArgs} args - Arguments to filter SharedOffers to delete.
     * @example
     * // Delete a few SharedOffers
     * const { count } = await prisma.sharedOffer.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SharedOfferDeleteManyArgs>(args?: SelectSubset<T, SharedOfferDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SharedOffers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedOfferUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SharedOffers
     * const sharedOffer = await prisma.sharedOffer.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SharedOfferUpdateManyArgs>(args: SelectSubset<T, SharedOfferUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SharedOffer.
     * @param {SharedOfferUpsertArgs} args - Arguments to update or create a SharedOffer.
     * @example
     * // Update or create a SharedOffer
     * const sharedOffer = await prisma.sharedOffer.upsert({
     *   create: {
     *     // ... data to create a SharedOffer
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SharedOffer we want to update
     *   }
     * })
     */
    upsert<T extends SharedOfferUpsertArgs>(args: SelectSubset<T, SharedOfferUpsertArgs<ExtArgs>>): Prisma__SharedOfferClient<$Result.GetResult<Prisma.$SharedOfferPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SharedOffers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedOfferCountArgs} args - Arguments to filter SharedOffers to count.
     * @example
     * // Count the number of SharedOffers
     * const count = await prisma.sharedOffer.count({
     *   where: {
     *     // ... the filter for the SharedOffers we want to count
     *   }
     * })
    **/
    count<T extends SharedOfferCountArgs>(
      args?: Subset<T, SharedOfferCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SharedOfferCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SharedOffer.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedOfferAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SharedOfferAggregateArgs>(args: Subset<T, SharedOfferAggregateArgs>): Prisma.PrismaPromise<GetSharedOfferAggregateType<T>>

    /**
     * Group by SharedOffer.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedOfferGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SharedOfferGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SharedOfferGroupByArgs['orderBy'] }
        : { orderBy?: SharedOfferGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SharedOfferGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSharedOfferGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SharedOffer model
   */
  readonly fields: SharedOfferFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SharedOffer.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SharedOfferClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    vendor<T extends SharedVendorDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendorDefaultArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    posts<T extends SharedOffer$postsArgs<ExtArgs> = {}>(args?: Subset<T, SharedOffer$postsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedPostPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SharedOffer model
   */
  interface SharedOfferFieldRefs {
    readonly id: FieldRef<"SharedOffer", 'Int'>
    readonly vendorId: FieldRef<"SharedOffer", 'Int'>
    readonly offerTargetType: FieldRef<"SharedOffer", 'String'>
    readonly offerTargetId: FieldRef<"SharedOffer", 'Int'>
    readonly offerType: FieldRef<"SharedOffer", 'String'>
    readonly offerValue: FieldRef<"SharedOffer", 'Json'>
    readonly validityFrom: FieldRef<"SharedOffer", 'DateTime'>
    readonly validityTo: FieldRef<"SharedOffer", 'DateTime'>
    readonly createdAt: FieldRef<"SharedOffer", 'DateTime'>
    readonly updatedAt: FieldRef<"SharedOffer", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SharedOffer findUnique
   */
  export type SharedOfferFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * Filter, which SharedOffer to fetch.
     */
    where: SharedOfferWhereUniqueInput
  }

  /**
   * SharedOffer findUniqueOrThrow
   */
  export type SharedOfferFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * Filter, which SharedOffer to fetch.
     */
    where: SharedOfferWhereUniqueInput
  }

  /**
   * SharedOffer findFirst
   */
  export type SharedOfferFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * Filter, which SharedOffer to fetch.
     */
    where?: SharedOfferWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedOffers to fetch.
     */
    orderBy?: SharedOfferOrderByWithRelationInput | SharedOfferOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedOffers.
     */
    cursor?: SharedOfferWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedOffers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedOffers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedOffers.
     */
    distinct?: SharedOfferScalarFieldEnum | SharedOfferScalarFieldEnum[]
  }

  /**
   * SharedOffer findFirstOrThrow
   */
  export type SharedOfferFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * Filter, which SharedOffer to fetch.
     */
    where?: SharedOfferWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedOffers to fetch.
     */
    orderBy?: SharedOfferOrderByWithRelationInput | SharedOfferOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedOffers.
     */
    cursor?: SharedOfferWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedOffers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedOffers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedOffers.
     */
    distinct?: SharedOfferScalarFieldEnum | SharedOfferScalarFieldEnum[]
  }

  /**
   * SharedOffer findMany
   */
  export type SharedOfferFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * Filter, which SharedOffers to fetch.
     */
    where?: SharedOfferWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedOffers to fetch.
     */
    orderBy?: SharedOfferOrderByWithRelationInput | SharedOfferOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SharedOffers.
     */
    cursor?: SharedOfferWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedOffers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedOffers.
     */
    skip?: number
    distinct?: SharedOfferScalarFieldEnum | SharedOfferScalarFieldEnum[]
  }

  /**
   * SharedOffer create
   */
  export type SharedOfferCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * The data needed to create a SharedOffer.
     */
    data: XOR<SharedOfferCreateInput, SharedOfferUncheckedCreateInput>
  }

  /**
   * SharedOffer createMany
   */
  export type SharedOfferCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SharedOffers.
     */
    data: SharedOfferCreateManyInput | SharedOfferCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SharedOffer update
   */
  export type SharedOfferUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * The data needed to update a SharedOffer.
     */
    data: XOR<SharedOfferUpdateInput, SharedOfferUncheckedUpdateInput>
    /**
     * Choose, which SharedOffer to update.
     */
    where: SharedOfferWhereUniqueInput
  }

  /**
   * SharedOffer updateMany
   */
  export type SharedOfferUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SharedOffers.
     */
    data: XOR<SharedOfferUpdateManyMutationInput, SharedOfferUncheckedUpdateManyInput>
    /**
     * Filter which SharedOffers to update
     */
    where?: SharedOfferWhereInput
    /**
     * Limit how many SharedOffers to update.
     */
    limit?: number
  }

  /**
   * SharedOffer upsert
   */
  export type SharedOfferUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * The filter to search for the SharedOffer to update in case it exists.
     */
    where: SharedOfferWhereUniqueInput
    /**
     * In case the SharedOffer found by the `where` argument doesn't exist, create a new SharedOffer with this data.
     */
    create: XOR<SharedOfferCreateInput, SharedOfferUncheckedCreateInput>
    /**
     * In case the SharedOffer was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SharedOfferUpdateInput, SharedOfferUncheckedUpdateInput>
  }

  /**
   * SharedOffer delete
   */
  export type SharedOfferDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
    /**
     * Filter which SharedOffer to delete.
     */
    where: SharedOfferWhereUniqueInput
  }

  /**
   * SharedOffer deleteMany
   */
  export type SharedOfferDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedOffers to delete
     */
    where?: SharedOfferWhereInput
    /**
     * Limit how many SharedOffers to delete.
     */
    limit?: number
  }

  /**
   * SharedOffer.posts
   */
  export type SharedOffer$postsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedPost
     */
    select?: SharedPostSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedPost
     */
    omit?: SharedPostOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedPostInclude<ExtArgs> | null
    where?: SharedPostWhereInput
    orderBy?: SharedPostOrderByWithRelationInput | SharedPostOrderByWithRelationInput[]
    cursor?: SharedPostWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SharedPostScalarFieldEnum | SharedPostScalarFieldEnum[]
  }

  /**
   * SharedOffer without action
   */
  export type SharedOfferDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedOffer
     */
    select?: SharedOfferSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedOffer
     */
    omit?: SharedOfferOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedOfferInclude<ExtArgs> | null
  }


  /**
   * Model SharedBill
   */

  export type AggregateSharedBill = {
    _count: SharedBillCountAggregateOutputType | null
    _avg: SharedBillAvgAggregateOutputType | null
    _sum: SharedBillSumAggregateOutputType | null
    _min: SharedBillMinAggregateOutputType | null
    _max: SharedBillMaxAggregateOutputType | null
  }

  export type SharedBillAvgAggregateOutputType = {
    id: number | null
    vendorId: number | null
    endUserId: number | null
    totalPrice: Decimal | null
  }

  export type SharedBillSumAggregateOutputType = {
    id: number | null
    vendorId: number | null
    endUserId: number | null
    totalPrice: Decimal | null
  }

  export type SharedBillMinAggregateOutputType = {
    id: number | null
    vendorId: number | null
    endUserId: number | null
    totalPrice: Decimal | null
    paymentStatus: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedBillMaxAggregateOutputType = {
    id: number | null
    vendorId: number | null
    endUserId: number | null
    totalPrice: Decimal | null
    paymentStatus: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SharedBillCountAggregateOutputType = {
    id: number
    vendorId: number
    endUserId: number
    products: number
    totalPrice: number
    paymentStatus: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SharedBillAvgAggregateInputType = {
    id?: true
    vendorId?: true
    endUserId?: true
    totalPrice?: true
  }

  export type SharedBillSumAggregateInputType = {
    id?: true
    vendorId?: true
    endUserId?: true
    totalPrice?: true
  }

  export type SharedBillMinAggregateInputType = {
    id?: true
    vendorId?: true
    endUserId?: true
    totalPrice?: true
    paymentStatus?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedBillMaxAggregateInputType = {
    id?: true
    vendorId?: true
    endUserId?: true
    totalPrice?: true
    paymentStatus?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SharedBillCountAggregateInputType = {
    id?: true
    vendorId?: true
    endUserId?: true
    products?: true
    totalPrice?: true
    paymentStatus?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SharedBillAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedBill to aggregate.
     */
    where?: SharedBillWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedBills to fetch.
     */
    orderBy?: SharedBillOrderByWithRelationInput | SharedBillOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SharedBillWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedBills from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedBills.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SharedBills
    **/
    _count?: true | SharedBillCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SharedBillAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SharedBillSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SharedBillMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SharedBillMaxAggregateInputType
  }

  export type GetSharedBillAggregateType<T extends SharedBillAggregateArgs> = {
        [P in keyof T & keyof AggregateSharedBill]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSharedBill[P]>
      : GetScalarType<T[P], AggregateSharedBill[P]>
  }




  export type SharedBillGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SharedBillWhereInput
    orderBy?: SharedBillOrderByWithAggregationInput | SharedBillOrderByWithAggregationInput[]
    by: SharedBillScalarFieldEnum[] | SharedBillScalarFieldEnum
    having?: SharedBillScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SharedBillCountAggregateInputType | true
    _avg?: SharedBillAvgAggregateInputType
    _sum?: SharedBillSumAggregateInputType
    _min?: SharedBillMinAggregateInputType
    _max?: SharedBillMaxAggregateInputType
  }

  export type SharedBillGroupByOutputType = {
    id: number
    vendorId: number
    endUserId: number | null
    products: JsonValue
    totalPrice: Decimal
    paymentStatus: string
    createdAt: Date | null
    updatedAt: Date | null
    _count: SharedBillCountAggregateOutputType | null
    _avg: SharedBillAvgAggregateOutputType | null
    _sum: SharedBillSumAggregateOutputType | null
    _min: SharedBillMinAggregateOutputType | null
    _max: SharedBillMaxAggregateOutputType | null
  }

  type GetSharedBillGroupByPayload<T extends SharedBillGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SharedBillGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SharedBillGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SharedBillGroupByOutputType[P]>
            : GetScalarType<T[P], SharedBillGroupByOutputType[P]>
        }
      >
    >


  export type SharedBillSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    vendorId?: boolean
    endUserId?: boolean
    products?: boolean
    totalPrice?: boolean
    paymentStatus?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    endUser?: boolean | SharedBill$endUserArgs<ExtArgs>
  }, ExtArgs["result"]["sharedBill"]>



  export type SharedBillSelectScalar = {
    id?: boolean
    vendorId?: boolean
    endUserId?: boolean
    products?: boolean
    totalPrice?: boolean
    paymentStatus?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SharedBillOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "vendorId" | "endUserId" | "products" | "totalPrice" | "paymentStatus" | "createdAt" | "updatedAt", ExtArgs["result"]["sharedBill"]>
  export type SharedBillInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendor?: boolean | SharedVendorDefaultArgs<ExtArgs>
    endUser?: boolean | SharedBill$endUserArgs<ExtArgs>
  }

  export type $SharedBillPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SharedBill"
    objects: {
      vendor: Prisma.$SharedVendorPayload<ExtArgs>
      endUser: Prisma.$SharedUserPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      vendorId: number
      endUserId: number | null
      products: Prisma.JsonValue
      totalPrice: Prisma.Decimal
      paymentStatus: string
      createdAt: Date | null
      updatedAt: Date | null
    }, ExtArgs["result"]["sharedBill"]>
    composites: {}
  }

  type SharedBillGetPayload<S extends boolean | null | undefined | SharedBillDefaultArgs> = $Result.GetResult<Prisma.$SharedBillPayload, S>

  type SharedBillCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SharedBillFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SharedBillCountAggregateInputType | true
    }

  export interface SharedBillDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SharedBill'], meta: { name: 'SharedBill' } }
    /**
     * Find zero or one SharedBill that matches the filter.
     * @param {SharedBillFindUniqueArgs} args - Arguments to find a SharedBill
     * @example
     * // Get one SharedBill
     * const sharedBill = await prisma.sharedBill.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SharedBillFindUniqueArgs>(args: SelectSubset<T, SharedBillFindUniqueArgs<ExtArgs>>): Prisma__SharedBillClient<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SharedBill that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SharedBillFindUniqueOrThrowArgs} args - Arguments to find a SharedBill
     * @example
     * // Get one SharedBill
     * const sharedBill = await prisma.sharedBill.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SharedBillFindUniqueOrThrowArgs>(args: SelectSubset<T, SharedBillFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SharedBillClient<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedBill that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedBillFindFirstArgs} args - Arguments to find a SharedBill
     * @example
     * // Get one SharedBill
     * const sharedBill = await prisma.sharedBill.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SharedBillFindFirstArgs>(args?: SelectSubset<T, SharedBillFindFirstArgs<ExtArgs>>): Prisma__SharedBillClient<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SharedBill that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedBillFindFirstOrThrowArgs} args - Arguments to find a SharedBill
     * @example
     * // Get one SharedBill
     * const sharedBill = await prisma.sharedBill.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SharedBillFindFirstOrThrowArgs>(args?: SelectSubset<T, SharedBillFindFirstOrThrowArgs<ExtArgs>>): Prisma__SharedBillClient<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SharedBills that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedBillFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SharedBills
     * const sharedBills = await prisma.sharedBill.findMany()
     * 
     * // Get first 10 SharedBills
     * const sharedBills = await prisma.sharedBill.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sharedBillWithIdOnly = await prisma.sharedBill.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SharedBillFindManyArgs>(args?: SelectSubset<T, SharedBillFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SharedBill.
     * @param {SharedBillCreateArgs} args - Arguments to create a SharedBill.
     * @example
     * // Create one SharedBill
     * const SharedBill = await prisma.sharedBill.create({
     *   data: {
     *     // ... data to create a SharedBill
     *   }
     * })
     * 
     */
    create<T extends SharedBillCreateArgs>(args: SelectSubset<T, SharedBillCreateArgs<ExtArgs>>): Prisma__SharedBillClient<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SharedBills.
     * @param {SharedBillCreateManyArgs} args - Arguments to create many SharedBills.
     * @example
     * // Create many SharedBills
     * const sharedBill = await prisma.sharedBill.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SharedBillCreateManyArgs>(args?: SelectSubset<T, SharedBillCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SharedBill.
     * @param {SharedBillDeleteArgs} args - Arguments to delete one SharedBill.
     * @example
     * // Delete one SharedBill
     * const SharedBill = await prisma.sharedBill.delete({
     *   where: {
     *     // ... filter to delete one SharedBill
     *   }
     * })
     * 
     */
    delete<T extends SharedBillDeleteArgs>(args: SelectSubset<T, SharedBillDeleteArgs<ExtArgs>>): Prisma__SharedBillClient<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SharedBill.
     * @param {SharedBillUpdateArgs} args - Arguments to update one SharedBill.
     * @example
     * // Update one SharedBill
     * const sharedBill = await prisma.sharedBill.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SharedBillUpdateArgs>(args: SelectSubset<T, SharedBillUpdateArgs<ExtArgs>>): Prisma__SharedBillClient<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SharedBills.
     * @param {SharedBillDeleteManyArgs} args - Arguments to filter SharedBills to delete.
     * @example
     * // Delete a few SharedBills
     * const { count } = await prisma.sharedBill.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SharedBillDeleteManyArgs>(args?: SelectSubset<T, SharedBillDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SharedBills.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedBillUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SharedBills
     * const sharedBill = await prisma.sharedBill.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SharedBillUpdateManyArgs>(args: SelectSubset<T, SharedBillUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SharedBill.
     * @param {SharedBillUpsertArgs} args - Arguments to update or create a SharedBill.
     * @example
     * // Update or create a SharedBill
     * const sharedBill = await prisma.sharedBill.upsert({
     *   create: {
     *     // ... data to create a SharedBill
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SharedBill we want to update
     *   }
     * })
     */
    upsert<T extends SharedBillUpsertArgs>(args: SelectSubset<T, SharedBillUpsertArgs<ExtArgs>>): Prisma__SharedBillClient<$Result.GetResult<Prisma.$SharedBillPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SharedBills.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedBillCountArgs} args - Arguments to filter SharedBills to count.
     * @example
     * // Count the number of SharedBills
     * const count = await prisma.sharedBill.count({
     *   where: {
     *     // ... the filter for the SharedBills we want to count
     *   }
     * })
    **/
    count<T extends SharedBillCountArgs>(
      args?: Subset<T, SharedBillCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SharedBillCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SharedBill.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedBillAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SharedBillAggregateArgs>(args: Subset<T, SharedBillAggregateArgs>): Prisma.PrismaPromise<GetSharedBillAggregateType<T>>

    /**
     * Group by SharedBill.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SharedBillGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SharedBillGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SharedBillGroupByArgs['orderBy'] }
        : { orderBy?: SharedBillGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SharedBillGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSharedBillGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SharedBill model
   */
  readonly fields: SharedBillFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SharedBill.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SharedBillClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    vendor<T extends SharedVendorDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SharedVendorDefaultArgs<ExtArgs>>): Prisma__SharedVendorClient<$Result.GetResult<Prisma.$SharedVendorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    endUser<T extends SharedBill$endUserArgs<ExtArgs> = {}>(args?: Subset<T, SharedBill$endUserArgs<ExtArgs>>): Prisma__SharedUserClient<$Result.GetResult<Prisma.$SharedUserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SharedBill model
   */
  interface SharedBillFieldRefs {
    readonly id: FieldRef<"SharedBill", 'Int'>
    readonly vendorId: FieldRef<"SharedBill", 'Int'>
    readonly endUserId: FieldRef<"SharedBill", 'Int'>
    readonly products: FieldRef<"SharedBill", 'Json'>
    readonly totalPrice: FieldRef<"SharedBill", 'Decimal'>
    readonly paymentStatus: FieldRef<"SharedBill", 'String'>
    readonly createdAt: FieldRef<"SharedBill", 'DateTime'>
    readonly updatedAt: FieldRef<"SharedBill", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SharedBill findUnique
   */
  export type SharedBillFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * Filter, which SharedBill to fetch.
     */
    where: SharedBillWhereUniqueInput
  }

  /**
   * SharedBill findUniqueOrThrow
   */
  export type SharedBillFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * Filter, which SharedBill to fetch.
     */
    where: SharedBillWhereUniqueInput
  }

  /**
   * SharedBill findFirst
   */
  export type SharedBillFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * Filter, which SharedBill to fetch.
     */
    where?: SharedBillWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedBills to fetch.
     */
    orderBy?: SharedBillOrderByWithRelationInput | SharedBillOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedBills.
     */
    cursor?: SharedBillWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedBills from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedBills.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedBills.
     */
    distinct?: SharedBillScalarFieldEnum | SharedBillScalarFieldEnum[]
  }

  /**
   * SharedBill findFirstOrThrow
   */
  export type SharedBillFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * Filter, which SharedBill to fetch.
     */
    where?: SharedBillWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedBills to fetch.
     */
    orderBy?: SharedBillOrderByWithRelationInput | SharedBillOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SharedBills.
     */
    cursor?: SharedBillWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedBills from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedBills.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SharedBills.
     */
    distinct?: SharedBillScalarFieldEnum | SharedBillScalarFieldEnum[]
  }

  /**
   * SharedBill findMany
   */
  export type SharedBillFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * Filter, which SharedBills to fetch.
     */
    where?: SharedBillWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SharedBills to fetch.
     */
    orderBy?: SharedBillOrderByWithRelationInput | SharedBillOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SharedBills.
     */
    cursor?: SharedBillWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SharedBills from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SharedBills.
     */
    skip?: number
    distinct?: SharedBillScalarFieldEnum | SharedBillScalarFieldEnum[]
  }

  /**
   * SharedBill create
   */
  export type SharedBillCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * The data needed to create a SharedBill.
     */
    data: XOR<SharedBillCreateInput, SharedBillUncheckedCreateInput>
  }

  /**
   * SharedBill createMany
   */
  export type SharedBillCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SharedBills.
     */
    data: SharedBillCreateManyInput | SharedBillCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SharedBill update
   */
  export type SharedBillUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * The data needed to update a SharedBill.
     */
    data: XOR<SharedBillUpdateInput, SharedBillUncheckedUpdateInput>
    /**
     * Choose, which SharedBill to update.
     */
    where: SharedBillWhereUniqueInput
  }

  /**
   * SharedBill updateMany
   */
  export type SharedBillUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SharedBills.
     */
    data: XOR<SharedBillUpdateManyMutationInput, SharedBillUncheckedUpdateManyInput>
    /**
     * Filter which SharedBills to update
     */
    where?: SharedBillWhereInput
    /**
     * Limit how many SharedBills to update.
     */
    limit?: number
  }

  /**
   * SharedBill upsert
   */
  export type SharedBillUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * The filter to search for the SharedBill to update in case it exists.
     */
    where: SharedBillWhereUniqueInput
    /**
     * In case the SharedBill found by the `where` argument doesn't exist, create a new SharedBill with this data.
     */
    create: XOR<SharedBillCreateInput, SharedBillUncheckedCreateInput>
    /**
     * In case the SharedBill was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SharedBillUpdateInput, SharedBillUncheckedUpdateInput>
  }

  /**
   * SharedBill delete
   */
  export type SharedBillDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
    /**
     * Filter which SharedBill to delete.
     */
    where: SharedBillWhereUniqueInput
  }

  /**
   * SharedBill deleteMany
   */
  export type SharedBillDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SharedBills to delete
     */
    where?: SharedBillWhereInput
    /**
     * Limit how many SharedBills to delete.
     */
    limit?: number
  }

  /**
   * SharedBill.endUser
   */
  export type SharedBill$endUserArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedUser
     */
    select?: SharedUserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedUser
     */
    omit?: SharedUserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedUserInclude<ExtArgs> | null
    where?: SharedUserWhereInput
  }

  /**
   * SharedBill without action
   */
  export type SharedBillDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SharedBill
     */
    select?: SharedBillSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SharedBill
     */
    omit?: SharedBillOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SharedBillInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const SharedUserScalarFieldEnum: {
    id: 'id',
    phoneNumber: 'phoneNumber',
    userType: 'userType',
    status: 'status',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SharedUserScalarFieldEnum = (typeof SharedUserScalarFieldEnum)[keyof typeof SharedUserScalarFieldEnum]


  export const SharedVendorScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    businessName: 'businessName',
    status: 'status',
    logoUrl: 'logoUrl',
    businessCategory: 'businessCategory',
    address: 'address',
    payment: 'payment',
    workingDays: 'workingDays',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SharedVendorScalarFieldEnum = (typeof SharedVendorScalarFieldEnum)[keyof typeof SharedVendorScalarFieldEnum]


  export const SharedPostScalarFieldEnum: {
    id: 'id',
    vendorId: 'vendorId',
    postType: 'postType',
    postCategory: 'postCategory',
    postUrl: 'postUrl',
    isOfferIncluded: 'isOfferIncluded',
    offerId: 'offerId',
    isDownloaded: 'isDownloaded',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SharedPostScalarFieldEnum = (typeof SharedPostScalarFieldEnum)[keyof typeof SharedPostScalarFieldEnum]


  export const SharedMenuCategoryScalarFieldEnum: {
    id: 'id',
    vendorId: 'vendorId',
    categoryName: 'categoryName',
    categoryImage: 'categoryImage',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SharedMenuCategoryScalarFieldEnum = (typeof SharedMenuCategoryScalarFieldEnum)[keyof typeof SharedMenuCategoryScalarFieldEnum]


  export const SharedMenuSubCategoryScalarFieldEnum: {
    id: 'id',
    vendorId: 'vendorId',
    categoryId: 'categoryId',
    subCategoryName: 'subCategoryName',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SharedMenuSubCategoryScalarFieldEnum = (typeof SharedMenuSubCategoryScalarFieldEnum)[keyof typeof SharedMenuSubCategoryScalarFieldEnum]


  export const SharedMenuItemScalarFieldEnum: {
    id: 'id',
    vendorId: 'vendorId',
    menuCategoryId: 'menuCategoryId',
    menuSubCategoryId: 'menuSubCategoryId',
    productName: 'productName',
    image: 'image',
    price: 'price',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SharedMenuItemScalarFieldEnum = (typeof SharedMenuItemScalarFieldEnum)[keyof typeof SharedMenuItemScalarFieldEnum]


  export const SharedOfferScalarFieldEnum: {
    id: 'id',
    vendorId: 'vendorId',
    offerTargetType: 'offerTargetType',
    offerTargetId: 'offerTargetId',
    offerType: 'offerType',
    offerValue: 'offerValue',
    validityFrom: 'validityFrom',
    validityTo: 'validityTo',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SharedOfferScalarFieldEnum = (typeof SharedOfferScalarFieldEnum)[keyof typeof SharedOfferScalarFieldEnum]


  export const SharedBillScalarFieldEnum: {
    id: 'id',
    vendorId: 'vendorId',
    endUserId: 'endUserId',
    products: 'products',
    totalPrice: 'totalPrice',
    paymentStatus: 'paymentStatus',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SharedBillScalarFieldEnum = (typeof SharedBillScalarFieldEnum)[keyof typeof SharedBillScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullableJsonNullValueInput: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull
  };

  export type NullableJsonNullValueInput = (typeof NullableJsonNullValueInput)[keyof typeof NullableJsonNullValueInput]


  export const JsonNullValueInput: {
    JsonNull: typeof JsonNull
  };

  export type JsonNullValueInput = (typeof JsonNullValueInput)[keyof typeof JsonNullValueInput]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const SharedUserOrderByRelevanceFieldEnum: {
    phoneNumber: 'phoneNumber',
    userType: 'userType',
    status: 'status'
  };

  export type SharedUserOrderByRelevanceFieldEnum = (typeof SharedUserOrderByRelevanceFieldEnum)[keyof typeof SharedUserOrderByRelevanceFieldEnum]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const SharedVendorOrderByRelevanceFieldEnum: {
    businessName: 'businessName',
    status: 'status',
    logoUrl: 'logoUrl',
    businessCategory: 'businessCategory',
    address: 'address'
  };

  export type SharedVendorOrderByRelevanceFieldEnum = (typeof SharedVendorOrderByRelevanceFieldEnum)[keyof typeof SharedVendorOrderByRelevanceFieldEnum]


  export const SharedPostOrderByRelevanceFieldEnum: {
    postType: 'postType',
    postCategory: 'postCategory',
    postUrl: 'postUrl'
  };

  export type SharedPostOrderByRelevanceFieldEnum = (typeof SharedPostOrderByRelevanceFieldEnum)[keyof typeof SharedPostOrderByRelevanceFieldEnum]


  export const SharedMenuCategoryOrderByRelevanceFieldEnum: {
    categoryName: 'categoryName',
    categoryImage: 'categoryImage'
  };

  export type SharedMenuCategoryOrderByRelevanceFieldEnum = (typeof SharedMenuCategoryOrderByRelevanceFieldEnum)[keyof typeof SharedMenuCategoryOrderByRelevanceFieldEnum]


  export const SharedMenuSubCategoryOrderByRelevanceFieldEnum: {
    subCategoryName: 'subCategoryName'
  };

  export type SharedMenuSubCategoryOrderByRelevanceFieldEnum = (typeof SharedMenuSubCategoryOrderByRelevanceFieldEnum)[keyof typeof SharedMenuSubCategoryOrderByRelevanceFieldEnum]


  export const SharedMenuItemOrderByRelevanceFieldEnum: {
    productName: 'productName',
    image: 'image'
  };

  export type SharedMenuItemOrderByRelevanceFieldEnum = (typeof SharedMenuItemOrderByRelevanceFieldEnum)[keyof typeof SharedMenuItemOrderByRelevanceFieldEnum]


  export const SharedOfferOrderByRelevanceFieldEnum: {
    offerTargetType: 'offerTargetType',
    offerType: 'offerType'
  };

  export type SharedOfferOrderByRelevanceFieldEnum = (typeof SharedOfferOrderByRelevanceFieldEnum)[keyof typeof SharedOfferOrderByRelevanceFieldEnum]


  export const SharedBillOrderByRelevanceFieldEnum: {
    paymentStatus: 'paymentStatus'
  };

  export type SharedBillOrderByRelevanceFieldEnum = (typeof SharedBillOrderByRelevanceFieldEnum)[keyof typeof SharedBillOrderByRelevanceFieldEnum]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Decimal'
   */
  export type DecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type SharedUserWhereInput = {
    AND?: SharedUserWhereInput | SharedUserWhereInput[]
    OR?: SharedUserWhereInput[]
    NOT?: SharedUserWhereInput | SharedUserWhereInput[]
    id?: IntFilter<"SharedUser"> | number
    phoneNumber?: StringFilter<"SharedUser"> | string
    userType?: StringFilter<"SharedUser"> | string
    status?: StringFilter<"SharedUser"> | string
    createdAt?: DateTimeNullableFilter<"SharedUser"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedUser"> | Date | string | null
    vendors?: SharedVendorListRelationFilter
    bills?: SharedBillListRelationFilter
  }

  export type SharedUserOrderByWithRelationInput = {
    id?: SortOrder
    phoneNumber?: SortOrder
    userType?: SortOrder
    status?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    vendors?: SharedVendorOrderByRelationAggregateInput
    bills?: SharedBillOrderByRelationAggregateInput
    _relevance?: SharedUserOrderByRelevanceInput
  }

  export type SharedUserWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: SharedUserWhereInput | SharedUserWhereInput[]
    OR?: SharedUserWhereInput[]
    NOT?: SharedUserWhereInput | SharedUserWhereInput[]
    phoneNumber?: StringFilter<"SharedUser"> | string
    userType?: StringFilter<"SharedUser"> | string
    status?: StringFilter<"SharedUser"> | string
    createdAt?: DateTimeNullableFilter<"SharedUser"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedUser"> | Date | string | null
    vendors?: SharedVendorListRelationFilter
    bills?: SharedBillListRelationFilter
  }, "id">

  export type SharedUserOrderByWithAggregationInput = {
    id?: SortOrder
    phoneNumber?: SortOrder
    userType?: SortOrder
    status?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    _count?: SharedUserCountOrderByAggregateInput
    _avg?: SharedUserAvgOrderByAggregateInput
    _max?: SharedUserMaxOrderByAggregateInput
    _min?: SharedUserMinOrderByAggregateInput
    _sum?: SharedUserSumOrderByAggregateInput
  }

  export type SharedUserScalarWhereWithAggregatesInput = {
    AND?: SharedUserScalarWhereWithAggregatesInput | SharedUserScalarWhereWithAggregatesInput[]
    OR?: SharedUserScalarWhereWithAggregatesInput[]
    NOT?: SharedUserScalarWhereWithAggregatesInput | SharedUserScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SharedUser"> | number
    phoneNumber?: StringWithAggregatesFilter<"SharedUser"> | string
    userType?: StringWithAggregatesFilter<"SharedUser"> | string
    status?: StringWithAggregatesFilter<"SharedUser"> | string
    createdAt?: DateTimeNullableWithAggregatesFilter<"SharedUser"> | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter<"SharedUser"> | Date | string | null
  }

  export type SharedVendorWhereInput = {
    AND?: SharedVendorWhereInput | SharedVendorWhereInput[]
    OR?: SharedVendorWhereInput[]
    NOT?: SharedVendorWhereInput | SharedVendorWhereInput[]
    id?: IntFilter<"SharedVendor"> | number
    userId?: IntFilter<"SharedVendor"> | number
    businessName?: StringNullableFilter<"SharedVendor"> | string | null
    status?: StringFilter<"SharedVendor"> | string
    logoUrl?: StringNullableFilter<"SharedVendor"> | string | null
    businessCategory?: StringNullableFilter<"SharedVendor"> | string | null
    address?: StringNullableFilter<"SharedVendor"> | string | null
    payment?: JsonNullableFilter<"SharedVendor">
    workingDays?: JsonNullableFilter<"SharedVendor">
    createdAt?: DateTimeNullableFilter<"SharedVendor"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedVendor"> | Date | string | null
    user?: XOR<SharedUserScalarRelationFilter, SharedUserWhereInput>
    posts?: SharedPostListRelationFilter
    menuCategories?: SharedMenuCategoryListRelationFilter
    menuSubCategories?: SharedMenuSubCategoryListRelationFilter
    menuItems?: SharedMenuItemListRelationFilter
    offers?: SharedOfferListRelationFilter
    bills?: SharedBillListRelationFilter
  }

  export type SharedVendorOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    businessName?: SortOrderInput | SortOrder
    status?: SortOrder
    logoUrl?: SortOrderInput | SortOrder
    businessCategory?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    payment?: SortOrderInput | SortOrder
    workingDays?: SortOrderInput | SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    user?: SharedUserOrderByWithRelationInput
    posts?: SharedPostOrderByRelationAggregateInput
    menuCategories?: SharedMenuCategoryOrderByRelationAggregateInput
    menuSubCategories?: SharedMenuSubCategoryOrderByRelationAggregateInput
    menuItems?: SharedMenuItemOrderByRelationAggregateInput
    offers?: SharedOfferOrderByRelationAggregateInput
    bills?: SharedBillOrderByRelationAggregateInput
    _relevance?: SharedVendorOrderByRelevanceInput
  }

  export type SharedVendorWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    userId?: number
    AND?: SharedVendorWhereInput | SharedVendorWhereInput[]
    OR?: SharedVendorWhereInput[]
    NOT?: SharedVendorWhereInput | SharedVendorWhereInput[]
    businessName?: StringNullableFilter<"SharedVendor"> | string | null
    status?: StringFilter<"SharedVendor"> | string
    logoUrl?: StringNullableFilter<"SharedVendor"> | string | null
    businessCategory?: StringNullableFilter<"SharedVendor"> | string | null
    address?: StringNullableFilter<"SharedVendor"> | string | null
    payment?: JsonNullableFilter<"SharedVendor">
    workingDays?: JsonNullableFilter<"SharedVendor">
    createdAt?: DateTimeNullableFilter<"SharedVendor"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedVendor"> | Date | string | null
    user?: XOR<SharedUserScalarRelationFilter, SharedUserWhereInput>
    posts?: SharedPostListRelationFilter
    menuCategories?: SharedMenuCategoryListRelationFilter
    menuSubCategories?: SharedMenuSubCategoryListRelationFilter
    menuItems?: SharedMenuItemListRelationFilter
    offers?: SharedOfferListRelationFilter
    bills?: SharedBillListRelationFilter
  }, "id" | "userId">

  export type SharedVendorOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    businessName?: SortOrderInput | SortOrder
    status?: SortOrder
    logoUrl?: SortOrderInput | SortOrder
    businessCategory?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    payment?: SortOrderInput | SortOrder
    workingDays?: SortOrderInput | SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    _count?: SharedVendorCountOrderByAggregateInput
    _avg?: SharedVendorAvgOrderByAggregateInput
    _max?: SharedVendorMaxOrderByAggregateInput
    _min?: SharedVendorMinOrderByAggregateInput
    _sum?: SharedVendorSumOrderByAggregateInput
  }

  export type SharedVendorScalarWhereWithAggregatesInput = {
    AND?: SharedVendorScalarWhereWithAggregatesInput | SharedVendorScalarWhereWithAggregatesInput[]
    OR?: SharedVendorScalarWhereWithAggregatesInput[]
    NOT?: SharedVendorScalarWhereWithAggregatesInput | SharedVendorScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SharedVendor"> | number
    userId?: IntWithAggregatesFilter<"SharedVendor"> | number
    businessName?: StringNullableWithAggregatesFilter<"SharedVendor"> | string | null
    status?: StringWithAggregatesFilter<"SharedVendor"> | string
    logoUrl?: StringNullableWithAggregatesFilter<"SharedVendor"> | string | null
    businessCategory?: StringNullableWithAggregatesFilter<"SharedVendor"> | string | null
    address?: StringNullableWithAggregatesFilter<"SharedVendor"> | string | null
    payment?: JsonNullableWithAggregatesFilter<"SharedVendor">
    workingDays?: JsonNullableWithAggregatesFilter<"SharedVendor">
    createdAt?: DateTimeNullableWithAggregatesFilter<"SharedVendor"> | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter<"SharedVendor"> | Date | string | null
  }

  export type SharedPostWhereInput = {
    AND?: SharedPostWhereInput | SharedPostWhereInput[]
    OR?: SharedPostWhereInput[]
    NOT?: SharedPostWhereInput | SharedPostWhereInput[]
    id?: IntFilter<"SharedPost"> | number
    vendorId?: IntFilter<"SharedPost"> | number
    postType?: StringFilter<"SharedPost"> | string
    postCategory?: StringNullableFilter<"SharedPost"> | string | null
    postUrl?: StringFilter<"SharedPost"> | string
    isOfferIncluded?: BoolFilter<"SharedPost"> | boolean
    offerId?: IntNullableFilter<"SharedPost"> | number | null
    isDownloaded?: BoolFilter<"SharedPost"> | boolean
    createdAt?: DateTimeNullableFilter<"SharedPost"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedPost"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    offer?: XOR<SharedOfferNullableScalarRelationFilter, SharedOfferWhereInput> | null
  }

  export type SharedPostOrderByWithRelationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    postType?: SortOrder
    postCategory?: SortOrderInput | SortOrder
    postUrl?: SortOrder
    isOfferIncluded?: SortOrder
    offerId?: SortOrderInput | SortOrder
    isDownloaded?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    vendor?: SharedVendorOrderByWithRelationInput
    offer?: SharedOfferOrderByWithRelationInput
    _relevance?: SharedPostOrderByRelevanceInput
  }

  export type SharedPostWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: SharedPostWhereInput | SharedPostWhereInput[]
    OR?: SharedPostWhereInput[]
    NOT?: SharedPostWhereInput | SharedPostWhereInput[]
    vendorId?: IntFilter<"SharedPost"> | number
    postType?: StringFilter<"SharedPost"> | string
    postCategory?: StringNullableFilter<"SharedPost"> | string | null
    postUrl?: StringFilter<"SharedPost"> | string
    isOfferIncluded?: BoolFilter<"SharedPost"> | boolean
    offerId?: IntNullableFilter<"SharedPost"> | number | null
    isDownloaded?: BoolFilter<"SharedPost"> | boolean
    createdAt?: DateTimeNullableFilter<"SharedPost"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedPost"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    offer?: XOR<SharedOfferNullableScalarRelationFilter, SharedOfferWhereInput> | null
  }, "id">

  export type SharedPostOrderByWithAggregationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    postType?: SortOrder
    postCategory?: SortOrderInput | SortOrder
    postUrl?: SortOrder
    isOfferIncluded?: SortOrder
    offerId?: SortOrderInput | SortOrder
    isDownloaded?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    _count?: SharedPostCountOrderByAggregateInput
    _avg?: SharedPostAvgOrderByAggregateInput
    _max?: SharedPostMaxOrderByAggregateInput
    _min?: SharedPostMinOrderByAggregateInput
    _sum?: SharedPostSumOrderByAggregateInput
  }

  export type SharedPostScalarWhereWithAggregatesInput = {
    AND?: SharedPostScalarWhereWithAggregatesInput | SharedPostScalarWhereWithAggregatesInput[]
    OR?: SharedPostScalarWhereWithAggregatesInput[]
    NOT?: SharedPostScalarWhereWithAggregatesInput | SharedPostScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SharedPost"> | number
    vendorId?: IntWithAggregatesFilter<"SharedPost"> | number
    postType?: StringWithAggregatesFilter<"SharedPost"> | string
    postCategory?: StringNullableWithAggregatesFilter<"SharedPost"> | string | null
    postUrl?: StringWithAggregatesFilter<"SharedPost"> | string
    isOfferIncluded?: BoolWithAggregatesFilter<"SharedPost"> | boolean
    offerId?: IntNullableWithAggregatesFilter<"SharedPost"> | number | null
    isDownloaded?: BoolWithAggregatesFilter<"SharedPost"> | boolean
    createdAt?: DateTimeNullableWithAggregatesFilter<"SharedPost"> | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter<"SharedPost"> | Date | string | null
  }

  export type SharedMenuCategoryWhereInput = {
    AND?: SharedMenuCategoryWhereInput | SharedMenuCategoryWhereInput[]
    OR?: SharedMenuCategoryWhereInput[]
    NOT?: SharedMenuCategoryWhereInput | SharedMenuCategoryWhereInput[]
    id?: IntFilter<"SharedMenuCategory"> | number
    vendorId?: IntFilter<"SharedMenuCategory"> | number
    categoryName?: StringFilter<"SharedMenuCategory"> | string
    categoryImage?: StringNullableFilter<"SharedMenuCategory"> | string | null
    createdAt?: DateTimeNullableFilter<"SharedMenuCategory"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuCategory"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    subCategories?: SharedMenuSubCategoryListRelationFilter
    items?: SharedMenuItemListRelationFilter
  }

  export type SharedMenuCategoryOrderByWithRelationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryName?: SortOrder
    categoryImage?: SortOrderInput | SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    vendor?: SharedVendorOrderByWithRelationInput
    subCategories?: SharedMenuSubCategoryOrderByRelationAggregateInput
    items?: SharedMenuItemOrderByRelationAggregateInput
    _relevance?: SharedMenuCategoryOrderByRelevanceInput
  }

  export type SharedMenuCategoryWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: SharedMenuCategoryWhereInput | SharedMenuCategoryWhereInput[]
    OR?: SharedMenuCategoryWhereInput[]
    NOT?: SharedMenuCategoryWhereInput | SharedMenuCategoryWhereInput[]
    vendorId?: IntFilter<"SharedMenuCategory"> | number
    categoryName?: StringFilter<"SharedMenuCategory"> | string
    categoryImage?: StringNullableFilter<"SharedMenuCategory"> | string | null
    createdAt?: DateTimeNullableFilter<"SharedMenuCategory"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuCategory"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    subCategories?: SharedMenuSubCategoryListRelationFilter
    items?: SharedMenuItemListRelationFilter
  }, "id">

  export type SharedMenuCategoryOrderByWithAggregationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryName?: SortOrder
    categoryImage?: SortOrderInput | SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    _count?: SharedMenuCategoryCountOrderByAggregateInput
    _avg?: SharedMenuCategoryAvgOrderByAggregateInput
    _max?: SharedMenuCategoryMaxOrderByAggregateInput
    _min?: SharedMenuCategoryMinOrderByAggregateInput
    _sum?: SharedMenuCategorySumOrderByAggregateInput
  }

  export type SharedMenuCategoryScalarWhereWithAggregatesInput = {
    AND?: SharedMenuCategoryScalarWhereWithAggregatesInput | SharedMenuCategoryScalarWhereWithAggregatesInput[]
    OR?: SharedMenuCategoryScalarWhereWithAggregatesInput[]
    NOT?: SharedMenuCategoryScalarWhereWithAggregatesInput | SharedMenuCategoryScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SharedMenuCategory"> | number
    vendorId?: IntWithAggregatesFilter<"SharedMenuCategory"> | number
    categoryName?: StringWithAggregatesFilter<"SharedMenuCategory"> | string
    categoryImage?: StringNullableWithAggregatesFilter<"SharedMenuCategory"> | string | null
    createdAt?: DateTimeNullableWithAggregatesFilter<"SharedMenuCategory"> | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter<"SharedMenuCategory"> | Date | string | null
  }

  export type SharedMenuSubCategoryWhereInput = {
    AND?: SharedMenuSubCategoryWhereInput | SharedMenuSubCategoryWhereInput[]
    OR?: SharedMenuSubCategoryWhereInput[]
    NOT?: SharedMenuSubCategoryWhereInput | SharedMenuSubCategoryWhereInput[]
    id?: IntFilter<"SharedMenuSubCategory"> | number
    vendorId?: IntFilter<"SharedMenuSubCategory"> | number
    categoryId?: IntFilter<"SharedMenuSubCategory"> | number
    subCategoryName?: StringFilter<"SharedMenuSubCategory"> | string
    createdAt?: DateTimeNullableFilter<"SharedMenuSubCategory"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuSubCategory"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    category?: XOR<SharedMenuCategoryScalarRelationFilter, SharedMenuCategoryWhereInput>
    items?: SharedMenuItemListRelationFilter
  }

  export type SharedMenuSubCategoryOrderByWithRelationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryId?: SortOrder
    subCategoryName?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    vendor?: SharedVendorOrderByWithRelationInput
    category?: SharedMenuCategoryOrderByWithRelationInput
    items?: SharedMenuItemOrderByRelationAggregateInput
    _relevance?: SharedMenuSubCategoryOrderByRelevanceInput
  }

  export type SharedMenuSubCategoryWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: SharedMenuSubCategoryWhereInput | SharedMenuSubCategoryWhereInput[]
    OR?: SharedMenuSubCategoryWhereInput[]
    NOT?: SharedMenuSubCategoryWhereInput | SharedMenuSubCategoryWhereInput[]
    vendorId?: IntFilter<"SharedMenuSubCategory"> | number
    categoryId?: IntFilter<"SharedMenuSubCategory"> | number
    subCategoryName?: StringFilter<"SharedMenuSubCategory"> | string
    createdAt?: DateTimeNullableFilter<"SharedMenuSubCategory"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuSubCategory"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    category?: XOR<SharedMenuCategoryScalarRelationFilter, SharedMenuCategoryWhereInput>
    items?: SharedMenuItemListRelationFilter
  }, "id">

  export type SharedMenuSubCategoryOrderByWithAggregationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryId?: SortOrder
    subCategoryName?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    _count?: SharedMenuSubCategoryCountOrderByAggregateInput
    _avg?: SharedMenuSubCategoryAvgOrderByAggregateInput
    _max?: SharedMenuSubCategoryMaxOrderByAggregateInput
    _min?: SharedMenuSubCategoryMinOrderByAggregateInput
    _sum?: SharedMenuSubCategorySumOrderByAggregateInput
  }

  export type SharedMenuSubCategoryScalarWhereWithAggregatesInput = {
    AND?: SharedMenuSubCategoryScalarWhereWithAggregatesInput | SharedMenuSubCategoryScalarWhereWithAggregatesInput[]
    OR?: SharedMenuSubCategoryScalarWhereWithAggregatesInput[]
    NOT?: SharedMenuSubCategoryScalarWhereWithAggregatesInput | SharedMenuSubCategoryScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SharedMenuSubCategory"> | number
    vendorId?: IntWithAggregatesFilter<"SharedMenuSubCategory"> | number
    categoryId?: IntWithAggregatesFilter<"SharedMenuSubCategory"> | number
    subCategoryName?: StringWithAggregatesFilter<"SharedMenuSubCategory"> | string
    createdAt?: DateTimeNullableWithAggregatesFilter<"SharedMenuSubCategory"> | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter<"SharedMenuSubCategory"> | Date | string | null
  }

  export type SharedMenuItemWhereInput = {
    AND?: SharedMenuItemWhereInput | SharedMenuItemWhereInput[]
    OR?: SharedMenuItemWhereInput[]
    NOT?: SharedMenuItemWhereInput | SharedMenuItemWhereInput[]
    id?: IntFilter<"SharedMenuItem"> | number
    vendorId?: IntFilter<"SharedMenuItem"> | number
    menuCategoryId?: IntFilter<"SharedMenuItem"> | number
    menuSubCategoryId?: IntNullableFilter<"SharedMenuItem"> | number | null
    productName?: StringFilter<"SharedMenuItem"> | string
    image?: StringNullableFilter<"SharedMenuItem"> | string | null
    price?: DecimalFilter<"SharedMenuItem"> | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeNullableFilter<"SharedMenuItem"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuItem"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    category?: XOR<SharedMenuCategoryScalarRelationFilter, SharedMenuCategoryWhereInput>
    subCategory?: XOR<SharedMenuSubCategoryNullableScalarRelationFilter, SharedMenuSubCategoryWhereInput> | null
  }

  export type SharedMenuItemOrderByWithRelationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    menuCategoryId?: SortOrder
    menuSubCategoryId?: SortOrderInput | SortOrder
    productName?: SortOrder
    image?: SortOrderInput | SortOrder
    price?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    vendor?: SharedVendorOrderByWithRelationInput
    category?: SharedMenuCategoryOrderByWithRelationInput
    subCategory?: SharedMenuSubCategoryOrderByWithRelationInput
    _relevance?: SharedMenuItemOrderByRelevanceInput
  }

  export type SharedMenuItemWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: SharedMenuItemWhereInput | SharedMenuItemWhereInput[]
    OR?: SharedMenuItemWhereInput[]
    NOT?: SharedMenuItemWhereInput | SharedMenuItemWhereInput[]
    vendorId?: IntFilter<"SharedMenuItem"> | number
    menuCategoryId?: IntFilter<"SharedMenuItem"> | number
    menuSubCategoryId?: IntNullableFilter<"SharedMenuItem"> | number | null
    productName?: StringFilter<"SharedMenuItem"> | string
    image?: StringNullableFilter<"SharedMenuItem"> | string | null
    price?: DecimalFilter<"SharedMenuItem"> | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeNullableFilter<"SharedMenuItem"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuItem"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    category?: XOR<SharedMenuCategoryScalarRelationFilter, SharedMenuCategoryWhereInput>
    subCategory?: XOR<SharedMenuSubCategoryNullableScalarRelationFilter, SharedMenuSubCategoryWhereInput> | null
  }, "id">

  export type SharedMenuItemOrderByWithAggregationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    menuCategoryId?: SortOrder
    menuSubCategoryId?: SortOrderInput | SortOrder
    productName?: SortOrder
    image?: SortOrderInput | SortOrder
    price?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    _count?: SharedMenuItemCountOrderByAggregateInput
    _avg?: SharedMenuItemAvgOrderByAggregateInput
    _max?: SharedMenuItemMaxOrderByAggregateInput
    _min?: SharedMenuItemMinOrderByAggregateInput
    _sum?: SharedMenuItemSumOrderByAggregateInput
  }

  export type SharedMenuItemScalarWhereWithAggregatesInput = {
    AND?: SharedMenuItemScalarWhereWithAggregatesInput | SharedMenuItemScalarWhereWithAggregatesInput[]
    OR?: SharedMenuItemScalarWhereWithAggregatesInput[]
    NOT?: SharedMenuItemScalarWhereWithAggregatesInput | SharedMenuItemScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SharedMenuItem"> | number
    vendorId?: IntWithAggregatesFilter<"SharedMenuItem"> | number
    menuCategoryId?: IntWithAggregatesFilter<"SharedMenuItem"> | number
    menuSubCategoryId?: IntNullableWithAggregatesFilter<"SharedMenuItem"> | number | null
    productName?: StringWithAggregatesFilter<"SharedMenuItem"> | string
    image?: StringNullableWithAggregatesFilter<"SharedMenuItem"> | string | null
    price?: DecimalWithAggregatesFilter<"SharedMenuItem"> | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeNullableWithAggregatesFilter<"SharedMenuItem"> | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter<"SharedMenuItem"> | Date | string | null
  }

  export type SharedOfferWhereInput = {
    AND?: SharedOfferWhereInput | SharedOfferWhereInput[]
    OR?: SharedOfferWhereInput[]
    NOT?: SharedOfferWhereInput | SharedOfferWhereInput[]
    id?: IntFilter<"SharedOffer"> | number
    vendorId?: IntFilter<"SharedOffer"> | number
    offerTargetType?: StringNullableFilter<"SharedOffer"> | string | null
    offerTargetId?: IntNullableFilter<"SharedOffer"> | number | null
    offerType?: StringFilter<"SharedOffer"> | string
    offerValue?: JsonNullableFilter<"SharedOffer">
    validityFrom?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    validityTo?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    createdAt?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    posts?: SharedPostListRelationFilter
  }

  export type SharedOfferOrderByWithRelationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerTargetType?: SortOrderInput | SortOrder
    offerTargetId?: SortOrderInput | SortOrder
    offerType?: SortOrder
    offerValue?: SortOrderInput | SortOrder
    validityFrom?: SortOrderInput | SortOrder
    validityTo?: SortOrderInput | SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    vendor?: SharedVendorOrderByWithRelationInput
    posts?: SharedPostOrderByRelationAggregateInput
    _relevance?: SharedOfferOrderByRelevanceInput
  }

  export type SharedOfferWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: SharedOfferWhereInput | SharedOfferWhereInput[]
    OR?: SharedOfferWhereInput[]
    NOT?: SharedOfferWhereInput | SharedOfferWhereInput[]
    vendorId?: IntFilter<"SharedOffer"> | number
    offerTargetType?: StringNullableFilter<"SharedOffer"> | string | null
    offerTargetId?: IntNullableFilter<"SharedOffer"> | number | null
    offerType?: StringFilter<"SharedOffer"> | string
    offerValue?: JsonNullableFilter<"SharedOffer">
    validityFrom?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    validityTo?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    createdAt?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    posts?: SharedPostListRelationFilter
  }, "id">

  export type SharedOfferOrderByWithAggregationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerTargetType?: SortOrderInput | SortOrder
    offerTargetId?: SortOrderInput | SortOrder
    offerType?: SortOrder
    offerValue?: SortOrderInput | SortOrder
    validityFrom?: SortOrderInput | SortOrder
    validityTo?: SortOrderInput | SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    _count?: SharedOfferCountOrderByAggregateInput
    _avg?: SharedOfferAvgOrderByAggregateInput
    _max?: SharedOfferMaxOrderByAggregateInput
    _min?: SharedOfferMinOrderByAggregateInput
    _sum?: SharedOfferSumOrderByAggregateInput
  }

  export type SharedOfferScalarWhereWithAggregatesInput = {
    AND?: SharedOfferScalarWhereWithAggregatesInput | SharedOfferScalarWhereWithAggregatesInput[]
    OR?: SharedOfferScalarWhereWithAggregatesInput[]
    NOT?: SharedOfferScalarWhereWithAggregatesInput | SharedOfferScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SharedOffer"> | number
    vendorId?: IntWithAggregatesFilter<"SharedOffer"> | number
    offerTargetType?: StringNullableWithAggregatesFilter<"SharedOffer"> | string | null
    offerTargetId?: IntNullableWithAggregatesFilter<"SharedOffer"> | number | null
    offerType?: StringWithAggregatesFilter<"SharedOffer"> | string
    offerValue?: JsonNullableWithAggregatesFilter<"SharedOffer">
    validityFrom?: DateTimeNullableWithAggregatesFilter<"SharedOffer"> | Date | string | null
    validityTo?: DateTimeNullableWithAggregatesFilter<"SharedOffer"> | Date | string | null
    createdAt?: DateTimeNullableWithAggregatesFilter<"SharedOffer"> | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter<"SharedOffer"> | Date | string | null
  }

  export type SharedBillWhereInput = {
    AND?: SharedBillWhereInput | SharedBillWhereInput[]
    OR?: SharedBillWhereInput[]
    NOT?: SharedBillWhereInput | SharedBillWhereInput[]
    id?: IntFilter<"SharedBill"> | number
    vendorId?: IntFilter<"SharedBill"> | number
    endUserId?: IntNullableFilter<"SharedBill"> | number | null
    products?: JsonFilter<"SharedBill">
    totalPrice?: DecimalFilter<"SharedBill"> | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFilter<"SharedBill"> | string
    createdAt?: DateTimeNullableFilter<"SharedBill"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedBill"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    endUser?: XOR<SharedUserNullableScalarRelationFilter, SharedUserWhereInput> | null
  }

  export type SharedBillOrderByWithRelationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    endUserId?: SortOrderInput | SortOrder
    products?: SortOrder
    totalPrice?: SortOrder
    paymentStatus?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    vendor?: SharedVendorOrderByWithRelationInput
    endUser?: SharedUserOrderByWithRelationInput
    _relevance?: SharedBillOrderByRelevanceInput
  }

  export type SharedBillWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: SharedBillWhereInput | SharedBillWhereInput[]
    OR?: SharedBillWhereInput[]
    NOT?: SharedBillWhereInput | SharedBillWhereInput[]
    vendorId?: IntFilter<"SharedBill"> | number
    endUserId?: IntNullableFilter<"SharedBill"> | number | null
    products?: JsonFilter<"SharedBill">
    totalPrice?: DecimalFilter<"SharedBill"> | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFilter<"SharedBill"> | string
    createdAt?: DateTimeNullableFilter<"SharedBill"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedBill"> | Date | string | null
    vendor?: XOR<SharedVendorScalarRelationFilter, SharedVendorWhereInput>
    endUser?: XOR<SharedUserNullableScalarRelationFilter, SharedUserWhereInput> | null
  }, "id">

  export type SharedBillOrderByWithAggregationInput = {
    id?: SortOrder
    vendorId?: SortOrder
    endUserId?: SortOrderInput | SortOrder
    products?: SortOrder
    totalPrice?: SortOrder
    paymentStatus?: SortOrder
    createdAt?: SortOrderInput | SortOrder
    updatedAt?: SortOrderInput | SortOrder
    _count?: SharedBillCountOrderByAggregateInput
    _avg?: SharedBillAvgOrderByAggregateInput
    _max?: SharedBillMaxOrderByAggregateInput
    _min?: SharedBillMinOrderByAggregateInput
    _sum?: SharedBillSumOrderByAggregateInput
  }

  export type SharedBillScalarWhereWithAggregatesInput = {
    AND?: SharedBillScalarWhereWithAggregatesInput | SharedBillScalarWhereWithAggregatesInput[]
    OR?: SharedBillScalarWhereWithAggregatesInput[]
    NOT?: SharedBillScalarWhereWithAggregatesInput | SharedBillScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SharedBill"> | number
    vendorId?: IntWithAggregatesFilter<"SharedBill"> | number
    endUserId?: IntNullableWithAggregatesFilter<"SharedBill"> | number | null
    products?: JsonWithAggregatesFilter<"SharedBill">
    totalPrice?: DecimalWithAggregatesFilter<"SharedBill"> | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringWithAggregatesFilter<"SharedBill"> | string
    createdAt?: DateTimeNullableWithAggregatesFilter<"SharedBill"> | Date | string | null
    updatedAt?: DateTimeNullableWithAggregatesFilter<"SharedBill"> | Date | string | null
  }

  export type SharedUserCreateInput = {
    phoneNumber: string
    userType: string
    status: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendors?: SharedVendorCreateNestedManyWithoutUserInput
    bills?: SharedBillCreateNestedManyWithoutEndUserInput
  }

  export type SharedUserUncheckedCreateInput = {
    id?: number
    phoneNumber: string
    userType: string
    status: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendors?: SharedVendorUncheckedCreateNestedManyWithoutUserInput
    bills?: SharedBillUncheckedCreateNestedManyWithoutEndUserInput
  }

  export type SharedUserUpdateInput = {
    phoneNumber?: StringFieldUpdateOperationsInput | string
    userType?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendors?: SharedVendorUpdateManyWithoutUserNestedInput
    bills?: SharedBillUpdateManyWithoutEndUserNestedInput
  }

  export type SharedUserUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    phoneNumber?: StringFieldUpdateOperationsInput | string
    userType?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendors?: SharedVendorUncheckedUpdateManyWithoutUserNestedInput
    bills?: SharedBillUncheckedUpdateManyWithoutEndUserNestedInput
  }

  export type SharedUserCreateManyInput = {
    id?: number
    phoneNumber: string
    userType: string
    status: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedUserUpdateManyMutationInput = {
    phoneNumber?: StringFieldUpdateOperationsInput | string
    userType?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedUserUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    phoneNumber?: StringFieldUpdateOperationsInput | string
    userType?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedVendorCreateInput = {
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    user: SharedUserCreateNestedOneWithoutVendorsInput
    posts?: SharedPostCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemCreateNestedManyWithoutVendorInput
    offers?: SharedOfferCreateNestedManyWithoutVendorInput
    bills?: SharedBillCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUncheckedCreateInput = {
    id?: number
    userId: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemUncheckedCreateNestedManyWithoutVendorInput
    offers?: SharedOfferUncheckedCreateNestedManyWithoutVendorInput
    bills?: SharedBillUncheckedCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUpdateInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: SharedUserUpdateOneRequiredWithoutVendorsNestedInput
    posts?: SharedPostUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUncheckedUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUncheckedUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUncheckedUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorCreateManyInput = {
    id?: number
    userId: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedVendorUpdateManyMutationInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedVendorUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedPostCreateInput = {
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutPostsInput
    offer?: SharedOfferCreateNestedOneWithoutPostsInput
  }

  export type SharedPostUncheckedCreateInput = {
    id?: number
    vendorId: number
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    offerId?: number | null
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedPostUpdateInput = {
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutPostsNestedInput
    offer?: SharedOfferUpdateOneWithoutPostsNestedInput
  }

  export type SharedPostUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    offerId?: NullableIntFieldUpdateOperationsInput | number | null
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedPostCreateManyInput = {
    id?: number
    vendorId: number
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    offerId?: number | null
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedPostUpdateManyMutationInput = {
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedPostUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    offerId?: NullableIntFieldUpdateOperationsInput | number | null
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuCategoryCreateInput = {
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuCategoriesInput
    subCategories?: SharedMenuSubCategoryCreateNestedManyWithoutCategoryInput
    items?: SharedMenuItemCreateNestedManyWithoutCategoryInput
  }

  export type SharedMenuCategoryUncheckedCreateInput = {
    id?: number
    vendorId: number
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    subCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutCategoryInput
    items?: SharedMenuItemUncheckedCreateNestedManyWithoutCategoryInput
  }

  export type SharedMenuCategoryUpdateInput = {
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuCategoriesNestedInput
    subCategories?: SharedMenuSubCategoryUpdateManyWithoutCategoryNestedInput
    items?: SharedMenuItemUpdateManyWithoutCategoryNestedInput
  }

  export type SharedMenuCategoryUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    subCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutCategoryNestedInput
    items?: SharedMenuItemUncheckedUpdateManyWithoutCategoryNestedInput
  }

  export type SharedMenuCategoryCreateManyInput = {
    id?: number
    vendorId: number
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuCategoryUpdateManyMutationInput = {
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuCategoryUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuSubCategoryCreateInput = {
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuSubCategoriesInput
    category: SharedMenuCategoryCreateNestedOneWithoutSubCategoriesInput
    items?: SharedMenuItemCreateNestedManyWithoutSubCategoryInput
  }

  export type SharedMenuSubCategoryUncheckedCreateInput = {
    id?: number
    vendorId: number
    categoryId: number
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    items?: SharedMenuItemUncheckedCreateNestedManyWithoutSubCategoryInput
  }

  export type SharedMenuSubCategoryUpdateInput = {
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuSubCategoriesNestedInput
    category?: SharedMenuCategoryUpdateOneRequiredWithoutSubCategoriesNestedInput
    items?: SharedMenuItemUpdateManyWithoutSubCategoryNestedInput
  }

  export type SharedMenuSubCategoryUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    categoryId?: IntFieldUpdateOperationsInput | number
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    items?: SharedMenuItemUncheckedUpdateManyWithoutSubCategoryNestedInput
  }

  export type SharedMenuSubCategoryCreateManyInput = {
    id?: number
    vendorId: number
    categoryId: number
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuSubCategoryUpdateManyMutationInput = {
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuSubCategoryUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    categoryId?: IntFieldUpdateOperationsInput | number
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemCreateInput = {
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuItemsInput
    category: SharedMenuCategoryCreateNestedOneWithoutItemsInput
    subCategory?: SharedMenuSubCategoryCreateNestedOneWithoutItemsInput
  }

  export type SharedMenuItemUncheckedCreateInput = {
    id?: number
    vendorId: number
    menuCategoryId: number
    menuSubCategoryId?: number | null
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuItemUpdateInput = {
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuItemsNestedInput
    category?: SharedMenuCategoryUpdateOneRequiredWithoutItemsNestedInput
    subCategory?: SharedMenuSubCategoryUpdateOneWithoutItemsNestedInput
  }

  export type SharedMenuItemUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    menuCategoryId?: IntFieldUpdateOperationsInput | number
    menuSubCategoryId?: NullableIntFieldUpdateOperationsInput | number | null
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemCreateManyInput = {
    id?: number
    vendorId: number
    menuCategoryId: number
    menuSubCategoryId?: number | null
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuItemUpdateManyMutationInput = {
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    menuCategoryId?: IntFieldUpdateOperationsInput | number
    menuSubCategoryId?: NullableIntFieldUpdateOperationsInput | number | null
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedOfferCreateInput = {
    offerTargetType?: string | null
    offerTargetId?: number | null
    offerType: string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: Date | string | null
    validityTo?: Date | string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutOffersInput
    posts?: SharedPostCreateNestedManyWithoutOfferInput
  }

  export type SharedOfferUncheckedCreateInput = {
    id?: number
    vendorId: number
    offerTargetType?: string | null
    offerTargetId?: number | null
    offerType: string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: Date | string | null
    validityTo?: Date | string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutOfferInput
  }

  export type SharedOfferUpdateInput = {
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutOffersNestedInput
    posts?: SharedPostUpdateManyWithoutOfferNestedInput
  }

  export type SharedOfferUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutOfferNestedInput
  }

  export type SharedOfferCreateManyInput = {
    id?: number
    vendorId: number
    offerTargetType?: string | null
    offerTargetId?: number | null
    offerType: string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: Date | string | null
    validityTo?: Date | string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedOfferUpdateManyMutationInput = {
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedOfferUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedBillCreateInput = {
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutBillsInput
    endUser?: SharedUserCreateNestedOneWithoutBillsInput
  }

  export type SharedBillUncheckedCreateInput = {
    id?: number
    vendorId: number
    endUserId?: number | null
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedBillUpdateInput = {
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutBillsNestedInput
    endUser?: SharedUserUpdateOneWithoutBillsNestedInput
  }

  export type SharedBillUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    endUserId?: NullableIntFieldUpdateOperationsInput | number | null
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedBillCreateManyInput = {
    id?: number
    vendorId: number
    endUserId?: number | null
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedBillUpdateManyMutationInput = {
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedBillUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    endUserId?: NullableIntFieldUpdateOperationsInput | number | null
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type SharedVendorListRelationFilter = {
    every?: SharedVendorWhereInput
    some?: SharedVendorWhereInput
    none?: SharedVendorWhereInput
  }

  export type SharedBillListRelationFilter = {
    every?: SharedBillWhereInput
    some?: SharedBillWhereInput
    none?: SharedBillWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type SharedVendorOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SharedBillOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SharedUserOrderByRelevanceInput = {
    fields: SharedUserOrderByRelevanceFieldEnum | SharedUserOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SharedUserCountOrderByAggregateInput = {
    id?: SortOrder
    phoneNumber?: SortOrder
    userType?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedUserAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type SharedUserMaxOrderByAggregateInput = {
    id?: SortOrder
    phoneNumber?: SortOrder
    userType?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedUserMinOrderByAggregateInput = {
    id?: SortOrder
    phoneNumber?: SortOrder
    userType?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedUserSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }
  export type JsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type SharedUserScalarRelationFilter = {
    is?: SharedUserWhereInput
    isNot?: SharedUserWhereInput
  }

  export type SharedPostListRelationFilter = {
    every?: SharedPostWhereInput
    some?: SharedPostWhereInput
    none?: SharedPostWhereInput
  }

  export type SharedMenuCategoryListRelationFilter = {
    every?: SharedMenuCategoryWhereInput
    some?: SharedMenuCategoryWhereInput
    none?: SharedMenuCategoryWhereInput
  }

  export type SharedMenuSubCategoryListRelationFilter = {
    every?: SharedMenuSubCategoryWhereInput
    some?: SharedMenuSubCategoryWhereInput
    none?: SharedMenuSubCategoryWhereInput
  }

  export type SharedMenuItemListRelationFilter = {
    every?: SharedMenuItemWhereInput
    some?: SharedMenuItemWhereInput
    none?: SharedMenuItemWhereInput
  }

  export type SharedOfferListRelationFilter = {
    every?: SharedOfferWhereInput
    some?: SharedOfferWhereInput
    none?: SharedOfferWhereInput
  }

  export type SharedPostOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SharedMenuCategoryOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SharedMenuSubCategoryOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SharedMenuItemOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SharedOfferOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SharedVendorOrderByRelevanceInput = {
    fields: SharedVendorOrderByRelevanceFieldEnum | SharedVendorOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SharedVendorCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    businessName?: SortOrder
    status?: SortOrder
    logoUrl?: SortOrder
    businessCategory?: SortOrder
    address?: SortOrder
    payment?: SortOrder
    workingDays?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedVendorAvgOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
  }

  export type SharedVendorMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    businessName?: SortOrder
    status?: SortOrder
    logoUrl?: SortOrder
    businessCategory?: SortOrder
    address?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedVendorMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    businessName?: SortOrder
    status?: SortOrder
    logoUrl?: SortOrder
    businessCategory?: SortOrder
    address?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedVendorSumOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }
  export type JsonNullableWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedJsonNullableFilter<$PrismaModel>
    _max?: NestedJsonNullableFilter<$PrismaModel>
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type SharedVendorScalarRelationFilter = {
    is?: SharedVendorWhereInput
    isNot?: SharedVendorWhereInput
  }

  export type SharedOfferNullableScalarRelationFilter = {
    is?: SharedOfferWhereInput | null
    isNot?: SharedOfferWhereInput | null
  }

  export type SharedPostOrderByRelevanceInput = {
    fields: SharedPostOrderByRelevanceFieldEnum | SharedPostOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SharedPostCountOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    postType?: SortOrder
    postCategory?: SortOrder
    postUrl?: SortOrder
    isOfferIncluded?: SortOrder
    offerId?: SortOrder
    isDownloaded?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedPostAvgOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerId?: SortOrder
  }

  export type SharedPostMaxOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    postType?: SortOrder
    postCategory?: SortOrder
    postUrl?: SortOrder
    isOfferIncluded?: SortOrder
    offerId?: SortOrder
    isDownloaded?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedPostMinOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    postType?: SortOrder
    postCategory?: SortOrder
    postUrl?: SortOrder
    isOfferIncluded?: SortOrder
    offerId?: SortOrder
    isDownloaded?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedPostSumOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerId?: SortOrder
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type SharedMenuCategoryOrderByRelevanceInput = {
    fields: SharedMenuCategoryOrderByRelevanceFieldEnum | SharedMenuCategoryOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SharedMenuCategoryCountOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryName?: SortOrder
    categoryImage?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuCategoryAvgOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
  }

  export type SharedMenuCategoryMaxOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryName?: SortOrder
    categoryImage?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuCategoryMinOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryName?: SortOrder
    categoryImage?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuCategorySumOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
  }

  export type SharedMenuCategoryScalarRelationFilter = {
    is?: SharedMenuCategoryWhereInput
    isNot?: SharedMenuCategoryWhereInput
  }

  export type SharedMenuSubCategoryOrderByRelevanceInput = {
    fields: SharedMenuSubCategoryOrderByRelevanceFieldEnum | SharedMenuSubCategoryOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SharedMenuSubCategoryCountOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryId?: SortOrder
    subCategoryName?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuSubCategoryAvgOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryId?: SortOrder
  }

  export type SharedMenuSubCategoryMaxOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryId?: SortOrder
    subCategoryName?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuSubCategoryMinOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryId?: SortOrder
    subCategoryName?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuSubCategorySumOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    categoryId?: SortOrder
  }

  export type DecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type SharedMenuSubCategoryNullableScalarRelationFilter = {
    is?: SharedMenuSubCategoryWhereInput | null
    isNot?: SharedMenuSubCategoryWhereInput | null
  }

  export type SharedMenuItemOrderByRelevanceInput = {
    fields: SharedMenuItemOrderByRelevanceFieldEnum | SharedMenuItemOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SharedMenuItemCountOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    menuCategoryId?: SortOrder
    menuSubCategoryId?: SortOrder
    productName?: SortOrder
    image?: SortOrder
    price?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuItemAvgOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    menuCategoryId?: SortOrder
    menuSubCategoryId?: SortOrder
    price?: SortOrder
  }

  export type SharedMenuItemMaxOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    menuCategoryId?: SortOrder
    menuSubCategoryId?: SortOrder
    productName?: SortOrder
    image?: SortOrder
    price?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuItemMinOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    menuCategoryId?: SortOrder
    menuSubCategoryId?: SortOrder
    productName?: SortOrder
    image?: SortOrder
    price?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedMenuItemSumOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    menuCategoryId?: SortOrder
    menuSubCategoryId?: SortOrder
    price?: SortOrder
  }

  export type DecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type SharedOfferOrderByRelevanceInput = {
    fields: SharedOfferOrderByRelevanceFieldEnum | SharedOfferOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SharedOfferCountOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerTargetType?: SortOrder
    offerTargetId?: SortOrder
    offerType?: SortOrder
    offerValue?: SortOrder
    validityFrom?: SortOrder
    validityTo?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedOfferAvgOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerTargetId?: SortOrder
  }

  export type SharedOfferMaxOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerTargetType?: SortOrder
    offerTargetId?: SortOrder
    offerType?: SortOrder
    validityFrom?: SortOrder
    validityTo?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedOfferMinOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerTargetType?: SortOrder
    offerTargetId?: SortOrder
    offerType?: SortOrder
    validityFrom?: SortOrder
    validityTo?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedOfferSumOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    offerTargetId?: SortOrder
  }
  export type JsonFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonFilterBase<$PrismaModel>>, 'path'>>

  export type JsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type SharedUserNullableScalarRelationFilter = {
    is?: SharedUserWhereInput | null
    isNot?: SharedUserWhereInput | null
  }

  export type SharedBillOrderByRelevanceInput = {
    fields: SharedBillOrderByRelevanceFieldEnum | SharedBillOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SharedBillCountOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    endUserId?: SortOrder
    products?: SortOrder
    totalPrice?: SortOrder
    paymentStatus?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedBillAvgOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    endUserId?: SortOrder
    totalPrice?: SortOrder
  }

  export type SharedBillMaxOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    endUserId?: SortOrder
    totalPrice?: SortOrder
    paymentStatus?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedBillMinOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    endUserId?: SortOrder
    totalPrice?: SortOrder
    paymentStatus?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SharedBillSumOrderByAggregateInput = {
    id?: SortOrder
    vendorId?: SortOrder
    endUserId?: SortOrder
    totalPrice?: SortOrder
  }
  export type JsonWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedJsonFilter<$PrismaModel>
    _max?: NestedJsonFilter<$PrismaModel>
  }

  export type SharedVendorCreateNestedManyWithoutUserInput = {
    create?: XOR<SharedVendorCreateWithoutUserInput, SharedVendorUncheckedCreateWithoutUserInput> | SharedVendorCreateWithoutUserInput[] | SharedVendorUncheckedCreateWithoutUserInput[]
    connectOrCreate?: SharedVendorCreateOrConnectWithoutUserInput | SharedVendorCreateOrConnectWithoutUserInput[]
    createMany?: SharedVendorCreateManyUserInputEnvelope
    connect?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
  }

  export type SharedBillCreateNestedManyWithoutEndUserInput = {
    create?: XOR<SharedBillCreateWithoutEndUserInput, SharedBillUncheckedCreateWithoutEndUserInput> | SharedBillCreateWithoutEndUserInput[] | SharedBillUncheckedCreateWithoutEndUserInput[]
    connectOrCreate?: SharedBillCreateOrConnectWithoutEndUserInput | SharedBillCreateOrConnectWithoutEndUserInput[]
    createMany?: SharedBillCreateManyEndUserInputEnvelope
    connect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
  }

  export type SharedVendorUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<SharedVendorCreateWithoutUserInput, SharedVendorUncheckedCreateWithoutUserInput> | SharedVendorCreateWithoutUserInput[] | SharedVendorUncheckedCreateWithoutUserInput[]
    connectOrCreate?: SharedVendorCreateOrConnectWithoutUserInput | SharedVendorCreateOrConnectWithoutUserInput[]
    createMany?: SharedVendorCreateManyUserInputEnvelope
    connect?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
  }

  export type SharedBillUncheckedCreateNestedManyWithoutEndUserInput = {
    create?: XOR<SharedBillCreateWithoutEndUserInput, SharedBillUncheckedCreateWithoutEndUserInput> | SharedBillCreateWithoutEndUserInput[] | SharedBillUncheckedCreateWithoutEndUserInput[]
    connectOrCreate?: SharedBillCreateOrConnectWithoutEndUserInput | SharedBillCreateOrConnectWithoutEndUserInput[]
    createMany?: SharedBillCreateManyEndUserInputEnvelope
    connect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type SharedVendorUpdateManyWithoutUserNestedInput = {
    create?: XOR<SharedVendorCreateWithoutUserInput, SharedVendorUncheckedCreateWithoutUserInput> | SharedVendorCreateWithoutUserInput[] | SharedVendorUncheckedCreateWithoutUserInput[]
    connectOrCreate?: SharedVendorCreateOrConnectWithoutUserInput | SharedVendorCreateOrConnectWithoutUserInput[]
    upsert?: SharedVendorUpsertWithWhereUniqueWithoutUserInput | SharedVendorUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: SharedVendorCreateManyUserInputEnvelope
    set?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
    disconnect?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
    delete?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
    connect?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
    update?: SharedVendorUpdateWithWhereUniqueWithoutUserInput | SharedVendorUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: SharedVendorUpdateManyWithWhereWithoutUserInput | SharedVendorUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: SharedVendorScalarWhereInput | SharedVendorScalarWhereInput[]
  }

  export type SharedBillUpdateManyWithoutEndUserNestedInput = {
    create?: XOR<SharedBillCreateWithoutEndUserInput, SharedBillUncheckedCreateWithoutEndUserInput> | SharedBillCreateWithoutEndUserInput[] | SharedBillUncheckedCreateWithoutEndUserInput[]
    connectOrCreate?: SharedBillCreateOrConnectWithoutEndUserInput | SharedBillCreateOrConnectWithoutEndUserInput[]
    upsert?: SharedBillUpsertWithWhereUniqueWithoutEndUserInput | SharedBillUpsertWithWhereUniqueWithoutEndUserInput[]
    createMany?: SharedBillCreateManyEndUserInputEnvelope
    set?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    disconnect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    delete?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    connect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    update?: SharedBillUpdateWithWhereUniqueWithoutEndUserInput | SharedBillUpdateWithWhereUniqueWithoutEndUserInput[]
    updateMany?: SharedBillUpdateManyWithWhereWithoutEndUserInput | SharedBillUpdateManyWithWhereWithoutEndUserInput[]
    deleteMany?: SharedBillScalarWhereInput | SharedBillScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type SharedVendorUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<SharedVendorCreateWithoutUserInput, SharedVendorUncheckedCreateWithoutUserInput> | SharedVendorCreateWithoutUserInput[] | SharedVendorUncheckedCreateWithoutUserInput[]
    connectOrCreate?: SharedVendorCreateOrConnectWithoutUserInput | SharedVendorCreateOrConnectWithoutUserInput[]
    upsert?: SharedVendorUpsertWithWhereUniqueWithoutUserInput | SharedVendorUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: SharedVendorCreateManyUserInputEnvelope
    set?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
    disconnect?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
    delete?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
    connect?: SharedVendorWhereUniqueInput | SharedVendorWhereUniqueInput[]
    update?: SharedVendorUpdateWithWhereUniqueWithoutUserInput | SharedVendorUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: SharedVendorUpdateManyWithWhereWithoutUserInput | SharedVendorUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: SharedVendorScalarWhereInput | SharedVendorScalarWhereInput[]
  }

  export type SharedBillUncheckedUpdateManyWithoutEndUserNestedInput = {
    create?: XOR<SharedBillCreateWithoutEndUserInput, SharedBillUncheckedCreateWithoutEndUserInput> | SharedBillCreateWithoutEndUserInput[] | SharedBillUncheckedCreateWithoutEndUserInput[]
    connectOrCreate?: SharedBillCreateOrConnectWithoutEndUserInput | SharedBillCreateOrConnectWithoutEndUserInput[]
    upsert?: SharedBillUpsertWithWhereUniqueWithoutEndUserInput | SharedBillUpsertWithWhereUniqueWithoutEndUserInput[]
    createMany?: SharedBillCreateManyEndUserInputEnvelope
    set?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    disconnect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    delete?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    connect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    update?: SharedBillUpdateWithWhereUniqueWithoutEndUserInput | SharedBillUpdateWithWhereUniqueWithoutEndUserInput[]
    updateMany?: SharedBillUpdateManyWithWhereWithoutEndUserInput | SharedBillUpdateManyWithWhereWithoutEndUserInput[]
    deleteMany?: SharedBillScalarWhereInput | SharedBillScalarWhereInput[]
  }

  export type SharedUserCreateNestedOneWithoutVendorsInput = {
    create?: XOR<SharedUserCreateWithoutVendorsInput, SharedUserUncheckedCreateWithoutVendorsInput>
    connectOrCreate?: SharedUserCreateOrConnectWithoutVendorsInput
    connect?: SharedUserWhereUniqueInput
  }

  export type SharedPostCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedPostCreateWithoutVendorInput, SharedPostUncheckedCreateWithoutVendorInput> | SharedPostCreateWithoutVendorInput[] | SharedPostUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedPostCreateOrConnectWithoutVendorInput | SharedPostCreateOrConnectWithoutVendorInput[]
    createMany?: SharedPostCreateManyVendorInputEnvelope
    connect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
  }

  export type SharedMenuCategoryCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedMenuCategoryCreateWithoutVendorInput, SharedMenuCategoryUncheckedCreateWithoutVendorInput> | SharedMenuCategoryCreateWithoutVendorInput[] | SharedMenuCategoryUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuCategoryCreateOrConnectWithoutVendorInput | SharedMenuCategoryCreateOrConnectWithoutVendorInput[]
    createMany?: SharedMenuCategoryCreateManyVendorInputEnvelope
    connect?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
  }

  export type SharedMenuSubCategoryCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutVendorInput, SharedMenuSubCategoryUncheckedCreateWithoutVendorInput> | SharedMenuSubCategoryCreateWithoutVendorInput[] | SharedMenuSubCategoryUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutVendorInput | SharedMenuSubCategoryCreateOrConnectWithoutVendorInput[]
    createMany?: SharedMenuSubCategoryCreateManyVendorInputEnvelope
    connect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
  }

  export type SharedMenuItemCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedMenuItemCreateWithoutVendorInput, SharedMenuItemUncheckedCreateWithoutVendorInput> | SharedMenuItemCreateWithoutVendorInput[] | SharedMenuItemUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutVendorInput | SharedMenuItemCreateOrConnectWithoutVendorInput[]
    createMany?: SharedMenuItemCreateManyVendorInputEnvelope
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
  }

  export type SharedOfferCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedOfferCreateWithoutVendorInput, SharedOfferUncheckedCreateWithoutVendorInput> | SharedOfferCreateWithoutVendorInput[] | SharedOfferUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedOfferCreateOrConnectWithoutVendorInput | SharedOfferCreateOrConnectWithoutVendorInput[]
    createMany?: SharedOfferCreateManyVendorInputEnvelope
    connect?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
  }

  export type SharedBillCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedBillCreateWithoutVendorInput, SharedBillUncheckedCreateWithoutVendorInput> | SharedBillCreateWithoutVendorInput[] | SharedBillUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedBillCreateOrConnectWithoutVendorInput | SharedBillCreateOrConnectWithoutVendorInput[]
    createMany?: SharedBillCreateManyVendorInputEnvelope
    connect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
  }

  export type SharedPostUncheckedCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedPostCreateWithoutVendorInput, SharedPostUncheckedCreateWithoutVendorInput> | SharedPostCreateWithoutVendorInput[] | SharedPostUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedPostCreateOrConnectWithoutVendorInput | SharedPostCreateOrConnectWithoutVendorInput[]
    createMany?: SharedPostCreateManyVendorInputEnvelope
    connect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
  }

  export type SharedMenuCategoryUncheckedCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedMenuCategoryCreateWithoutVendorInput, SharedMenuCategoryUncheckedCreateWithoutVendorInput> | SharedMenuCategoryCreateWithoutVendorInput[] | SharedMenuCategoryUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuCategoryCreateOrConnectWithoutVendorInput | SharedMenuCategoryCreateOrConnectWithoutVendorInput[]
    createMany?: SharedMenuCategoryCreateManyVendorInputEnvelope
    connect?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
  }

  export type SharedMenuSubCategoryUncheckedCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutVendorInput, SharedMenuSubCategoryUncheckedCreateWithoutVendorInput> | SharedMenuSubCategoryCreateWithoutVendorInput[] | SharedMenuSubCategoryUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutVendorInput | SharedMenuSubCategoryCreateOrConnectWithoutVendorInput[]
    createMany?: SharedMenuSubCategoryCreateManyVendorInputEnvelope
    connect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
  }

  export type SharedMenuItemUncheckedCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedMenuItemCreateWithoutVendorInput, SharedMenuItemUncheckedCreateWithoutVendorInput> | SharedMenuItemCreateWithoutVendorInput[] | SharedMenuItemUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutVendorInput | SharedMenuItemCreateOrConnectWithoutVendorInput[]
    createMany?: SharedMenuItemCreateManyVendorInputEnvelope
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
  }

  export type SharedOfferUncheckedCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedOfferCreateWithoutVendorInput, SharedOfferUncheckedCreateWithoutVendorInput> | SharedOfferCreateWithoutVendorInput[] | SharedOfferUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedOfferCreateOrConnectWithoutVendorInput | SharedOfferCreateOrConnectWithoutVendorInput[]
    createMany?: SharedOfferCreateManyVendorInputEnvelope
    connect?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
  }

  export type SharedBillUncheckedCreateNestedManyWithoutVendorInput = {
    create?: XOR<SharedBillCreateWithoutVendorInput, SharedBillUncheckedCreateWithoutVendorInput> | SharedBillCreateWithoutVendorInput[] | SharedBillUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedBillCreateOrConnectWithoutVendorInput | SharedBillCreateOrConnectWithoutVendorInput[]
    createMany?: SharedBillCreateManyVendorInputEnvelope
    connect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type SharedUserUpdateOneRequiredWithoutVendorsNestedInput = {
    create?: XOR<SharedUserCreateWithoutVendorsInput, SharedUserUncheckedCreateWithoutVendorsInput>
    connectOrCreate?: SharedUserCreateOrConnectWithoutVendorsInput
    upsert?: SharedUserUpsertWithoutVendorsInput
    connect?: SharedUserWhereUniqueInput
    update?: XOR<XOR<SharedUserUpdateToOneWithWhereWithoutVendorsInput, SharedUserUpdateWithoutVendorsInput>, SharedUserUncheckedUpdateWithoutVendorsInput>
  }

  export type SharedPostUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedPostCreateWithoutVendorInput, SharedPostUncheckedCreateWithoutVendorInput> | SharedPostCreateWithoutVendorInput[] | SharedPostUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedPostCreateOrConnectWithoutVendorInput | SharedPostCreateOrConnectWithoutVendorInput[]
    upsert?: SharedPostUpsertWithWhereUniqueWithoutVendorInput | SharedPostUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedPostCreateManyVendorInputEnvelope
    set?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    disconnect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    delete?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    connect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    update?: SharedPostUpdateWithWhereUniqueWithoutVendorInput | SharedPostUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedPostUpdateManyWithWhereWithoutVendorInput | SharedPostUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedPostScalarWhereInput | SharedPostScalarWhereInput[]
  }

  export type SharedMenuCategoryUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedMenuCategoryCreateWithoutVendorInput, SharedMenuCategoryUncheckedCreateWithoutVendorInput> | SharedMenuCategoryCreateWithoutVendorInput[] | SharedMenuCategoryUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuCategoryCreateOrConnectWithoutVendorInput | SharedMenuCategoryCreateOrConnectWithoutVendorInput[]
    upsert?: SharedMenuCategoryUpsertWithWhereUniqueWithoutVendorInput | SharedMenuCategoryUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedMenuCategoryCreateManyVendorInputEnvelope
    set?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
    disconnect?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
    delete?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
    connect?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
    update?: SharedMenuCategoryUpdateWithWhereUniqueWithoutVendorInput | SharedMenuCategoryUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedMenuCategoryUpdateManyWithWhereWithoutVendorInput | SharedMenuCategoryUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedMenuCategoryScalarWhereInput | SharedMenuCategoryScalarWhereInput[]
  }

  export type SharedMenuSubCategoryUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutVendorInput, SharedMenuSubCategoryUncheckedCreateWithoutVendorInput> | SharedMenuSubCategoryCreateWithoutVendorInput[] | SharedMenuSubCategoryUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutVendorInput | SharedMenuSubCategoryCreateOrConnectWithoutVendorInput[]
    upsert?: SharedMenuSubCategoryUpsertWithWhereUniqueWithoutVendorInput | SharedMenuSubCategoryUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedMenuSubCategoryCreateManyVendorInputEnvelope
    set?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    disconnect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    delete?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    connect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    update?: SharedMenuSubCategoryUpdateWithWhereUniqueWithoutVendorInput | SharedMenuSubCategoryUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedMenuSubCategoryUpdateManyWithWhereWithoutVendorInput | SharedMenuSubCategoryUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedMenuSubCategoryScalarWhereInput | SharedMenuSubCategoryScalarWhereInput[]
  }

  export type SharedMenuItemUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedMenuItemCreateWithoutVendorInput, SharedMenuItemUncheckedCreateWithoutVendorInput> | SharedMenuItemCreateWithoutVendorInput[] | SharedMenuItemUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutVendorInput | SharedMenuItemCreateOrConnectWithoutVendorInput[]
    upsert?: SharedMenuItemUpsertWithWhereUniqueWithoutVendorInput | SharedMenuItemUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedMenuItemCreateManyVendorInputEnvelope
    set?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    disconnect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    delete?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    update?: SharedMenuItemUpdateWithWhereUniqueWithoutVendorInput | SharedMenuItemUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedMenuItemUpdateManyWithWhereWithoutVendorInput | SharedMenuItemUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedMenuItemScalarWhereInput | SharedMenuItemScalarWhereInput[]
  }

  export type SharedOfferUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedOfferCreateWithoutVendorInput, SharedOfferUncheckedCreateWithoutVendorInput> | SharedOfferCreateWithoutVendorInput[] | SharedOfferUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedOfferCreateOrConnectWithoutVendorInput | SharedOfferCreateOrConnectWithoutVendorInput[]
    upsert?: SharedOfferUpsertWithWhereUniqueWithoutVendorInput | SharedOfferUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedOfferCreateManyVendorInputEnvelope
    set?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
    disconnect?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
    delete?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
    connect?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
    update?: SharedOfferUpdateWithWhereUniqueWithoutVendorInput | SharedOfferUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedOfferUpdateManyWithWhereWithoutVendorInput | SharedOfferUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedOfferScalarWhereInput | SharedOfferScalarWhereInput[]
  }

  export type SharedBillUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedBillCreateWithoutVendorInput, SharedBillUncheckedCreateWithoutVendorInput> | SharedBillCreateWithoutVendorInput[] | SharedBillUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedBillCreateOrConnectWithoutVendorInput | SharedBillCreateOrConnectWithoutVendorInput[]
    upsert?: SharedBillUpsertWithWhereUniqueWithoutVendorInput | SharedBillUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedBillCreateManyVendorInputEnvelope
    set?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    disconnect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    delete?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    connect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    update?: SharedBillUpdateWithWhereUniqueWithoutVendorInput | SharedBillUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedBillUpdateManyWithWhereWithoutVendorInput | SharedBillUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedBillScalarWhereInput | SharedBillScalarWhereInput[]
  }

  export type SharedPostUncheckedUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedPostCreateWithoutVendorInput, SharedPostUncheckedCreateWithoutVendorInput> | SharedPostCreateWithoutVendorInput[] | SharedPostUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedPostCreateOrConnectWithoutVendorInput | SharedPostCreateOrConnectWithoutVendorInput[]
    upsert?: SharedPostUpsertWithWhereUniqueWithoutVendorInput | SharedPostUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedPostCreateManyVendorInputEnvelope
    set?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    disconnect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    delete?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    connect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    update?: SharedPostUpdateWithWhereUniqueWithoutVendorInput | SharedPostUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedPostUpdateManyWithWhereWithoutVendorInput | SharedPostUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedPostScalarWhereInput | SharedPostScalarWhereInput[]
  }

  export type SharedMenuCategoryUncheckedUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedMenuCategoryCreateWithoutVendorInput, SharedMenuCategoryUncheckedCreateWithoutVendorInput> | SharedMenuCategoryCreateWithoutVendorInput[] | SharedMenuCategoryUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuCategoryCreateOrConnectWithoutVendorInput | SharedMenuCategoryCreateOrConnectWithoutVendorInput[]
    upsert?: SharedMenuCategoryUpsertWithWhereUniqueWithoutVendorInput | SharedMenuCategoryUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedMenuCategoryCreateManyVendorInputEnvelope
    set?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
    disconnect?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
    delete?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
    connect?: SharedMenuCategoryWhereUniqueInput | SharedMenuCategoryWhereUniqueInput[]
    update?: SharedMenuCategoryUpdateWithWhereUniqueWithoutVendorInput | SharedMenuCategoryUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedMenuCategoryUpdateManyWithWhereWithoutVendorInput | SharedMenuCategoryUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedMenuCategoryScalarWhereInput | SharedMenuCategoryScalarWhereInput[]
  }

  export type SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutVendorInput, SharedMenuSubCategoryUncheckedCreateWithoutVendorInput> | SharedMenuSubCategoryCreateWithoutVendorInput[] | SharedMenuSubCategoryUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutVendorInput | SharedMenuSubCategoryCreateOrConnectWithoutVendorInput[]
    upsert?: SharedMenuSubCategoryUpsertWithWhereUniqueWithoutVendorInput | SharedMenuSubCategoryUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedMenuSubCategoryCreateManyVendorInputEnvelope
    set?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    disconnect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    delete?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    connect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    update?: SharedMenuSubCategoryUpdateWithWhereUniqueWithoutVendorInput | SharedMenuSubCategoryUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedMenuSubCategoryUpdateManyWithWhereWithoutVendorInput | SharedMenuSubCategoryUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedMenuSubCategoryScalarWhereInput | SharedMenuSubCategoryScalarWhereInput[]
  }

  export type SharedMenuItemUncheckedUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedMenuItemCreateWithoutVendorInput, SharedMenuItemUncheckedCreateWithoutVendorInput> | SharedMenuItemCreateWithoutVendorInput[] | SharedMenuItemUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutVendorInput | SharedMenuItemCreateOrConnectWithoutVendorInput[]
    upsert?: SharedMenuItemUpsertWithWhereUniqueWithoutVendorInput | SharedMenuItemUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedMenuItemCreateManyVendorInputEnvelope
    set?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    disconnect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    delete?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    update?: SharedMenuItemUpdateWithWhereUniqueWithoutVendorInput | SharedMenuItemUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedMenuItemUpdateManyWithWhereWithoutVendorInput | SharedMenuItemUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedMenuItemScalarWhereInput | SharedMenuItemScalarWhereInput[]
  }

  export type SharedOfferUncheckedUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedOfferCreateWithoutVendorInput, SharedOfferUncheckedCreateWithoutVendorInput> | SharedOfferCreateWithoutVendorInput[] | SharedOfferUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedOfferCreateOrConnectWithoutVendorInput | SharedOfferCreateOrConnectWithoutVendorInput[]
    upsert?: SharedOfferUpsertWithWhereUniqueWithoutVendorInput | SharedOfferUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedOfferCreateManyVendorInputEnvelope
    set?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
    disconnect?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
    delete?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
    connect?: SharedOfferWhereUniqueInput | SharedOfferWhereUniqueInput[]
    update?: SharedOfferUpdateWithWhereUniqueWithoutVendorInput | SharedOfferUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedOfferUpdateManyWithWhereWithoutVendorInput | SharedOfferUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedOfferScalarWhereInput | SharedOfferScalarWhereInput[]
  }

  export type SharedBillUncheckedUpdateManyWithoutVendorNestedInput = {
    create?: XOR<SharedBillCreateWithoutVendorInput, SharedBillUncheckedCreateWithoutVendorInput> | SharedBillCreateWithoutVendorInput[] | SharedBillUncheckedCreateWithoutVendorInput[]
    connectOrCreate?: SharedBillCreateOrConnectWithoutVendorInput | SharedBillCreateOrConnectWithoutVendorInput[]
    upsert?: SharedBillUpsertWithWhereUniqueWithoutVendorInput | SharedBillUpsertWithWhereUniqueWithoutVendorInput[]
    createMany?: SharedBillCreateManyVendorInputEnvelope
    set?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    disconnect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    delete?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    connect?: SharedBillWhereUniqueInput | SharedBillWhereUniqueInput[]
    update?: SharedBillUpdateWithWhereUniqueWithoutVendorInput | SharedBillUpdateWithWhereUniqueWithoutVendorInput[]
    updateMany?: SharedBillUpdateManyWithWhereWithoutVendorInput | SharedBillUpdateManyWithWhereWithoutVendorInput[]
    deleteMany?: SharedBillScalarWhereInput | SharedBillScalarWhereInput[]
  }

  export type SharedVendorCreateNestedOneWithoutPostsInput = {
    create?: XOR<SharedVendorCreateWithoutPostsInput, SharedVendorUncheckedCreateWithoutPostsInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutPostsInput
    connect?: SharedVendorWhereUniqueInput
  }

  export type SharedOfferCreateNestedOneWithoutPostsInput = {
    create?: XOR<SharedOfferCreateWithoutPostsInput, SharedOfferUncheckedCreateWithoutPostsInput>
    connectOrCreate?: SharedOfferCreateOrConnectWithoutPostsInput
    connect?: SharedOfferWhereUniqueInput
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type SharedVendorUpdateOneRequiredWithoutPostsNestedInput = {
    create?: XOR<SharedVendorCreateWithoutPostsInput, SharedVendorUncheckedCreateWithoutPostsInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutPostsInput
    upsert?: SharedVendorUpsertWithoutPostsInput
    connect?: SharedVendorWhereUniqueInput
    update?: XOR<XOR<SharedVendorUpdateToOneWithWhereWithoutPostsInput, SharedVendorUpdateWithoutPostsInput>, SharedVendorUncheckedUpdateWithoutPostsInput>
  }

  export type SharedOfferUpdateOneWithoutPostsNestedInput = {
    create?: XOR<SharedOfferCreateWithoutPostsInput, SharedOfferUncheckedCreateWithoutPostsInput>
    connectOrCreate?: SharedOfferCreateOrConnectWithoutPostsInput
    upsert?: SharedOfferUpsertWithoutPostsInput
    disconnect?: SharedOfferWhereInput | boolean
    delete?: SharedOfferWhereInput | boolean
    connect?: SharedOfferWhereUniqueInput
    update?: XOR<XOR<SharedOfferUpdateToOneWithWhereWithoutPostsInput, SharedOfferUpdateWithoutPostsInput>, SharedOfferUncheckedUpdateWithoutPostsInput>
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type SharedVendorCreateNestedOneWithoutMenuCategoriesInput = {
    create?: XOR<SharedVendorCreateWithoutMenuCategoriesInput, SharedVendorUncheckedCreateWithoutMenuCategoriesInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutMenuCategoriesInput
    connect?: SharedVendorWhereUniqueInput
  }

  export type SharedMenuSubCategoryCreateNestedManyWithoutCategoryInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutCategoryInput, SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput> | SharedMenuSubCategoryCreateWithoutCategoryInput[] | SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput | SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput[]
    createMany?: SharedMenuSubCategoryCreateManyCategoryInputEnvelope
    connect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
  }

  export type SharedMenuItemCreateNestedManyWithoutCategoryInput = {
    create?: XOR<SharedMenuItemCreateWithoutCategoryInput, SharedMenuItemUncheckedCreateWithoutCategoryInput> | SharedMenuItemCreateWithoutCategoryInput[] | SharedMenuItemUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutCategoryInput | SharedMenuItemCreateOrConnectWithoutCategoryInput[]
    createMany?: SharedMenuItemCreateManyCategoryInputEnvelope
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
  }

  export type SharedMenuSubCategoryUncheckedCreateNestedManyWithoutCategoryInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutCategoryInput, SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput> | SharedMenuSubCategoryCreateWithoutCategoryInput[] | SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput | SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput[]
    createMany?: SharedMenuSubCategoryCreateManyCategoryInputEnvelope
    connect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
  }

  export type SharedMenuItemUncheckedCreateNestedManyWithoutCategoryInput = {
    create?: XOR<SharedMenuItemCreateWithoutCategoryInput, SharedMenuItemUncheckedCreateWithoutCategoryInput> | SharedMenuItemCreateWithoutCategoryInput[] | SharedMenuItemUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutCategoryInput | SharedMenuItemCreateOrConnectWithoutCategoryInput[]
    createMany?: SharedMenuItemCreateManyCategoryInputEnvelope
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
  }

  export type SharedVendorUpdateOneRequiredWithoutMenuCategoriesNestedInput = {
    create?: XOR<SharedVendorCreateWithoutMenuCategoriesInput, SharedVendorUncheckedCreateWithoutMenuCategoriesInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutMenuCategoriesInput
    upsert?: SharedVendorUpsertWithoutMenuCategoriesInput
    connect?: SharedVendorWhereUniqueInput
    update?: XOR<XOR<SharedVendorUpdateToOneWithWhereWithoutMenuCategoriesInput, SharedVendorUpdateWithoutMenuCategoriesInput>, SharedVendorUncheckedUpdateWithoutMenuCategoriesInput>
  }

  export type SharedMenuSubCategoryUpdateManyWithoutCategoryNestedInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutCategoryInput, SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput> | SharedMenuSubCategoryCreateWithoutCategoryInput[] | SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput | SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput[]
    upsert?: SharedMenuSubCategoryUpsertWithWhereUniqueWithoutCategoryInput | SharedMenuSubCategoryUpsertWithWhereUniqueWithoutCategoryInput[]
    createMany?: SharedMenuSubCategoryCreateManyCategoryInputEnvelope
    set?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    disconnect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    delete?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    connect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    update?: SharedMenuSubCategoryUpdateWithWhereUniqueWithoutCategoryInput | SharedMenuSubCategoryUpdateWithWhereUniqueWithoutCategoryInput[]
    updateMany?: SharedMenuSubCategoryUpdateManyWithWhereWithoutCategoryInput | SharedMenuSubCategoryUpdateManyWithWhereWithoutCategoryInput[]
    deleteMany?: SharedMenuSubCategoryScalarWhereInput | SharedMenuSubCategoryScalarWhereInput[]
  }

  export type SharedMenuItemUpdateManyWithoutCategoryNestedInput = {
    create?: XOR<SharedMenuItemCreateWithoutCategoryInput, SharedMenuItemUncheckedCreateWithoutCategoryInput> | SharedMenuItemCreateWithoutCategoryInput[] | SharedMenuItemUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutCategoryInput | SharedMenuItemCreateOrConnectWithoutCategoryInput[]
    upsert?: SharedMenuItemUpsertWithWhereUniqueWithoutCategoryInput | SharedMenuItemUpsertWithWhereUniqueWithoutCategoryInput[]
    createMany?: SharedMenuItemCreateManyCategoryInputEnvelope
    set?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    disconnect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    delete?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    update?: SharedMenuItemUpdateWithWhereUniqueWithoutCategoryInput | SharedMenuItemUpdateWithWhereUniqueWithoutCategoryInput[]
    updateMany?: SharedMenuItemUpdateManyWithWhereWithoutCategoryInput | SharedMenuItemUpdateManyWithWhereWithoutCategoryInput[]
    deleteMany?: SharedMenuItemScalarWhereInput | SharedMenuItemScalarWhereInput[]
  }

  export type SharedMenuSubCategoryUncheckedUpdateManyWithoutCategoryNestedInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutCategoryInput, SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput> | SharedMenuSubCategoryCreateWithoutCategoryInput[] | SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput | SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput[]
    upsert?: SharedMenuSubCategoryUpsertWithWhereUniqueWithoutCategoryInput | SharedMenuSubCategoryUpsertWithWhereUniqueWithoutCategoryInput[]
    createMany?: SharedMenuSubCategoryCreateManyCategoryInputEnvelope
    set?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    disconnect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    delete?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    connect?: SharedMenuSubCategoryWhereUniqueInput | SharedMenuSubCategoryWhereUniqueInput[]
    update?: SharedMenuSubCategoryUpdateWithWhereUniqueWithoutCategoryInput | SharedMenuSubCategoryUpdateWithWhereUniqueWithoutCategoryInput[]
    updateMany?: SharedMenuSubCategoryUpdateManyWithWhereWithoutCategoryInput | SharedMenuSubCategoryUpdateManyWithWhereWithoutCategoryInput[]
    deleteMany?: SharedMenuSubCategoryScalarWhereInput | SharedMenuSubCategoryScalarWhereInput[]
  }

  export type SharedMenuItemUncheckedUpdateManyWithoutCategoryNestedInput = {
    create?: XOR<SharedMenuItemCreateWithoutCategoryInput, SharedMenuItemUncheckedCreateWithoutCategoryInput> | SharedMenuItemCreateWithoutCategoryInput[] | SharedMenuItemUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutCategoryInput | SharedMenuItemCreateOrConnectWithoutCategoryInput[]
    upsert?: SharedMenuItemUpsertWithWhereUniqueWithoutCategoryInput | SharedMenuItemUpsertWithWhereUniqueWithoutCategoryInput[]
    createMany?: SharedMenuItemCreateManyCategoryInputEnvelope
    set?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    disconnect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    delete?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    update?: SharedMenuItemUpdateWithWhereUniqueWithoutCategoryInput | SharedMenuItemUpdateWithWhereUniqueWithoutCategoryInput[]
    updateMany?: SharedMenuItemUpdateManyWithWhereWithoutCategoryInput | SharedMenuItemUpdateManyWithWhereWithoutCategoryInput[]
    deleteMany?: SharedMenuItemScalarWhereInput | SharedMenuItemScalarWhereInput[]
  }

  export type SharedVendorCreateNestedOneWithoutMenuSubCategoriesInput = {
    create?: XOR<SharedVendorCreateWithoutMenuSubCategoriesInput, SharedVendorUncheckedCreateWithoutMenuSubCategoriesInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutMenuSubCategoriesInput
    connect?: SharedVendorWhereUniqueInput
  }

  export type SharedMenuCategoryCreateNestedOneWithoutSubCategoriesInput = {
    create?: XOR<SharedMenuCategoryCreateWithoutSubCategoriesInput, SharedMenuCategoryUncheckedCreateWithoutSubCategoriesInput>
    connectOrCreate?: SharedMenuCategoryCreateOrConnectWithoutSubCategoriesInput
    connect?: SharedMenuCategoryWhereUniqueInput
  }

  export type SharedMenuItemCreateNestedManyWithoutSubCategoryInput = {
    create?: XOR<SharedMenuItemCreateWithoutSubCategoryInput, SharedMenuItemUncheckedCreateWithoutSubCategoryInput> | SharedMenuItemCreateWithoutSubCategoryInput[] | SharedMenuItemUncheckedCreateWithoutSubCategoryInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutSubCategoryInput | SharedMenuItemCreateOrConnectWithoutSubCategoryInput[]
    createMany?: SharedMenuItemCreateManySubCategoryInputEnvelope
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
  }

  export type SharedMenuItemUncheckedCreateNestedManyWithoutSubCategoryInput = {
    create?: XOR<SharedMenuItemCreateWithoutSubCategoryInput, SharedMenuItemUncheckedCreateWithoutSubCategoryInput> | SharedMenuItemCreateWithoutSubCategoryInput[] | SharedMenuItemUncheckedCreateWithoutSubCategoryInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutSubCategoryInput | SharedMenuItemCreateOrConnectWithoutSubCategoryInput[]
    createMany?: SharedMenuItemCreateManySubCategoryInputEnvelope
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
  }

  export type SharedVendorUpdateOneRequiredWithoutMenuSubCategoriesNestedInput = {
    create?: XOR<SharedVendorCreateWithoutMenuSubCategoriesInput, SharedVendorUncheckedCreateWithoutMenuSubCategoriesInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutMenuSubCategoriesInput
    upsert?: SharedVendorUpsertWithoutMenuSubCategoriesInput
    connect?: SharedVendorWhereUniqueInput
    update?: XOR<XOR<SharedVendorUpdateToOneWithWhereWithoutMenuSubCategoriesInput, SharedVendorUpdateWithoutMenuSubCategoriesInput>, SharedVendorUncheckedUpdateWithoutMenuSubCategoriesInput>
  }

  export type SharedMenuCategoryUpdateOneRequiredWithoutSubCategoriesNestedInput = {
    create?: XOR<SharedMenuCategoryCreateWithoutSubCategoriesInput, SharedMenuCategoryUncheckedCreateWithoutSubCategoriesInput>
    connectOrCreate?: SharedMenuCategoryCreateOrConnectWithoutSubCategoriesInput
    upsert?: SharedMenuCategoryUpsertWithoutSubCategoriesInput
    connect?: SharedMenuCategoryWhereUniqueInput
    update?: XOR<XOR<SharedMenuCategoryUpdateToOneWithWhereWithoutSubCategoriesInput, SharedMenuCategoryUpdateWithoutSubCategoriesInput>, SharedMenuCategoryUncheckedUpdateWithoutSubCategoriesInput>
  }

  export type SharedMenuItemUpdateManyWithoutSubCategoryNestedInput = {
    create?: XOR<SharedMenuItemCreateWithoutSubCategoryInput, SharedMenuItemUncheckedCreateWithoutSubCategoryInput> | SharedMenuItemCreateWithoutSubCategoryInput[] | SharedMenuItemUncheckedCreateWithoutSubCategoryInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutSubCategoryInput | SharedMenuItemCreateOrConnectWithoutSubCategoryInput[]
    upsert?: SharedMenuItemUpsertWithWhereUniqueWithoutSubCategoryInput | SharedMenuItemUpsertWithWhereUniqueWithoutSubCategoryInput[]
    createMany?: SharedMenuItemCreateManySubCategoryInputEnvelope
    set?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    disconnect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    delete?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    update?: SharedMenuItemUpdateWithWhereUniqueWithoutSubCategoryInput | SharedMenuItemUpdateWithWhereUniqueWithoutSubCategoryInput[]
    updateMany?: SharedMenuItemUpdateManyWithWhereWithoutSubCategoryInput | SharedMenuItemUpdateManyWithWhereWithoutSubCategoryInput[]
    deleteMany?: SharedMenuItemScalarWhereInput | SharedMenuItemScalarWhereInput[]
  }

  export type SharedMenuItemUncheckedUpdateManyWithoutSubCategoryNestedInput = {
    create?: XOR<SharedMenuItemCreateWithoutSubCategoryInput, SharedMenuItemUncheckedCreateWithoutSubCategoryInput> | SharedMenuItemCreateWithoutSubCategoryInput[] | SharedMenuItemUncheckedCreateWithoutSubCategoryInput[]
    connectOrCreate?: SharedMenuItemCreateOrConnectWithoutSubCategoryInput | SharedMenuItemCreateOrConnectWithoutSubCategoryInput[]
    upsert?: SharedMenuItemUpsertWithWhereUniqueWithoutSubCategoryInput | SharedMenuItemUpsertWithWhereUniqueWithoutSubCategoryInput[]
    createMany?: SharedMenuItemCreateManySubCategoryInputEnvelope
    set?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    disconnect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    delete?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    connect?: SharedMenuItemWhereUniqueInput | SharedMenuItemWhereUniqueInput[]
    update?: SharedMenuItemUpdateWithWhereUniqueWithoutSubCategoryInput | SharedMenuItemUpdateWithWhereUniqueWithoutSubCategoryInput[]
    updateMany?: SharedMenuItemUpdateManyWithWhereWithoutSubCategoryInput | SharedMenuItemUpdateManyWithWhereWithoutSubCategoryInput[]
    deleteMany?: SharedMenuItemScalarWhereInput | SharedMenuItemScalarWhereInput[]
  }

  export type SharedVendorCreateNestedOneWithoutMenuItemsInput = {
    create?: XOR<SharedVendorCreateWithoutMenuItemsInput, SharedVendorUncheckedCreateWithoutMenuItemsInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutMenuItemsInput
    connect?: SharedVendorWhereUniqueInput
  }

  export type SharedMenuCategoryCreateNestedOneWithoutItemsInput = {
    create?: XOR<SharedMenuCategoryCreateWithoutItemsInput, SharedMenuCategoryUncheckedCreateWithoutItemsInput>
    connectOrCreate?: SharedMenuCategoryCreateOrConnectWithoutItemsInput
    connect?: SharedMenuCategoryWhereUniqueInput
  }

  export type SharedMenuSubCategoryCreateNestedOneWithoutItemsInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutItemsInput, SharedMenuSubCategoryUncheckedCreateWithoutItemsInput>
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutItemsInput
    connect?: SharedMenuSubCategoryWhereUniqueInput
  }

  export type DecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type SharedVendorUpdateOneRequiredWithoutMenuItemsNestedInput = {
    create?: XOR<SharedVendorCreateWithoutMenuItemsInput, SharedVendorUncheckedCreateWithoutMenuItemsInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutMenuItemsInput
    upsert?: SharedVendorUpsertWithoutMenuItemsInput
    connect?: SharedVendorWhereUniqueInput
    update?: XOR<XOR<SharedVendorUpdateToOneWithWhereWithoutMenuItemsInput, SharedVendorUpdateWithoutMenuItemsInput>, SharedVendorUncheckedUpdateWithoutMenuItemsInput>
  }

  export type SharedMenuCategoryUpdateOneRequiredWithoutItemsNestedInput = {
    create?: XOR<SharedMenuCategoryCreateWithoutItemsInput, SharedMenuCategoryUncheckedCreateWithoutItemsInput>
    connectOrCreate?: SharedMenuCategoryCreateOrConnectWithoutItemsInput
    upsert?: SharedMenuCategoryUpsertWithoutItemsInput
    connect?: SharedMenuCategoryWhereUniqueInput
    update?: XOR<XOR<SharedMenuCategoryUpdateToOneWithWhereWithoutItemsInput, SharedMenuCategoryUpdateWithoutItemsInput>, SharedMenuCategoryUncheckedUpdateWithoutItemsInput>
  }

  export type SharedMenuSubCategoryUpdateOneWithoutItemsNestedInput = {
    create?: XOR<SharedMenuSubCategoryCreateWithoutItemsInput, SharedMenuSubCategoryUncheckedCreateWithoutItemsInput>
    connectOrCreate?: SharedMenuSubCategoryCreateOrConnectWithoutItemsInput
    upsert?: SharedMenuSubCategoryUpsertWithoutItemsInput
    disconnect?: SharedMenuSubCategoryWhereInput | boolean
    delete?: SharedMenuSubCategoryWhereInput | boolean
    connect?: SharedMenuSubCategoryWhereUniqueInput
    update?: XOR<XOR<SharedMenuSubCategoryUpdateToOneWithWhereWithoutItemsInput, SharedMenuSubCategoryUpdateWithoutItemsInput>, SharedMenuSubCategoryUncheckedUpdateWithoutItemsInput>
  }

  export type SharedVendorCreateNestedOneWithoutOffersInput = {
    create?: XOR<SharedVendorCreateWithoutOffersInput, SharedVendorUncheckedCreateWithoutOffersInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutOffersInput
    connect?: SharedVendorWhereUniqueInput
  }

  export type SharedPostCreateNestedManyWithoutOfferInput = {
    create?: XOR<SharedPostCreateWithoutOfferInput, SharedPostUncheckedCreateWithoutOfferInput> | SharedPostCreateWithoutOfferInput[] | SharedPostUncheckedCreateWithoutOfferInput[]
    connectOrCreate?: SharedPostCreateOrConnectWithoutOfferInput | SharedPostCreateOrConnectWithoutOfferInput[]
    createMany?: SharedPostCreateManyOfferInputEnvelope
    connect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
  }

  export type SharedPostUncheckedCreateNestedManyWithoutOfferInput = {
    create?: XOR<SharedPostCreateWithoutOfferInput, SharedPostUncheckedCreateWithoutOfferInput> | SharedPostCreateWithoutOfferInput[] | SharedPostUncheckedCreateWithoutOfferInput[]
    connectOrCreate?: SharedPostCreateOrConnectWithoutOfferInput | SharedPostCreateOrConnectWithoutOfferInput[]
    createMany?: SharedPostCreateManyOfferInputEnvelope
    connect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
  }

  export type SharedVendorUpdateOneRequiredWithoutOffersNestedInput = {
    create?: XOR<SharedVendorCreateWithoutOffersInput, SharedVendorUncheckedCreateWithoutOffersInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutOffersInput
    upsert?: SharedVendorUpsertWithoutOffersInput
    connect?: SharedVendorWhereUniqueInput
    update?: XOR<XOR<SharedVendorUpdateToOneWithWhereWithoutOffersInput, SharedVendorUpdateWithoutOffersInput>, SharedVendorUncheckedUpdateWithoutOffersInput>
  }

  export type SharedPostUpdateManyWithoutOfferNestedInput = {
    create?: XOR<SharedPostCreateWithoutOfferInput, SharedPostUncheckedCreateWithoutOfferInput> | SharedPostCreateWithoutOfferInput[] | SharedPostUncheckedCreateWithoutOfferInput[]
    connectOrCreate?: SharedPostCreateOrConnectWithoutOfferInput | SharedPostCreateOrConnectWithoutOfferInput[]
    upsert?: SharedPostUpsertWithWhereUniqueWithoutOfferInput | SharedPostUpsertWithWhereUniqueWithoutOfferInput[]
    createMany?: SharedPostCreateManyOfferInputEnvelope
    set?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    disconnect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    delete?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    connect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    update?: SharedPostUpdateWithWhereUniqueWithoutOfferInput | SharedPostUpdateWithWhereUniqueWithoutOfferInput[]
    updateMany?: SharedPostUpdateManyWithWhereWithoutOfferInput | SharedPostUpdateManyWithWhereWithoutOfferInput[]
    deleteMany?: SharedPostScalarWhereInput | SharedPostScalarWhereInput[]
  }

  export type SharedPostUncheckedUpdateManyWithoutOfferNestedInput = {
    create?: XOR<SharedPostCreateWithoutOfferInput, SharedPostUncheckedCreateWithoutOfferInput> | SharedPostCreateWithoutOfferInput[] | SharedPostUncheckedCreateWithoutOfferInput[]
    connectOrCreate?: SharedPostCreateOrConnectWithoutOfferInput | SharedPostCreateOrConnectWithoutOfferInput[]
    upsert?: SharedPostUpsertWithWhereUniqueWithoutOfferInput | SharedPostUpsertWithWhereUniqueWithoutOfferInput[]
    createMany?: SharedPostCreateManyOfferInputEnvelope
    set?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    disconnect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    delete?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    connect?: SharedPostWhereUniqueInput | SharedPostWhereUniqueInput[]
    update?: SharedPostUpdateWithWhereUniqueWithoutOfferInput | SharedPostUpdateWithWhereUniqueWithoutOfferInput[]
    updateMany?: SharedPostUpdateManyWithWhereWithoutOfferInput | SharedPostUpdateManyWithWhereWithoutOfferInput[]
    deleteMany?: SharedPostScalarWhereInput | SharedPostScalarWhereInput[]
  }

  export type SharedVendorCreateNestedOneWithoutBillsInput = {
    create?: XOR<SharedVendorCreateWithoutBillsInput, SharedVendorUncheckedCreateWithoutBillsInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutBillsInput
    connect?: SharedVendorWhereUniqueInput
  }

  export type SharedUserCreateNestedOneWithoutBillsInput = {
    create?: XOR<SharedUserCreateWithoutBillsInput, SharedUserUncheckedCreateWithoutBillsInput>
    connectOrCreate?: SharedUserCreateOrConnectWithoutBillsInput
    connect?: SharedUserWhereUniqueInput
  }

  export type SharedVendorUpdateOneRequiredWithoutBillsNestedInput = {
    create?: XOR<SharedVendorCreateWithoutBillsInput, SharedVendorUncheckedCreateWithoutBillsInput>
    connectOrCreate?: SharedVendorCreateOrConnectWithoutBillsInput
    upsert?: SharedVendorUpsertWithoutBillsInput
    connect?: SharedVendorWhereUniqueInput
    update?: XOR<XOR<SharedVendorUpdateToOneWithWhereWithoutBillsInput, SharedVendorUpdateWithoutBillsInput>, SharedVendorUncheckedUpdateWithoutBillsInput>
  }

  export type SharedUserUpdateOneWithoutBillsNestedInput = {
    create?: XOR<SharedUserCreateWithoutBillsInput, SharedUserUncheckedCreateWithoutBillsInput>
    connectOrCreate?: SharedUserCreateOrConnectWithoutBillsInput
    upsert?: SharedUserUpsertWithoutBillsInput
    disconnect?: SharedUserWhereInput | boolean
    delete?: SharedUserWhereInput | boolean
    connect?: SharedUserWhereUniqueInput
    update?: XOR<XOR<SharedUserUpdateToOneWithWhereWithoutBillsInput, SharedUserUpdateWithoutBillsInput>, SharedUserUncheckedUpdateWithoutBillsInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }
  export type NestedJsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type NestedDecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }
  export type NestedJsonFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type SharedVendorCreateWithoutUserInput = {
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemCreateNestedManyWithoutVendorInput
    offers?: SharedOfferCreateNestedManyWithoutVendorInput
    bills?: SharedBillCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUncheckedCreateWithoutUserInput = {
    id?: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemUncheckedCreateNestedManyWithoutVendorInput
    offers?: SharedOfferUncheckedCreateNestedManyWithoutVendorInput
    bills?: SharedBillUncheckedCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorCreateOrConnectWithoutUserInput = {
    where: SharedVendorWhereUniqueInput
    create: XOR<SharedVendorCreateWithoutUserInput, SharedVendorUncheckedCreateWithoutUserInput>
  }

  export type SharedVendorCreateManyUserInputEnvelope = {
    data: SharedVendorCreateManyUserInput | SharedVendorCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type SharedBillCreateWithoutEndUserInput = {
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutBillsInput
  }

  export type SharedBillUncheckedCreateWithoutEndUserInput = {
    id?: number
    vendorId: number
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedBillCreateOrConnectWithoutEndUserInput = {
    where: SharedBillWhereUniqueInput
    create: XOR<SharedBillCreateWithoutEndUserInput, SharedBillUncheckedCreateWithoutEndUserInput>
  }

  export type SharedBillCreateManyEndUserInputEnvelope = {
    data: SharedBillCreateManyEndUserInput | SharedBillCreateManyEndUserInput[]
    skipDuplicates?: boolean
  }

  export type SharedVendorUpsertWithWhereUniqueWithoutUserInput = {
    where: SharedVendorWhereUniqueInput
    update: XOR<SharedVendorUpdateWithoutUserInput, SharedVendorUncheckedUpdateWithoutUserInput>
    create: XOR<SharedVendorCreateWithoutUserInput, SharedVendorUncheckedCreateWithoutUserInput>
  }

  export type SharedVendorUpdateWithWhereUniqueWithoutUserInput = {
    where: SharedVendorWhereUniqueInput
    data: XOR<SharedVendorUpdateWithoutUserInput, SharedVendorUncheckedUpdateWithoutUserInput>
  }

  export type SharedVendorUpdateManyWithWhereWithoutUserInput = {
    where: SharedVendorScalarWhereInput
    data: XOR<SharedVendorUpdateManyMutationInput, SharedVendorUncheckedUpdateManyWithoutUserInput>
  }

  export type SharedVendorScalarWhereInput = {
    AND?: SharedVendorScalarWhereInput | SharedVendorScalarWhereInput[]
    OR?: SharedVendorScalarWhereInput[]
    NOT?: SharedVendorScalarWhereInput | SharedVendorScalarWhereInput[]
    id?: IntFilter<"SharedVendor"> | number
    userId?: IntFilter<"SharedVendor"> | number
    businessName?: StringNullableFilter<"SharedVendor"> | string | null
    status?: StringFilter<"SharedVendor"> | string
    logoUrl?: StringNullableFilter<"SharedVendor"> | string | null
    businessCategory?: StringNullableFilter<"SharedVendor"> | string | null
    address?: StringNullableFilter<"SharedVendor"> | string | null
    payment?: JsonNullableFilter<"SharedVendor">
    workingDays?: JsonNullableFilter<"SharedVendor">
    createdAt?: DateTimeNullableFilter<"SharedVendor"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedVendor"> | Date | string | null
  }

  export type SharedBillUpsertWithWhereUniqueWithoutEndUserInput = {
    where: SharedBillWhereUniqueInput
    update: XOR<SharedBillUpdateWithoutEndUserInput, SharedBillUncheckedUpdateWithoutEndUserInput>
    create: XOR<SharedBillCreateWithoutEndUserInput, SharedBillUncheckedCreateWithoutEndUserInput>
  }

  export type SharedBillUpdateWithWhereUniqueWithoutEndUserInput = {
    where: SharedBillWhereUniqueInput
    data: XOR<SharedBillUpdateWithoutEndUserInput, SharedBillUncheckedUpdateWithoutEndUserInput>
  }

  export type SharedBillUpdateManyWithWhereWithoutEndUserInput = {
    where: SharedBillScalarWhereInput
    data: XOR<SharedBillUpdateManyMutationInput, SharedBillUncheckedUpdateManyWithoutEndUserInput>
  }

  export type SharedBillScalarWhereInput = {
    AND?: SharedBillScalarWhereInput | SharedBillScalarWhereInput[]
    OR?: SharedBillScalarWhereInput[]
    NOT?: SharedBillScalarWhereInput | SharedBillScalarWhereInput[]
    id?: IntFilter<"SharedBill"> | number
    vendorId?: IntFilter<"SharedBill"> | number
    endUserId?: IntNullableFilter<"SharedBill"> | number | null
    products?: JsonFilter<"SharedBill">
    totalPrice?: DecimalFilter<"SharedBill"> | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFilter<"SharedBill"> | string
    createdAt?: DateTimeNullableFilter<"SharedBill"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedBill"> | Date | string | null
  }

  export type SharedUserCreateWithoutVendorsInput = {
    phoneNumber: string
    userType: string
    status: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    bills?: SharedBillCreateNestedManyWithoutEndUserInput
  }

  export type SharedUserUncheckedCreateWithoutVendorsInput = {
    id?: number
    phoneNumber: string
    userType: string
    status: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    bills?: SharedBillUncheckedCreateNestedManyWithoutEndUserInput
  }

  export type SharedUserCreateOrConnectWithoutVendorsInput = {
    where: SharedUserWhereUniqueInput
    create: XOR<SharedUserCreateWithoutVendorsInput, SharedUserUncheckedCreateWithoutVendorsInput>
  }

  export type SharedPostCreateWithoutVendorInput = {
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    offer?: SharedOfferCreateNestedOneWithoutPostsInput
  }

  export type SharedPostUncheckedCreateWithoutVendorInput = {
    id?: number
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    offerId?: number | null
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedPostCreateOrConnectWithoutVendorInput = {
    where: SharedPostWhereUniqueInput
    create: XOR<SharedPostCreateWithoutVendorInput, SharedPostUncheckedCreateWithoutVendorInput>
  }

  export type SharedPostCreateManyVendorInputEnvelope = {
    data: SharedPostCreateManyVendorInput | SharedPostCreateManyVendorInput[]
    skipDuplicates?: boolean
  }

  export type SharedMenuCategoryCreateWithoutVendorInput = {
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    subCategories?: SharedMenuSubCategoryCreateNestedManyWithoutCategoryInput
    items?: SharedMenuItemCreateNestedManyWithoutCategoryInput
  }

  export type SharedMenuCategoryUncheckedCreateWithoutVendorInput = {
    id?: number
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    subCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutCategoryInput
    items?: SharedMenuItemUncheckedCreateNestedManyWithoutCategoryInput
  }

  export type SharedMenuCategoryCreateOrConnectWithoutVendorInput = {
    where: SharedMenuCategoryWhereUniqueInput
    create: XOR<SharedMenuCategoryCreateWithoutVendorInput, SharedMenuCategoryUncheckedCreateWithoutVendorInput>
  }

  export type SharedMenuCategoryCreateManyVendorInputEnvelope = {
    data: SharedMenuCategoryCreateManyVendorInput | SharedMenuCategoryCreateManyVendorInput[]
    skipDuplicates?: boolean
  }

  export type SharedMenuSubCategoryCreateWithoutVendorInput = {
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    category: SharedMenuCategoryCreateNestedOneWithoutSubCategoriesInput
    items?: SharedMenuItemCreateNestedManyWithoutSubCategoryInput
  }

  export type SharedMenuSubCategoryUncheckedCreateWithoutVendorInput = {
    id?: number
    categoryId: number
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    items?: SharedMenuItemUncheckedCreateNestedManyWithoutSubCategoryInput
  }

  export type SharedMenuSubCategoryCreateOrConnectWithoutVendorInput = {
    where: SharedMenuSubCategoryWhereUniqueInput
    create: XOR<SharedMenuSubCategoryCreateWithoutVendorInput, SharedMenuSubCategoryUncheckedCreateWithoutVendorInput>
  }

  export type SharedMenuSubCategoryCreateManyVendorInputEnvelope = {
    data: SharedMenuSubCategoryCreateManyVendorInput | SharedMenuSubCategoryCreateManyVendorInput[]
    skipDuplicates?: boolean
  }

  export type SharedMenuItemCreateWithoutVendorInput = {
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    category: SharedMenuCategoryCreateNestedOneWithoutItemsInput
    subCategory?: SharedMenuSubCategoryCreateNestedOneWithoutItemsInput
  }

  export type SharedMenuItemUncheckedCreateWithoutVendorInput = {
    id?: number
    menuCategoryId: number
    menuSubCategoryId?: number | null
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuItemCreateOrConnectWithoutVendorInput = {
    where: SharedMenuItemWhereUniqueInput
    create: XOR<SharedMenuItemCreateWithoutVendorInput, SharedMenuItemUncheckedCreateWithoutVendorInput>
  }

  export type SharedMenuItemCreateManyVendorInputEnvelope = {
    data: SharedMenuItemCreateManyVendorInput | SharedMenuItemCreateManyVendorInput[]
    skipDuplicates?: boolean
  }

  export type SharedOfferCreateWithoutVendorInput = {
    offerTargetType?: string | null
    offerTargetId?: number | null
    offerType: string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: Date | string | null
    validityTo?: Date | string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostCreateNestedManyWithoutOfferInput
  }

  export type SharedOfferUncheckedCreateWithoutVendorInput = {
    id?: number
    offerTargetType?: string | null
    offerTargetId?: number | null
    offerType: string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: Date | string | null
    validityTo?: Date | string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutOfferInput
  }

  export type SharedOfferCreateOrConnectWithoutVendorInput = {
    where: SharedOfferWhereUniqueInput
    create: XOR<SharedOfferCreateWithoutVendorInput, SharedOfferUncheckedCreateWithoutVendorInput>
  }

  export type SharedOfferCreateManyVendorInputEnvelope = {
    data: SharedOfferCreateManyVendorInput | SharedOfferCreateManyVendorInput[]
    skipDuplicates?: boolean
  }

  export type SharedBillCreateWithoutVendorInput = {
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    endUser?: SharedUserCreateNestedOneWithoutBillsInput
  }

  export type SharedBillUncheckedCreateWithoutVendorInput = {
    id?: number
    endUserId?: number | null
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedBillCreateOrConnectWithoutVendorInput = {
    where: SharedBillWhereUniqueInput
    create: XOR<SharedBillCreateWithoutVendorInput, SharedBillUncheckedCreateWithoutVendorInput>
  }

  export type SharedBillCreateManyVendorInputEnvelope = {
    data: SharedBillCreateManyVendorInput | SharedBillCreateManyVendorInput[]
    skipDuplicates?: boolean
  }

  export type SharedUserUpsertWithoutVendorsInput = {
    update: XOR<SharedUserUpdateWithoutVendorsInput, SharedUserUncheckedUpdateWithoutVendorsInput>
    create: XOR<SharedUserCreateWithoutVendorsInput, SharedUserUncheckedCreateWithoutVendorsInput>
    where?: SharedUserWhereInput
  }

  export type SharedUserUpdateToOneWithWhereWithoutVendorsInput = {
    where?: SharedUserWhereInput
    data: XOR<SharedUserUpdateWithoutVendorsInput, SharedUserUncheckedUpdateWithoutVendorsInput>
  }

  export type SharedUserUpdateWithoutVendorsInput = {
    phoneNumber?: StringFieldUpdateOperationsInput | string
    userType?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    bills?: SharedBillUpdateManyWithoutEndUserNestedInput
  }

  export type SharedUserUncheckedUpdateWithoutVendorsInput = {
    id?: IntFieldUpdateOperationsInput | number
    phoneNumber?: StringFieldUpdateOperationsInput | string
    userType?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    bills?: SharedBillUncheckedUpdateManyWithoutEndUserNestedInput
  }

  export type SharedPostUpsertWithWhereUniqueWithoutVendorInput = {
    where: SharedPostWhereUniqueInput
    update: XOR<SharedPostUpdateWithoutVendorInput, SharedPostUncheckedUpdateWithoutVendorInput>
    create: XOR<SharedPostCreateWithoutVendorInput, SharedPostUncheckedCreateWithoutVendorInput>
  }

  export type SharedPostUpdateWithWhereUniqueWithoutVendorInput = {
    where: SharedPostWhereUniqueInput
    data: XOR<SharedPostUpdateWithoutVendorInput, SharedPostUncheckedUpdateWithoutVendorInput>
  }

  export type SharedPostUpdateManyWithWhereWithoutVendorInput = {
    where: SharedPostScalarWhereInput
    data: XOR<SharedPostUpdateManyMutationInput, SharedPostUncheckedUpdateManyWithoutVendorInput>
  }

  export type SharedPostScalarWhereInput = {
    AND?: SharedPostScalarWhereInput | SharedPostScalarWhereInput[]
    OR?: SharedPostScalarWhereInput[]
    NOT?: SharedPostScalarWhereInput | SharedPostScalarWhereInput[]
    id?: IntFilter<"SharedPost"> | number
    vendorId?: IntFilter<"SharedPost"> | number
    postType?: StringFilter<"SharedPost"> | string
    postCategory?: StringNullableFilter<"SharedPost"> | string | null
    postUrl?: StringFilter<"SharedPost"> | string
    isOfferIncluded?: BoolFilter<"SharedPost"> | boolean
    offerId?: IntNullableFilter<"SharedPost"> | number | null
    isDownloaded?: BoolFilter<"SharedPost"> | boolean
    createdAt?: DateTimeNullableFilter<"SharedPost"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedPost"> | Date | string | null
  }

  export type SharedMenuCategoryUpsertWithWhereUniqueWithoutVendorInput = {
    where: SharedMenuCategoryWhereUniqueInput
    update: XOR<SharedMenuCategoryUpdateWithoutVendorInput, SharedMenuCategoryUncheckedUpdateWithoutVendorInput>
    create: XOR<SharedMenuCategoryCreateWithoutVendorInput, SharedMenuCategoryUncheckedCreateWithoutVendorInput>
  }

  export type SharedMenuCategoryUpdateWithWhereUniqueWithoutVendorInput = {
    where: SharedMenuCategoryWhereUniqueInput
    data: XOR<SharedMenuCategoryUpdateWithoutVendorInput, SharedMenuCategoryUncheckedUpdateWithoutVendorInput>
  }

  export type SharedMenuCategoryUpdateManyWithWhereWithoutVendorInput = {
    where: SharedMenuCategoryScalarWhereInput
    data: XOR<SharedMenuCategoryUpdateManyMutationInput, SharedMenuCategoryUncheckedUpdateManyWithoutVendorInput>
  }

  export type SharedMenuCategoryScalarWhereInput = {
    AND?: SharedMenuCategoryScalarWhereInput | SharedMenuCategoryScalarWhereInput[]
    OR?: SharedMenuCategoryScalarWhereInput[]
    NOT?: SharedMenuCategoryScalarWhereInput | SharedMenuCategoryScalarWhereInput[]
    id?: IntFilter<"SharedMenuCategory"> | number
    vendorId?: IntFilter<"SharedMenuCategory"> | number
    categoryName?: StringFilter<"SharedMenuCategory"> | string
    categoryImage?: StringNullableFilter<"SharedMenuCategory"> | string | null
    createdAt?: DateTimeNullableFilter<"SharedMenuCategory"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuCategory"> | Date | string | null
  }

  export type SharedMenuSubCategoryUpsertWithWhereUniqueWithoutVendorInput = {
    where: SharedMenuSubCategoryWhereUniqueInput
    update: XOR<SharedMenuSubCategoryUpdateWithoutVendorInput, SharedMenuSubCategoryUncheckedUpdateWithoutVendorInput>
    create: XOR<SharedMenuSubCategoryCreateWithoutVendorInput, SharedMenuSubCategoryUncheckedCreateWithoutVendorInput>
  }

  export type SharedMenuSubCategoryUpdateWithWhereUniqueWithoutVendorInput = {
    where: SharedMenuSubCategoryWhereUniqueInput
    data: XOR<SharedMenuSubCategoryUpdateWithoutVendorInput, SharedMenuSubCategoryUncheckedUpdateWithoutVendorInput>
  }

  export type SharedMenuSubCategoryUpdateManyWithWhereWithoutVendorInput = {
    where: SharedMenuSubCategoryScalarWhereInput
    data: XOR<SharedMenuSubCategoryUpdateManyMutationInput, SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorInput>
  }

  export type SharedMenuSubCategoryScalarWhereInput = {
    AND?: SharedMenuSubCategoryScalarWhereInput | SharedMenuSubCategoryScalarWhereInput[]
    OR?: SharedMenuSubCategoryScalarWhereInput[]
    NOT?: SharedMenuSubCategoryScalarWhereInput | SharedMenuSubCategoryScalarWhereInput[]
    id?: IntFilter<"SharedMenuSubCategory"> | number
    vendorId?: IntFilter<"SharedMenuSubCategory"> | number
    categoryId?: IntFilter<"SharedMenuSubCategory"> | number
    subCategoryName?: StringFilter<"SharedMenuSubCategory"> | string
    createdAt?: DateTimeNullableFilter<"SharedMenuSubCategory"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuSubCategory"> | Date | string | null
  }

  export type SharedMenuItemUpsertWithWhereUniqueWithoutVendorInput = {
    where: SharedMenuItemWhereUniqueInput
    update: XOR<SharedMenuItemUpdateWithoutVendorInput, SharedMenuItemUncheckedUpdateWithoutVendorInput>
    create: XOR<SharedMenuItemCreateWithoutVendorInput, SharedMenuItemUncheckedCreateWithoutVendorInput>
  }

  export type SharedMenuItemUpdateWithWhereUniqueWithoutVendorInput = {
    where: SharedMenuItemWhereUniqueInput
    data: XOR<SharedMenuItemUpdateWithoutVendorInput, SharedMenuItemUncheckedUpdateWithoutVendorInput>
  }

  export type SharedMenuItemUpdateManyWithWhereWithoutVendorInput = {
    where: SharedMenuItemScalarWhereInput
    data: XOR<SharedMenuItemUpdateManyMutationInput, SharedMenuItemUncheckedUpdateManyWithoutVendorInput>
  }

  export type SharedMenuItemScalarWhereInput = {
    AND?: SharedMenuItemScalarWhereInput | SharedMenuItemScalarWhereInput[]
    OR?: SharedMenuItemScalarWhereInput[]
    NOT?: SharedMenuItemScalarWhereInput | SharedMenuItemScalarWhereInput[]
    id?: IntFilter<"SharedMenuItem"> | number
    vendorId?: IntFilter<"SharedMenuItem"> | number
    menuCategoryId?: IntFilter<"SharedMenuItem"> | number
    menuSubCategoryId?: IntNullableFilter<"SharedMenuItem"> | number | null
    productName?: StringFilter<"SharedMenuItem"> | string
    image?: StringNullableFilter<"SharedMenuItem"> | string | null
    price?: DecimalFilter<"SharedMenuItem"> | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeNullableFilter<"SharedMenuItem"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedMenuItem"> | Date | string | null
  }

  export type SharedOfferUpsertWithWhereUniqueWithoutVendorInput = {
    where: SharedOfferWhereUniqueInput
    update: XOR<SharedOfferUpdateWithoutVendorInput, SharedOfferUncheckedUpdateWithoutVendorInput>
    create: XOR<SharedOfferCreateWithoutVendorInput, SharedOfferUncheckedCreateWithoutVendorInput>
  }

  export type SharedOfferUpdateWithWhereUniqueWithoutVendorInput = {
    where: SharedOfferWhereUniqueInput
    data: XOR<SharedOfferUpdateWithoutVendorInput, SharedOfferUncheckedUpdateWithoutVendorInput>
  }

  export type SharedOfferUpdateManyWithWhereWithoutVendorInput = {
    where: SharedOfferScalarWhereInput
    data: XOR<SharedOfferUpdateManyMutationInput, SharedOfferUncheckedUpdateManyWithoutVendorInput>
  }

  export type SharedOfferScalarWhereInput = {
    AND?: SharedOfferScalarWhereInput | SharedOfferScalarWhereInput[]
    OR?: SharedOfferScalarWhereInput[]
    NOT?: SharedOfferScalarWhereInput | SharedOfferScalarWhereInput[]
    id?: IntFilter<"SharedOffer"> | number
    vendorId?: IntFilter<"SharedOffer"> | number
    offerTargetType?: StringNullableFilter<"SharedOffer"> | string | null
    offerTargetId?: IntNullableFilter<"SharedOffer"> | number | null
    offerType?: StringFilter<"SharedOffer"> | string
    offerValue?: JsonNullableFilter<"SharedOffer">
    validityFrom?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    validityTo?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    createdAt?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
    updatedAt?: DateTimeNullableFilter<"SharedOffer"> | Date | string | null
  }

  export type SharedBillUpsertWithWhereUniqueWithoutVendorInput = {
    where: SharedBillWhereUniqueInput
    update: XOR<SharedBillUpdateWithoutVendorInput, SharedBillUncheckedUpdateWithoutVendorInput>
    create: XOR<SharedBillCreateWithoutVendorInput, SharedBillUncheckedCreateWithoutVendorInput>
  }

  export type SharedBillUpdateWithWhereUniqueWithoutVendorInput = {
    where: SharedBillWhereUniqueInput
    data: XOR<SharedBillUpdateWithoutVendorInput, SharedBillUncheckedUpdateWithoutVendorInput>
  }

  export type SharedBillUpdateManyWithWhereWithoutVendorInput = {
    where: SharedBillScalarWhereInput
    data: XOR<SharedBillUpdateManyMutationInput, SharedBillUncheckedUpdateManyWithoutVendorInput>
  }

  export type SharedVendorCreateWithoutPostsInput = {
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    user: SharedUserCreateNestedOneWithoutVendorsInput
    menuCategories?: SharedMenuCategoryCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemCreateNestedManyWithoutVendorInput
    offers?: SharedOfferCreateNestedManyWithoutVendorInput
    bills?: SharedBillCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUncheckedCreateWithoutPostsInput = {
    id?: number
    userId: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    menuCategories?: SharedMenuCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemUncheckedCreateNestedManyWithoutVendorInput
    offers?: SharedOfferUncheckedCreateNestedManyWithoutVendorInput
    bills?: SharedBillUncheckedCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorCreateOrConnectWithoutPostsInput = {
    where: SharedVendorWhereUniqueInput
    create: XOR<SharedVendorCreateWithoutPostsInput, SharedVendorUncheckedCreateWithoutPostsInput>
  }

  export type SharedOfferCreateWithoutPostsInput = {
    offerTargetType?: string | null
    offerTargetId?: number | null
    offerType: string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: Date | string | null
    validityTo?: Date | string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutOffersInput
  }

  export type SharedOfferUncheckedCreateWithoutPostsInput = {
    id?: number
    vendorId: number
    offerTargetType?: string | null
    offerTargetId?: number | null
    offerType: string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: Date | string | null
    validityTo?: Date | string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedOfferCreateOrConnectWithoutPostsInput = {
    where: SharedOfferWhereUniqueInput
    create: XOR<SharedOfferCreateWithoutPostsInput, SharedOfferUncheckedCreateWithoutPostsInput>
  }

  export type SharedVendorUpsertWithoutPostsInput = {
    update: XOR<SharedVendorUpdateWithoutPostsInput, SharedVendorUncheckedUpdateWithoutPostsInput>
    create: XOR<SharedVendorCreateWithoutPostsInput, SharedVendorUncheckedCreateWithoutPostsInput>
    where?: SharedVendorWhereInput
  }

  export type SharedVendorUpdateToOneWithWhereWithoutPostsInput = {
    where?: SharedVendorWhereInput
    data: XOR<SharedVendorUpdateWithoutPostsInput, SharedVendorUncheckedUpdateWithoutPostsInput>
  }

  export type SharedVendorUpdateWithoutPostsInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: SharedUserUpdateOneRequiredWithoutVendorsNestedInput
    menuCategories?: SharedMenuCategoryUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateWithoutPostsInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    menuCategories?: SharedMenuCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUncheckedUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUncheckedUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUncheckedUpdateManyWithoutVendorNestedInput
  }

  export type SharedOfferUpsertWithoutPostsInput = {
    update: XOR<SharedOfferUpdateWithoutPostsInput, SharedOfferUncheckedUpdateWithoutPostsInput>
    create: XOR<SharedOfferCreateWithoutPostsInput, SharedOfferUncheckedCreateWithoutPostsInput>
    where?: SharedOfferWhereInput
  }

  export type SharedOfferUpdateToOneWithWhereWithoutPostsInput = {
    where?: SharedOfferWhereInput
    data: XOR<SharedOfferUpdateWithoutPostsInput, SharedOfferUncheckedUpdateWithoutPostsInput>
  }

  export type SharedOfferUpdateWithoutPostsInput = {
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutOffersNestedInput
  }

  export type SharedOfferUncheckedUpdateWithoutPostsInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedVendorCreateWithoutMenuCategoriesInput = {
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    user: SharedUserCreateNestedOneWithoutVendorsInput
    posts?: SharedPostCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemCreateNestedManyWithoutVendorInput
    offers?: SharedOfferCreateNestedManyWithoutVendorInput
    bills?: SharedBillCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUncheckedCreateWithoutMenuCategoriesInput = {
    id?: number
    userId: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemUncheckedCreateNestedManyWithoutVendorInput
    offers?: SharedOfferUncheckedCreateNestedManyWithoutVendorInput
    bills?: SharedBillUncheckedCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorCreateOrConnectWithoutMenuCategoriesInput = {
    where: SharedVendorWhereUniqueInput
    create: XOR<SharedVendorCreateWithoutMenuCategoriesInput, SharedVendorUncheckedCreateWithoutMenuCategoriesInput>
  }

  export type SharedMenuSubCategoryCreateWithoutCategoryInput = {
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuSubCategoriesInput
    items?: SharedMenuItemCreateNestedManyWithoutSubCategoryInput
  }

  export type SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput = {
    id?: number
    vendorId: number
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    items?: SharedMenuItemUncheckedCreateNestedManyWithoutSubCategoryInput
  }

  export type SharedMenuSubCategoryCreateOrConnectWithoutCategoryInput = {
    where: SharedMenuSubCategoryWhereUniqueInput
    create: XOR<SharedMenuSubCategoryCreateWithoutCategoryInput, SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput>
  }

  export type SharedMenuSubCategoryCreateManyCategoryInputEnvelope = {
    data: SharedMenuSubCategoryCreateManyCategoryInput | SharedMenuSubCategoryCreateManyCategoryInput[]
    skipDuplicates?: boolean
  }

  export type SharedMenuItemCreateWithoutCategoryInput = {
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuItemsInput
    subCategory?: SharedMenuSubCategoryCreateNestedOneWithoutItemsInput
  }

  export type SharedMenuItemUncheckedCreateWithoutCategoryInput = {
    id?: number
    vendorId: number
    menuSubCategoryId?: number | null
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuItemCreateOrConnectWithoutCategoryInput = {
    where: SharedMenuItemWhereUniqueInput
    create: XOR<SharedMenuItemCreateWithoutCategoryInput, SharedMenuItemUncheckedCreateWithoutCategoryInput>
  }

  export type SharedMenuItemCreateManyCategoryInputEnvelope = {
    data: SharedMenuItemCreateManyCategoryInput | SharedMenuItemCreateManyCategoryInput[]
    skipDuplicates?: boolean
  }

  export type SharedVendorUpsertWithoutMenuCategoriesInput = {
    update: XOR<SharedVendorUpdateWithoutMenuCategoriesInput, SharedVendorUncheckedUpdateWithoutMenuCategoriesInput>
    create: XOR<SharedVendorCreateWithoutMenuCategoriesInput, SharedVendorUncheckedCreateWithoutMenuCategoriesInput>
    where?: SharedVendorWhereInput
  }

  export type SharedVendorUpdateToOneWithWhereWithoutMenuCategoriesInput = {
    where?: SharedVendorWhereInput
    data: XOR<SharedVendorUpdateWithoutMenuCategoriesInput, SharedVendorUncheckedUpdateWithoutMenuCategoriesInput>
  }

  export type SharedVendorUpdateWithoutMenuCategoriesInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: SharedUserUpdateOneRequiredWithoutVendorsNestedInput
    posts?: SharedPostUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateWithoutMenuCategoriesInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUncheckedUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUncheckedUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUncheckedUpdateManyWithoutVendorNestedInput
  }

  export type SharedMenuSubCategoryUpsertWithWhereUniqueWithoutCategoryInput = {
    where: SharedMenuSubCategoryWhereUniqueInput
    update: XOR<SharedMenuSubCategoryUpdateWithoutCategoryInput, SharedMenuSubCategoryUncheckedUpdateWithoutCategoryInput>
    create: XOR<SharedMenuSubCategoryCreateWithoutCategoryInput, SharedMenuSubCategoryUncheckedCreateWithoutCategoryInput>
  }

  export type SharedMenuSubCategoryUpdateWithWhereUniqueWithoutCategoryInput = {
    where: SharedMenuSubCategoryWhereUniqueInput
    data: XOR<SharedMenuSubCategoryUpdateWithoutCategoryInput, SharedMenuSubCategoryUncheckedUpdateWithoutCategoryInput>
  }

  export type SharedMenuSubCategoryUpdateManyWithWhereWithoutCategoryInput = {
    where: SharedMenuSubCategoryScalarWhereInput
    data: XOR<SharedMenuSubCategoryUpdateManyMutationInput, SharedMenuSubCategoryUncheckedUpdateManyWithoutCategoryInput>
  }

  export type SharedMenuItemUpsertWithWhereUniqueWithoutCategoryInput = {
    where: SharedMenuItemWhereUniqueInput
    update: XOR<SharedMenuItemUpdateWithoutCategoryInput, SharedMenuItemUncheckedUpdateWithoutCategoryInput>
    create: XOR<SharedMenuItemCreateWithoutCategoryInput, SharedMenuItemUncheckedCreateWithoutCategoryInput>
  }

  export type SharedMenuItemUpdateWithWhereUniqueWithoutCategoryInput = {
    where: SharedMenuItemWhereUniqueInput
    data: XOR<SharedMenuItemUpdateWithoutCategoryInput, SharedMenuItemUncheckedUpdateWithoutCategoryInput>
  }

  export type SharedMenuItemUpdateManyWithWhereWithoutCategoryInput = {
    where: SharedMenuItemScalarWhereInput
    data: XOR<SharedMenuItemUpdateManyMutationInput, SharedMenuItemUncheckedUpdateManyWithoutCategoryInput>
  }

  export type SharedVendorCreateWithoutMenuSubCategoriesInput = {
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    user: SharedUserCreateNestedOneWithoutVendorsInput
    posts?: SharedPostCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemCreateNestedManyWithoutVendorInput
    offers?: SharedOfferCreateNestedManyWithoutVendorInput
    bills?: SharedBillCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUncheckedCreateWithoutMenuSubCategoriesInput = {
    id?: number
    userId: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemUncheckedCreateNestedManyWithoutVendorInput
    offers?: SharedOfferUncheckedCreateNestedManyWithoutVendorInput
    bills?: SharedBillUncheckedCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorCreateOrConnectWithoutMenuSubCategoriesInput = {
    where: SharedVendorWhereUniqueInput
    create: XOR<SharedVendorCreateWithoutMenuSubCategoriesInput, SharedVendorUncheckedCreateWithoutMenuSubCategoriesInput>
  }

  export type SharedMenuCategoryCreateWithoutSubCategoriesInput = {
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuCategoriesInput
    items?: SharedMenuItemCreateNestedManyWithoutCategoryInput
  }

  export type SharedMenuCategoryUncheckedCreateWithoutSubCategoriesInput = {
    id?: number
    vendorId: number
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    items?: SharedMenuItemUncheckedCreateNestedManyWithoutCategoryInput
  }

  export type SharedMenuCategoryCreateOrConnectWithoutSubCategoriesInput = {
    where: SharedMenuCategoryWhereUniqueInput
    create: XOR<SharedMenuCategoryCreateWithoutSubCategoriesInput, SharedMenuCategoryUncheckedCreateWithoutSubCategoriesInput>
  }

  export type SharedMenuItemCreateWithoutSubCategoryInput = {
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuItemsInput
    category: SharedMenuCategoryCreateNestedOneWithoutItemsInput
  }

  export type SharedMenuItemUncheckedCreateWithoutSubCategoryInput = {
    id?: number
    vendorId: number
    menuCategoryId: number
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuItemCreateOrConnectWithoutSubCategoryInput = {
    where: SharedMenuItemWhereUniqueInput
    create: XOR<SharedMenuItemCreateWithoutSubCategoryInput, SharedMenuItemUncheckedCreateWithoutSubCategoryInput>
  }

  export type SharedMenuItemCreateManySubCategoryInputEnvelope = {
    data: SharedMenuItemCreateManySubCategoryInput | SharedMenuItemCreateManySubCategoryInput[]
    skipDuplicates?: boolean
  }

  export type SharedVendorUpsertWithoutMenuSubCategoriesInput = {
    update: XOR<SharedVendorUpdateWithoutMenuSubCategoriesInput, SharedVendorUncheckedUpdateWithoutMenuSubCategoriesInput>
    create: XOR<SharedVendorCreateWithoutMenuSubCategoriesInput, SharedVendorUncheckedCreateWithoutMenuSubCategoriesInput>
    where?: SharedVendorWhereInput
  }

  export type SharedVendorUpdateToOneWithWhereWithoutMenuSubCategoriesInput = {
    where?: SharedVendorWhereInput
    data: XOR<SharedVendorUpdateWithoutMenuSubCategoriesInput, SharedVendorUncheckedUpdateWithoutMenuSubCategoriesInput>
  }

  export type SharedVendorUpdateWithoutMenuSubCategoriesInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: SharedUserUpdateOneRequiredWithoutVendorsNestedInput
    posts?: SharedPostUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateWithoutMenuSubCategoriesInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUncheckedUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUncheckedUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUncheckedUpdateManyWithoutVendorNestedInput
  }

  export type SharedMenuCategoryUpsertWithoutSubCategoriesInput = {
    update: XOR<SharedMenuCategoryUpdateWithoutSubCategoriesInput, SharedMenuCategoryUncheckedUpdateWithoutSubCategoriesInput>
    create: XOR<SharedMenuCategoryCreateWithoutSubCategoriesInput, SharedMenuCategoryUncheckedCreateWithoutSubCategoriesInput>
    where?: SharedMenuCategoryWhereInput
  }

  export type SharedMenuCategoryUpdateToOneWithWhereWithoutSubCategoriesInput = {
    where?: SharedMenuCategoryWhereInput
    data: XOR<SharedMenuCategoryUpdateWithoutSubCategoriesInput, SharedMenuCategoryUncheckedUpdateWithoutSubCategoriesInput>
  }

  export type SharedMenuCategoryUpdateWithoutSubCategoriesInput = {
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuCategoriesNestedInput
    items?: SharedMenuItemUpdateManyWithoutCategoryNestedInput
  }

  export type SharedMenuCategoryUncheckedUpdateWithoutSubCategoriesInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    items?: SharedMenuItemUncheckedUpdateManyWithoutCategoryNestedInput
  }

  export type SharedMenuItemUpsertWithWhereUniqueWithoutSubCategoryInput = {
    where: SharedMenuItemWhereUniqueInput
    update: XOR<SharedMenuItemUpdateWithoutSubCategoryInput, SharedMenuItemUncheckedUpdateWithoutSubCategoryInput>
    create: XOR<SharedMenuItemCreateWithoutSubCategoryInput, SharedMenuItemUncheckedCreateWithoutSubCategoryInput>
  }

  export type SharedMenuItemUpdateWithWhereUniqueWithoutSubCategoryInput = {
    where: SharedMenuItemWhereUniqueInput
    data: XOR<SharedMenuItemUpdateWithoutSubCategoryInput, SharedMenuItemUncheckedUpdateWithoutSubCategoryInput>
  }

  export type SharedMenuItemUpdateManyWithWhereWithoutSubCategoryInput = {
    where: SharedMenuItemScalarWhereInput
    data: XOR<SharedMenuItemUpdateManyMutationInput, SharedMenuItemUncheckedUpdateManyWithoutSubCategoryInput>
  }

  export type SharedVendorCreateWithoutMenuItemsInput = {
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    user: SharedUserCreateNestedOneWithoutVendorsInput
    posts?: SharedPostCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryCreateNestedManyWithoutVendorInput
    offers?: SharedOfferCreateNestedManyWithoutVendorInput
    bills?: SharedBillCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUncheckedCreateWithoutMenuItemsInput = {
    id?: number
    userId: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutVendorInput
    offers?: SharedOfferUncheckedCreateNestedManyWithoutVendorInput
    bills?: SharedBillUncheckedCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorCreateOrConnectWithoutMenuItemsInput = {
    where: SharedVendorWhereUniqueInput
    create: XOR<SharedVendorCreateWithoutMenuItemsInput, SharedVendorUncheckedCreateWithoutMenuItemsInput>
  }

  export type SharedMenuCategoryCreateWithoutItemsInput = {
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuCategoriesInput
    subCategories?: SharedMenuSubCategoryCreateNestedManyWithoutCategoryInput
  }

  export type SharedMenuCategoryUncheckedCreateWithoutItemsInput = {
    id?: number
    vendorId: number
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    subCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutCategoryInput
  }

  export type SharedMenuCategoryCreateOrConnectWithoutItemsInput = {
    where: SharedMenuCategoryWhereUniqueInput
    create: XOR<SharedMenuCategoryCreateWithoutItemsInput, SharedMenuCategoryUncheckedCreateWithoutItemsInput>
  }

  export type SharedMenuSubCategoryCreateWithoutItemsInput = {
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutMenuSubCategoriesInput
    category: SharedMenuCategoryCreateNestedOneWithoutSubCategoriesInput
  }

  export type SharedMenuSubCategoryUncheckedCreateWithoutItemsInput = {
    id?: number
    vendorId: number
    categoryId: number
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuSubCategoryCreateOrConnectWithoutItemsInput = {
    where: SharedMenuSubCategoryWhereUniqueInput
    create: XOR<SharedMenuSubCategoryCreateWithoutItemsInput, SharedMenuSubCategoryUncheckedCreateWithoutItemsInput>
  }

  export type SharedVendorUpsertWithoutMenuItemsInput = {
    update: XOR<SharedVendorUpdateWithoutMenuItemsInput, SharedVendorUncheckedUpdateWithoutMenuItemsInput>
    create: XOR<SharedVendorCreateWithoutMenuItemsInput, SharedVendorUncheckedCreateWithoutMenuItemsInput>
    where?: SharedVendorWhereInput
  }

  export type SharedVendorUpdateToOneWithWhereWithoutMenuItemsInput = {
    where?: SharedVendorWhereInput
    data: XOR<SharedVendorUpdateWithoutMenuItemsInput, SharedVendorUncheckedUpdateWithoutMenuItemsInput>
  }

  export type SharedVendorUpdateWithoutMenuItemsInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: SharedUserUpdateOneRequiredWithoutVendorsNestedInput
    posts?: SharedPostUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateWithoutMenuItemsInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUncheckedUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUncheckedUpdateManyWithoutVendorNestedInput
  }

  export type SharedMenuCategoryUpsertWithoutItemsInput = {
    update: XOR<SharedMenuCategoryUpdateWithoutItemsInput, SharedMenuCategoryUncheckedUpdateWithoutItemsInput>
    create: XOR<SharedMenuCategoryCreateWithoutItemsInput, SharedMenuCategoryUncheckedCreateWithoutItemsInput>
    where?: SharedMenuCategoryWhereInput
  }

  export type SharedMenuCategoryUpdateToOneWithWhereWithoutItemsInput = {
    where?: SharedMenuCategoryWhereInput
    data: XOR<SharedMenuCategoryUpdateWithoutItemsInput, SharedMenuCategoryUncheckedUpdateWithoutItemsInput>
  }

  export type SharedMenuCategoryUpdateWithoutItemsInput = {
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuCategoriesNestedInput
    subCategories?: SharedMenuSubCategoryUpdateManyWithoutCategoryNestedInput
  }

  export type SharedMenuCategoryUncheckedUpdateWithoutItemsInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    subCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutCategoryNestedInput
  }

  export type SharedMenuSubCategoryUpsertWithoutItemsInput = {
    update: XOR<SharedMenuSubCategoryUpdateWithoutItemsInput, SharedMenuSubCategoryUncheckedUpdateWithoutItemsInput>
    create: XOR<SharedMenuSubCategoryCreateWithoutItemsInput, SharedMenuSubCategoryUncheckedCreateWithoutItemsInput>
    where?: SharedMenuSubCategoryWhereInput
  }

  export type SharedMenuSubCategoryUpdateToOneWithWhereWithoutItemsInput = {
    where?: SharedMenuSubCategoryWhereInput
    data: XOR<SharedMenuSubCategoryUpdateWithoutItemsInput, SharedMenuSubCategoryUncheckedUpdateWithoutItemsInput>
  }

  export type SharedMenuSubCategoryUpdateWithoutItemsInput = {
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuSubCategoriesNestedInput
    category?: SharedMenuCategoryUpdateOneRequiredWithoutSubCategoriesNestedInput
  }

  export type SharedMenuSubCategoryUncheckedUpdateWithoutItemsInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    categoryId?: IntFieldUpdateOperationsInput | number
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedVendorCreateWithoutOffersInput = {
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    user: SharedUserCreateNestedOneWithoutVendorsInput
    posts?: SharedPostCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemCreateNestedManyWithoutVendorInput
    bills?: SharedBillCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUncheckedCreateWithoutOffersInput = {
    id?: number
    userId: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemUncheckedCreateNestedManyWithoutVendorInput
    bills?: SharedBillUncheckedCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorCreateOrConnectWithoutOffersInput = {
    where: SharedVendorWhereUniqueInput
    create: XOR<SharedVendorCreateWithoutOffersInput, SharedVendorUncheckedCreateWithoutOffersInput>
  }

  export type SharedPostCreateWithoutOfferInput = {
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendor: SharedVendorCreateNestedOneWithoutPostsInput
  }

  export type SharedPostUncheckedCreateWithoutOfferInput = {
    id?: number
    vendorId: number
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedPostCreateOrConnectWithoutOfferInput = {
    where: SharedPostWhereUniqueInput
    create: XOR<SharedPostCreateWithoutOfferInput, SharedPostUncheckedCreateWithoutOfferInput>
  }

  export type SharedPostCreateManyOfferInputEnvelope = {
    data: SharedPostCreateManyOfferInput | SharedPostCreateManyOfferInput[]
    skipDuplicates?: boolean
  }

  export type SharedVendorUpsertWithoutOffersInput = {
    update: XOR<SharedVendorUpdateWithoutOffersInput, SharedVendorUncheckedUpdateWithoutOffersInput>
    create: XOR<SharedVendorCreateWithoutOffersInput, SharedVendorUncheckedCreateWithoutOffersInput>
    where?: SharedVendorWhereInput
  }

  export type SharedVendorUpdateToOneWithWhereWithoutOffersInput = {
    where?: SharedVendorWhereInput
    data: XOR<SharedVendorUpdateWithoutOffersInput, SharedVendorUncheckedUpdateWithoutOffersInput>
  }

  export type SharedVendorUpdateWithoutOffersInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: SharedUserUpdateOneRequiredWithoutVendorsNestedInput
    posts?: SharedPostUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateWithoutOffersInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUncheckedUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUncheckedUpdateManyWithoutVendorNestedInput
  }

  export type SharedPostUpsertWithWhereUniqueWithoutOfferInput = {
    where: SharedPostWhereUniqueInput
    update: XOR<SharedPostUpdateWithoutOfferInput, SharedPostUncheckedUpdateWithoutOfferInput>
    create: XOR<SharedPostCreateWithoutOfferInput, SharedPostUncheckedCreateWithoutOfferInput>
  }

  export type SharedPostUpdateWithWhereUniqueWithoutOfferInput = {
    where: SharedPostWhereUniqueInput
    data: XOR<SharedPostUpdateWithoutOfferInput, SharedPostUncheckedUpdateWithoutOfferInput>
  }

  export type SharedPostUpdateManyWithWhereWithoutOfferInput = {
    where: SharedPostScalarWhereInput
    data: XOR<SharedPostUpdateManyMutationInput, SharedPostUncheckedUpdateManyWithoutOfferInput>
  }

  export type SharedVendorCreateWithoutBillsInput = {
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    user: SharedUserCreateNestedOneWithoutVendorsInput
    posts?: SharedPostCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemCreateNestedManyWithoutVendorInput
    offers?: SharedOfferCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorUncheckedCreateWithoutBillsInput = {
    id?: number
    userId: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    posts?: SharedPostUncheckedCreateNestedManyWithoutVendorInput
    menuCategories?: SharedMenuCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedCreateNestedManyWithoutVendorInput
    menuItems?: SharedMenuItemUncheckedCreateNestedManyWithoutVendorInput
    offers?: SharedOfferUncheckedCreateNestedManyWithoutVendorInput
  }

  export type SharedVendorCreateOrConnectWithoutBillsInput = {
    where: SharedVendorWhereUniqueInput
    create: XOR<SharedVendorCreateWithoutBillsInput, SharedVendorUncheckedCreateWithoutBillsInput>
  }

  export type SharedUserCreateWithoutBillsInput = {
    phoneNumber: string
    userType: string
    status: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendors?: SharedVendorCreateNestedManyWithoutUserInput
  }

  export type SharedUserUncheckedCreateWithoutBillsInput = {
    id?: number
    phoneNumber: string
    userType: string
    status: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
    vendors?: SharedVendorUncheckedCreateNestedManyWithoutUserInput
  }

  export type SharedUserCreateOrConnectWithoutBillsInput = {
    where: SharedUserWhereUniqueInput
    create: XOR<SharedUserCreateWithoutBillsInput, SharedUserUncheckedCreateWithoutBillsInput>
  }

  export type SharedVendorUpsertWithoutBillsInput = {
    update: XOR<SharedVendorUpdateWithoutBillsInput, SharedVendorUncheckedUpdateWithoutBillsInput>
    create: XOR<SharedVendorCreateWithoutBillsInput, SharedVendorUncheckedCreateWithoutBillsInput>
    where?: SharedVendorWhereInput
  }

  export type SharedVendorUpdateToOneWithWhereWithoutBillsInput = {
    where?: SharedVendorWhereInput
    data: XOR<SharedVendorUpdateWithoutBillsInput, SharedVendorUncheckedUpdateWithoutBillsInput>
  }

  export type SharedVendorUpdateWithoutBillsInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: SharedUserUpdateOneRequiredWithoutVendorsNestedInput
    posts?: SharedPostUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateWithoutBillsInput = {
    id?: IntFieldUpdateOperationsInput | number
    userId?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUncheckedUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUncheckedUpdateManyWithoutVendorNestedInput
  }

  export type SharedUserUpsertWithoutBillsInput = {
    update: XOR<SharedUserUpdateWithoutBillsInput, SharedUserUncheckedUpdateWithoutBillsInput>
    create: XOR<SharedUserCreateWithoutBillsInput, SharedUserUncheckedCreateWithoutBillsInput>
    where?: SharedUserWhereInput
  }

  export type SharedUserUpdateToOneWithWhereWithoutBillsInput = {
    where?: SharedUserWhereInput
    data: XOR<SharedUserUpdateWithoutBillsInput, SharedUserUncheckedUpdateWithoutBillsInput>
  }

  export type SharedUserUpdateWithoutBillsInput = {
    phoneNumber?: StringFieldUpdateOperationsInput | string
    userType?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendors?: SharedVendorUpdateManyWithoutUserNestedInput
  }

  export type SharedUserUncheckedUpdateWithoutBillsInput = {
    id?: IntFieldUpdateOperationsInput | number
    phoneNumber?: StringFieldUpdateOperationsInput | string
    userType?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendors?: SharedVendorUncheckedUpdateManyWithoutUserNestedInput
  }

  export type SharedVendorCreateManyUserInput = {
    id?: number
    businessName?: string | null
    status: string
    logoUrl?: string | null
    businessCategory?: string | null
    address?: string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedBillCreateManyEndUserInput = {
    id?: number
    vendorId: number
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedVendorUpdateWithoutUserInput = {
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutVendorNestedInput
    menuCategories?: SharedMenuCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuSubCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorNestedInput
    menuItems?: SharedMenuItemUncheckedUpdateManyWithoutVendorNestedInput
    offers?: SharedOfferUncheckedUpdateManyWithoutVendorNestedInput
    bills?: SharedBillUncheckedUpdateManyWithoutVendorNestedInput
  }

  export type SharedVendorUncheckedUpdateManyWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    businessName?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    logoUrl?: NullableStringFieldUpdateOperationsInput | string | null
    businessCategory?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    payment?: NullableJsonNullValueInput | InputJsonValue
    workingDays?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedBillUpdateWithoutEndUserInput = {
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutBillsNestedInput
  }

  export type SharedBillUncheckedUpdateWithoutEndUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedBillUncheckedUpdateManyWithoutEndUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedPostCreateManyVendorInput = {
    id?: number
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    offerId?: number | null
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuCategoryCreateManyVendorInput = {
    id?: number
    categoryName: string
    categoryImage?: string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuSubCategoryCreateManyVendorInput = {
    id?: number
    categoryId: number
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuItemCreateManyVendorInput = {
    id?: number
    menuCategoryId: number
    menuSubCategoryId?: number | null
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedOfferCreateManyVendorInput = {
    id?: number
    offerTargetType?: string | null
    offerTargetId?: number | null
    offerType: string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: Date | string | null
    validityTo?: Date | string | null
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedBillCreateManyVendorInput = {
    id?: number
    endUserId?: number | null
    products: JsonNullValueInput | InputJsonValue
    totalPrice?: Decimal | DecimalJsLike | number | string
    paymentStatus?: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedPostUpdateWithoutVendorInput = {
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    offer?: SharedOfferUpdateOneWithoutPostsNestedInput
  }

  export type SharedPostUncheckedUpdateWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    offerId?: NullableIntFieldUpdateOperationsInput | number | null
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedPostUncheckedUpdateManyWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    offerId?: NullableIntFieldUpdateOperationsInput | number | null
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuCategoryUpdateWithoutVendorInput = {
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    subCategories?: SharedMenuSubCategoryUpdateManyWithoutCategoryNestedInput
    items?: SharedMenuItemUpdateManyWithoutCategoryNestedInput
  }

  export type SharedMenuCategoryUncheckedUpdateWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    subCategories?: SharedMenuSubCategoryUncheckedUpdateManyWithoutCategoryNestedInput
    items?: SharedMenuItemUncheckedUpdateManyWithoutCategoryNestedInput
  }

  export type SharedMenuCategoryUncheckedUpdateManyWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    categoryName?: StringFieldUpdateOperationsInput | string
    categoryImage?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuSubCategoryUpdateWithoutVendorInput = {
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    category?: SharedMenuCategoryUpdateOneRequiredWithoutSubCategoriesNestedInput
    items?: SharedMenuItemUpdateManyWithoutSubCategoryNestedInput
  }

  export type SharedMenuSubCategoryUncheckedUpdateWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    categoryId?: IntFieldUpdateOperationsInput | number
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    items?: SharedMenuItemUncheckedUpdateManyWithoutSubCategoryNestedInput
  }

  export type SharedMenuSubCategoryUncheckedUpdateManyWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    categoryId?: IntFieldUpdateOperationsInput | number
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemUpdateWithoutVendorInput = {
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    category?: SharedMenuCategoryUpdateOneRequiredWithoutItemsNestedInput
    subCategory?: SharedMenuSubCategoryUpdateOneWithoutItemsNestedInput
  }

  export type SharedMenuItemUncheckedUpdateWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    menuCategoryId?: IntFieldUpdateOperationsInput | number
    menuSubCategoryId?: NullableIntFieldUpdateOperationsInput | number | null
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemUncheckedUpdateManyWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    menuCategoryId?: IntFieldUpdateOperationsInput | number
    menuSubCategoryId?: NullableIntFieldUpdateOperationsInput | number | null
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedOfferUpdateWithoutVendorInput = {
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUpdateManyWithoutOfferNestedInput
  }

  export type SharedOfferUncheckedUpdateWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    posts?: SharedPostUncheckedUpdateManyWithoutOfferNestedInput
  }

  export type SharedOfferUncheckedUpdateManyWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    offerTargetType?: NullableStringFieldUpdateOperationsInput | string | null
    offerTargetId?: NullableIntFieldUpdateOperationsInput | number | null
    offerType?: StringFieldUpdateOperationsInput | string
    offerValue?: NullableJsonNullValueInput | InputJsonValue
    validityFrom?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    validityTo?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedBillUpdateWithoutVendorInput = {
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    endUser?: SharedUserUpdateOneWithoutBillsNestedInput
  }

  export type SharedBillUncheckedUpdateWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    endUserId?: NullableIntFieldUpdateOperationsInput | number | null
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedBillUncheckedUpdateManyWithoutVendorInput = {
    id?: IntFieldUpdateOperationsInput | number
    endUserId?: NullableIntFieldUpdateOperationsInput | number | null
    products?: JsonNullValueInput | InputJsonValue
    totalPrice?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    paymentStatus?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuSubCategoryCreateManyCategoryInput = {
    id?: number
    vendorId: number
    subCategoryName: string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuItemCreateManyCategoryInput = {
    id?: number
    vendorId: number
    menuSubCategoryId?: number | null
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuSubCategoryUpdateWithoutCategoryInput = {
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuSubCategoriesNestedInput
    items?: SharedMenuItemUpdateManyWithoutSubCategoryNestedInput
  }

  export type SharedMenuSubCategoryUncheckedUpdateWithoutCategoryInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    items?: SharedMenuItemUncheckedUpdateManyWithoutSubCategoryNestedInput
  }

  export type SharedMenuSubCategoryUncheckedUpdateManyWithoutCategoryInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    subCategoryName?: StringFieldUpdateOperationsInput | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemUpdateWithoutCategoryInput = {
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuItemsNestedInput
    subCategory?: SharedMenuSubCategoryUpdateOneWithoutItemsNestedInput
  }

  export type SharedMenuItemUncheckedUpdateWithoutCategoryInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    menuSubCategoryId?: NullableIntFieldUpdateOperationsInput | number | null
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemUncheckedUpdateManyWithoutCategoryInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    menuSubCategoryId?: NullableIntFieldUpdateOperationsInput | number | null
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemCreateManySubCategoryInput = {
    id?: number
    vendorId: number
    menuCategoryId: number
    productName: string
    image?: string | null
    price: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedMenuItemUpdateWithoutSubCategoryInput = {
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutMenuItemsNestedInput
    category?: SharedMenuCategoryUpdateOneRequiredWithoutItemsNestedInput
  }

  export type SharedMenuItemUncheckedUpdateWithoutSubCategoryInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    menuCategoryId?: IntFieldUpdateOperationsInput | number
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedMenuItemUncheckedUpdateManyWithoutSubCategoryInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    menuCategoryId?: IntFieldUpdateOperationsInput | number
    productName?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedPostCreateManyOfferInput = {
    id?: number
    vendorId: number
    postType: string
    postCategory?: string | null
    postUrl: string
    isOfferIncluded?: boolean
    isDownloaded?: boolean
    createdAt?: Date | string | null
    updatedAt?: Date | string | null
  }

  export type SharedPostUpdateWithoutOfferInput = {
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    vendor?: SharedVendorUpdateOneRequiredWithoutPostsNestedInput
  }

  export type SharedPostUncheckedUpdateWithoutOfferInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SharedPostUncheckedUpdateManyWithoutOfferInput = {
    id?: IntFieldUpdateOperationsInput | number
    vendorId?: IntFieldUpdateOperationsInput | number
    postType?: StringFieldUpdateOperationsInput | string
    postCategory?: NullableStringFieldUpdateOperationsInput | string | null
    postUrl?: StringFieldUpdateOperationsInput | string
    isOfferIncluded?: BoolFieldUpdateOperationsInput | boolean
    isDownloaded?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    updatedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}