import "server-only";
import { pooledDatabaseUrl } from "@/lib/db/database-url";
import { PrismaClient } from "@/lib/db/generated/shared";

const globalForSharedPrisma = globalThis as typeof globalThis & {
  zidduSharedPrisma?: PrismaClient;
};

export const sharedPrisma = globalForSharedPrisma.zidduSharedPrisma ?? new PrismaClient({ datasourceUrl: pooledDatabaseUrl() });

// Reuse one client per instance (and across dev hot reloads) so pools are never duplicated.
globalForSharedPrisma.zidduSharedPrisma = sharedPrisma;
