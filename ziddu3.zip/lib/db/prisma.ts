import "server-only";
import { pooledDatabaseUrl } from "@/lib/db/database-url";
import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as typeof globalThis & {
  zidduPrisma?: PrismaClient;
};

export const prisma = globalForPrisma.zidduPrisma ?? new PrismaClient({ datasourceUrl: pooledDatabaseUrl() });

// Reuse one client per instance (and across dev hot reloads) so pools are never duplicated.
globalForPrisma.zidduPrisma = prisma;